//
// Created by ubuntu on 2024/6/4.
//

#ifndef BOS_CORE_SERVICE_LINUX_SERVICE_MANAGER_H
#define BOS_CORE_SERVICE_LINUX_SERVICE_MANAGER_H
#include <systemd/sd-bus.h>
#include <memory>
namespace bos::framework::em {



    class linux_service_manager {
    public:
        linux_service_manager();
        ~linux_service_manager();

        linux_service_manager(const linux_service_manager&) = delete;
        linux_service_manager& operator=(const linux_service_manager&) = delete;
        linux_service_manager(linux_service_manager&&) = delete;
        linux_service_manager& operator=(linux_service_manager&&) = delete;

    private:
        sd_bus* bus = nullptr;

    public:

        int start_service_by_name(const std::string& service_name);
        int stop_service_by_name(const std::string& service_name);
        int restart_service_by_name(const std::string& service_name);

        int stop_service_by_id(int serviceId);
        int restart_service_by_id(int serviceId);

        int get_service_id_by_name(const std::string& serviceName);
        std::string get_service_name_by_id(int serviceId);

        std::string get_service_status_by_id(int serviceId);
        std::string get_service_status_by_name(const std::string& serviceName);
        bool is_service_active(const std::string& serviceName);

        int get_service_nice_by_id(int serviceId);
        int get_service_nice_by_name(const std::string& serviceName);

        int set_service_nice_by_id(int serviceId, int niceValue);
        int set_service_nice_by_name(const std::string& serviceName, int niceValue);

        int get_oomscore_by_id(int serviceId);
        int get_oomcore_by_name(const std::string& serviceName);

        int set_oomscore_by_id(int serviceId, int oomScore);
        int set_oomscore_by_name(const std::string& serviceName, int oomScore);

        void reload_daemon();

    private:
        void remove_service_suffix(std::string& serviceName);
        void add_service_suffix(std::string &serviceName);
        std::string construct_object_path(const std::string& serviceName);

    private:
        int try_get_main_pid_by_name(const std::string& serviceName);
        int manage_service(const std::string& service_name, const std::string& action);
        int manager_service_by_id(int serviceId, const std::string& action);

        int get_main_pid_by_id(int serviceId);
        int get_main_pid_by_name(const std::string& serviceName);
    };
}
#endif //BOS_CORE_SERVICE_LINUX_SERVICE_MANAGER_H
