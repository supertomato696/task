//
// Created by ubuntu on 2024/6/4.
//
#include <iostream>
#include <stdexcept>
#include <cstring>
#include "linux_service_manager.h"
#include <systemd/sd-login.h>
#include <thread>
#include <sys/resource.h>
#include <fstream>
namespace bos::framework::em {

    linux_service_manager::linux_service_manager()  {
        int ret = sd_bus_open_system(&bus);
        if (ret >= 0) {
            std::cout << "linux_service_manager connect to dbus!" << std::endl;
            ret = sd_bus_request_name(bus, "com.byd.bos_em_service",0);
            if (ret >= 0) {
                std::cout << "linux_service_manager  require service name " <<  std::endl;
            }
        }
    }

    linux_service_manager::~linux_service_manager() {
        if (bus) {
            sd_bus_unref(bus);
            std::cout << "~linux_service_manager disconnect dbus!" << std::endl;
        }
    }

    int linux_service_manager::start_service_by_name(const std::string& service_name) {
        return manage_service(service_name, "StartUnit");
    }

    int linux_service_manager::stop_service_by_name(const std::string& service_name) {
        return manage_service(service_name, "StopUnit");
    }

    int linux_service_manager::restart_service_by_name(const std::string& service_name) {

        return manage_service(service_name, "RestartUnit");
    }

    int linux_service_manager::stop_service_by_id(int serviceId) {
        return manager_service_by_id(serviceId, "StopUnit");
    }

    int linux_service_manager::restart_service_by_id(int serviceId) {
        return manager_service_by_id(serviceId, "RestartUnit");
    }



    int linux_service_manager::get_service_id_by_name(const std::string& serviceName) {
        sd_bus_error error = SD_BUS_ERROR_NULL;
        sd_bus_message *m = nullptr;
        std::string  path;
        path = construct_object_path(serviceName);
        int pid = -1;
        // Get the MainPID property of the service
        int ret = sd_bus_get_property(bus,
                                      "org.freedesktop.systemd1",
                                      path.c_str(),
                                      "org.freedesktop.systemd1.Service",
                                      "MainPID",
                                      &error,
                                      &m,
                                      "u");
        if (ret < 0) {
            std::cerr << "Failed to get MainPID property: " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return -1;
        }

        // Read the property value
        ret = sd_bus_message_read(m, "u", &pid);
        if (ret < 0) {
            std::cerr << "Failed to read MainPID property: " << strerror(-ret) << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return -1;
        }

        sd_bus_message_unref(m);
        sd_bus_error_free(&error);
        return pid;

    }

    std::string linux_service_manager::get_service_name_by_id(pid_t pid) {
        sd_bus_error error = SD_BUS_ERROR_NULL;
        sd_bus_message *m = nullptr;
        std::string serviceName;
        std::string servicePath;

        int ret = sd_bus_call_method(bus,
                                     "org.freedesktop.systemd1",       // 服务名
                                     "/org/freedesktop/systemd1",      // 对象路径
                                     "org.freedesktop.systemd1.Manager", // 接口名
                                     "GetUnitByPID",                    // 方法名
                                     &error,                            // 错误处理
                                     &m,                                // 返回的消息
                                     "u",                               // 输入参数的类型
                                     (uint32_t)pid);                    // 实际参数

        if (ret < 0) {
            std::cerr << "Failed to get service path by PID: " << pid <<   std::strerror(-ret) << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return "";
        }

        const char *path = nullptr;
        ret = sd_bus_message_read(m, "o", &path);
        if (ret < 0) {
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            std::cerr << "Failed to read object path property: " << strerror(-ret) << std::endl;
            return "";
        }

        if (path == nullptr) {
            std::cerr << "path is empty" << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return "";
        }

        servicePath = path;
        sd_bus_message_unref(m);
        m = nullptr;

        // Get the Id property of the service (name.service name)
        ret = sd_bus_get_property(bus,
                                  "org.freedesktop.systemd1",
                                  servicePath.c_str(),
                                  "org.freedesktop.systemd1.Unit",
                                  "Id",
                                  &error,
                                  &m,
                                  "s");
        if (ret < 0) {
            std::cerr << "Failed to get Id property: " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return "";
        }

        // Read the property value
        const char *service = nullptr;
        ret = sd_bus_message_read(m, "s", &service);
        if (ret < 0 ) {
            std::cerr << "Failed to read Id property: " << strerror(-ret) << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return "";
        }

        if (service == nullptr) {
            std::cerr << "read empty message" << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return "";
        }

        serviceName = service;
        sd_bus_message_unref(m);
        sd_bus_error_free(&error);

        remove_service_suffix(serviceName);
        std::cout << "get_service_name_by_id " << "serviceName: " << serviceName << std::endl;
        return serviceName;
    }

    std::string linux_service_manager::get_service_status_by_id(int serviceId) {
        sd_bus_error error = SD_BUS_ERROR_NULL;
        sd_bus_message *m = nullptr;
        std::string servicePath;
        std::string serviceStatus;

        int ret = sd_bus_call_method(bus,
                                     "org.freedesktop.systemd1",
                                     "/org/freedesktop/systemd1",
                                     "org.freedesktop.systemd1.Manager",
                                     "GetUnitByPID",
                                     &error,
                                     &m,
                                     "u",
                                     (uint32_t)serviceId);
        if (ret < 0) {
            std::cerr << "get_service_status_by_id " << "Failed to GetUnitByPid pid: " << serviceId << " " << error.message <<std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return "";
        }

        const char *path = nullptr;
        ret = sd_bus_message_read(m, "o", &path);
        if (ret < 0 ) {
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            std::cerr << "Failed to read object path: " << serviceId <<  " " << strerror(-ret) << std::endl;
            return "";
        }

        if (path == nullptr) {
            std::cerr << "read empty object path" << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return "";
        }

        servicePath = path;
        sd_bus_message_unref(m);
        m = nullptr;

        ret = sd_bus_get_property(bus,
                                  "org.freedesktop.systemd1",
                                  servicePath.c_str(),
                                  "org.freedesktop.systemd1.Unit",
                                  "ActiveState",
                                  &error,
                                  &m,
                                  "s");

        if (ret < 0) {
            std::cerr << "Failed to get ActiveState property : " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return "";
        }

        const char *status = nullptr;
        ret = sd_bus_message_read(m, "s", &status);
        if (ret < 0 ) {
            std::cerr << "Failed to read ActiveState property: " << strerror(-ret) << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return "";
        }

        if (status == nullptr) {
            std::cerr << "read empty ActiveState property" << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return  "";
        }

        serviceStatus = status;
        sd_bus_message_unref(m);
        sd_bus_error_free(&error);
        return serviceStatus;
    }

    std::string linux_service_manager::get_service_status_by_name(const std::string& serviceName) {
        sd_bus_error error = SD_BUS_ERROR_NULL;
        sd_bus_message *m = nullptr;
        std::string serviceStatus;
        std::string servicePath = construct_object_path(serviceName);

        int ret = sd_bus_get_property(bus,
                                      "org.freedesktop.systemd1",
                                      servicePath.c_str(),
                                      "org.freedesktop.systemd1.Unit",
                                      "ActiveState",
                                      &error,
                                      &m,
                                      "s");
        if (ret < 0) {
            std::cerr << "Failed to get ActivieState property: " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return "";
        }

        const char *status = nullptr;
        ret = sd_bus_message_read(m, "s", &status);
        if (ret < 0 ) {
            std::cerr << "Failed to read ActiveState property: " << strerror(-ret) << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return "";
        }

        if (status == nullptr) {
            std::cerr << "read empty ActiveState property" << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return  "";
        }

        serviceStatus = status;
        sd_bus_message_unref(m);
        sd_bus_error_free(&error);
        return serviceStatus;
    }

    bool linux_service_manager::is_service_active(const std::string& serviceName) {
        std::string active_state = get_service_status_by_name(serviceName);
        std::cout << "s_service_active " << active_state << std::endl;
        return std::string(active_state) == "active";
    }

    int linux_service_manager::get_service_nice_by_id(int serviceId) {
        errno = 0;
        int niceValue = getpriority(PRIO_PROCESS, serviceId);
        if (niceValue == -1 && errno != 0) {
            std::cerr << "Failed to getpriority" << std::endl;
            return niceValue;
        }
        std::cout << "get_service_nice_by_id"<< " getpriority sucessful" << std::endl;
        return niceValue;
    }

    int linux_service_manager::get_service_nice_by_name(const std::string& serviceName) {
        int mainPid = get_main_pid_by_name(serviceName);
        if (mainPid <= 0) {
            std::cerr << "Failed to get MainPidByName" << std::endl;
            return -1;
        }
        return get_service_nice_by_id(mainPid);
    }

    int linux_service_manager::set_service_nice_by_id(int serviceId, int niceValue) {
        if (setpriority(PRIO_PROCESS, serviceId, niceValue) == 0) {
            std::cout << "setpriority sucessful, pid: " <<  serviceId << std::endl;
            return 0;
        }

        std::cerr << "Failed to serpriority, pid: " << serviceId <<std::endl;
        return -1;

    }

    int linux_service_manager::set_service_nice_by_name(const std::string& serviceName, int niceValue) {

        int mainPid = get_main_pid_by_name(serviceName);
        if (mainPid <=0) {
            std::cerr << "Failed to getMainPidByName" << std::endl;
            return -1;
        }

        return set_service_nice_by_id(mainPid, niceValue);
    }

    int linux_service_manager::get_oomscore_by_id(int serviceId) {
        int oomScore;
        std::string path = "/proc/" + std::to_string(serviceId) + "/oom_score_adj";
        std::ifstream file(path);
        if (!file.is_open()) {
            std::cerr << "Failed to open file: " << path <<std::endl;
            return -1;
        }

        file  >> oomScore;
        std::cout << "get oom_score sucessful " << oomScore << std::endl;
        return oomScore;
    }

    int linux_service_manager::get_oomcore_by_name(const std::string& serviceName) {
        int mainPid = get_main_pid_by_name(serviceName);
        if (mainPid <= 0) {
            std::cerr << "Failed to getMainPidByName" << std::endl;
            return -1;
        }
        return get_oomscore_by_id(mainPid);
    }

    int linux_service_manager::set_oomscore_by_id(int serviceId, int oomScore) {
        std::string path = "/proc/" + std::to_string(serviceId) + "/oom_score_adj";
        std::ofstream file(path);
        if (!file.is_open()) {
            std::cerr << "Failed to open file: " << path <<std::endl;
            return -1;
        }

        file << oomScore;
        std::cout << "set oom_score sucessful " << std::endl;
        return 0;
    }

    int linux_service_manager::set_oomscore_by_name(const std::string& serviceName, int oomScore) {
        int mainPid = get_main_pid_by_name(serviceName);
        if (mainPid <= 0) {
            std::cerr << "Failed to getMainPidByName" << std::endl;
            return -1;
        }
        return set_oomscore_by_id(mainPid, oomScore);
    }



    int  linux_service_manager::get_main_pid_by_id(pid_t serviceId) {
        sd_bus_error error = SD_BUS_ERROR_NULL;
        sd_bus_message *m = nullptr;
        std::string objectPath;
        int mainPid = -1;

        int ret = sd_bus_call_method(bus,
                                     "org.freedesktop.systemd1",
                                     "/org/freedesktop/systemd1",
                                     "org.freedesktop.systemd1.Manager",
                                     "GetUnitByPID",
                                     &error,
                                     &m,
                                     "u",
                                     (uint32_t)serviceId);
        if (ret < 0) {
            std::cerr << "get_main_pid_by_id " <<  "Failed to GetUnitByPid pid :" << serviceId << " " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return -1;
        }

        const char* path = nullptr;
        ret = sd_bus_message_read(m, "o", &path);
        if (ret < 0 ) {
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            std::cerr << "Failed to read object path: " << serviceId << " " << strerror(-ret) << std::endl;
            return -1;
        }

        if (path == nullptr) {
            std::cerr << "read empty object path" << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return -1;
        }
        // Get the MainPID property of the service
        objectPath = path;
        sd_bus_message_unref(m);
        m = nullptr;

        ret = sd_bus_get_property(bus,
                                  "org.freedesktop.systemd1",
                                  objectPath.c_str(),
                                  "org.freedesktop.systemd1.Service",
                                  "MainPID",
                                  &error,
                                  &m,
                                  "u"); // 'u' indicates that the property is an unsigned integer
        if (ret < 0) {
            std::cerr << "Failed to get MainPID property: " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return -1;
        }

        // Read the property value
        ret = sd_bus_message_read(m, "u", &mainPid);
        if (ret < 0) {
            std::cerr << "Failed to read MainPID property: " << strerror(-ret) << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return -1;
        }

        sd_bus_message_unref(m);
        sd_bus_error_free(&error);
        return mainPid;
    }


    int linux_service_manager::get_main_pid_by_name(const std::string& serviceName) {
        sd_bus_error error = SD_BUS_ERROR_NULL;
        sd_bus_message *m = nullptr;
        int mainPid = -1;

        std::string objectPath = construct_object_path(serviceName);

        // Get the MainPID property of the service
        int ret = sd_bus_get_property(bus,
                                      "org.freedesktop.systemd1",
                                      objectPath.c_str(),
                                      "org.freedesktop.systemd1.Service",
                                      "MainPID",
                                      &error,
                                      &m,
                                      "u"); // 'u' indicates that the property is an unsigned integer
        if (ret < 0) {
            std::cerr << "Failed to get MainPID property: " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return -1;
        }

        // Read the property value
        ret = sd_bus_message_read(m, "u", &mainPid);
        if (ret < 0) {
            std::cerr << "Failed to read MainPID property: " << strerror(-ret) << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return -1;
        }

        sd_bus_message_unref(m);
        sd_bus_error_free(&error);
        return mainPid;
    }


    int linux_service_manager::manage_service(const std::string& service_name, const std::string& action) {
        sd_bus_error error = SD_BUS_ERROR_NULL;
        sd_bus_message* msg = nullptr;
        std::string serviceName = service_name;
        add_service_suffix(serviceName);

        int ret = sd_bus_call_method(bus,
                                     "org.freedesktop.systemd1",
                                     "/org/freedesktop/systemd1",
                                     "org.freedesktop.systemd1.Manager",
                                     action.c_str(),
                                     &error,
                                     &msg,
                                     "ss",
                                     serviceName.c_str(),
                                     "replace");

        if (ret < 0)
        {
            std::cerr << "Failed to " << action << " service: " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(msg);
            return ret;
        }

        std::cout << "Service " << service_name << " has been " << action << "ed successfully." << std::endl;

        sd_bus_message_unref(msg);
        sd_bus_error_free(&error);

        // No new PID for stop action, return 0 if action is StopUnit
        return action == "StopUnit" ? 0 : try_get_main_pid_by_name(service_name);

    }

    int linux_service_manager::manager_service_by_id(int serviceId, const std::string& action) {
        sd_bus_error error = SD_BUS_ERROR_NULL;
        sd_bus_message *m = nullptr;
        std::string objectPath;
        std::string serviceName;

        int ret = sd_bus_call_method(bus,
                                     "org.freedesktop.systemd1",
                                     "/org/freedesktop/systemd1",
                                     "org.freedesktop.systemd1.Manager",
                                     "GetUnitByPID",
                                     &error,
                                     &m,
                                     "u",
                                     (uint32_t)serviceId);

        if (ret < 0) {
            std::cerr << "manager_service_by_id " << "Failed to GetUnitByPid pid :" << serviceId << " " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return -1;
        }

        const char* path = nullptr;
        ret = sd_bus_message_read(m, "o", &path);
        if (ret < 0 ) {
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            std::cerr << "Failed to read object path: " << serviceId << " " << strerror(-ret) << std::endl;
            return -1;
        }

        if (path == nullptr) {
            std::cerr << "read empty object path" << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return -1;
        }

        objectPath = path;
        sd_bus_message_unref(m);
        m = nullptr;

        ret = sd_bus_get_property(bus,
                                  "org.freedesktop.systemd1",
                                  objectPath.c_str(),
                                  "org.freedesktop.systemd1.Unit",
                                  "Id",
                                  &error,
                                  &m,
                                  "s");
        if (ret < 0) {
            std::cerr << "Failed to get Id property: " << error.message << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return -1;
        }

        const char* service = nullptr;
        ret = sd_bus_message_read(m, "s", &service);
        if (ret < 0 ) {
            std::cerr << "Failed to read Id property: " << strerror(-ret) << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return -1;
        }

        if (service == nullptr) {
            std::cerr << "read empty Id property" << std::endl;
            sd_bus_message_unref(m);
            sd_bus_error_free(&error);
            return  -1;
        }

        serviceName = service;
        sd_bus_message_unref(m);
        m = nullptr;

        ret = sd_bus_call_method(bus,
                                 "org.freedesktop.systemd1",
                                 "/org/freedesktop/systemd1",
                                 "org.freedesktop.systemd1.Manager",
                                 action.c_str(),
                                 &error,
                                 &m,
                                 "ss",
                                 serviceName.c_str(),
                                 "replace");

        if (ret < 0) {
            std::cerr << "Failed to " << action <<  " service: " << error.message << std::endl;
            sd_bus_error_free(&error);
            sd_bus_message_unref(m);
            return -1; // Indicate error
        }

        sd_bus_message_unref(m);
        sd_bus_error_free(&error);

        // Get the main PID of the service
        return action == "StopUnit" ? 0 : try_get_main_pid_by_name(serviceName);
        // return getMainPidByName(serviceName);
    }


    int linux_service_manager::try_get_main_pid_by_name(const std::string& serviceName) {
        int new_pid = -1;
        for (int i = 0; i < 10; ++i)
        { // 尝试 10 次，每次等待 2 毫秒
            if (is_service_active(serviceName))
            {
                new_pid = get_main_pid_by_name(serviceName);
                if (new_pid > 0)
                {
                    std::cout << "[action-restart]: tryGetMainPidByName done!" <<  " after: " << i <<std::endl;
                    break;
                }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }

        return new_pid;
    }

    void linux_service_manager::reload_daemon() {
        sd_bus_message *m = nullptr;
        int ret = sd_bus_message_new_method_call(bus, &m,
                                                 "org.freedesktop.systemd1",
                                                 "/org/freedesktop/systemd1",
                                                 "org.freedesktop.systemd1.Manager",
                                                 "Reload");
        if (ret < 0) {
            std::cerr << "Failed to create method call: " << strerror(-ret) << std::endl;
            return;
        }

        ret = sd_bus_call(bus, m, 0, nullptr, nullptr);
        if (ret < 0) {
            std::cerr << "Failed to reload daemon: " << strerror(-ret) << std::endl;
        } else {
            std::cout << "Daemon reloaded successfully." << std::endl;
        }

        sd_bus_message_unref(m);
    }



    void linux_service_manager:: remove_service_suffix(std::string& serviceName){
        static const std::string suffix = ".service";
        if (serviceName.size() >= suffix.size() &&
            serviceName.compare(serviceName.size() - suffix.size(), suffix.size(), suffix) == 0) {
            serviceName = serviceName.substr(0, serviceName.size() - suffix.size());
        }
        return ;
    }


    void linux_service_manager::add_service_suffix(std::string &serviceName) {
        static const std::string suffix = ".service";
        // 检查服务名是否以 ".service" 结尾
        if (serviceName.length() < suffix.length() ||
            serviceName.compare(serviceName.length() - suffix.length(), suffix.length(), suffix) != 0) {
            serviceName += suffix;  // 如果不是，则添加 ".service"
        }
    }

    std::string linux_service_manager::construct_object_path(const std::string& serviceName) {
        std::string temp = serviceName;
        remove_service_suffix(temp);
        return "/org/freedesktop/systemd1/unit/" + temp + "_2eservice";
    }
}