__all__ = ["Config"]

from src.model.config import Config