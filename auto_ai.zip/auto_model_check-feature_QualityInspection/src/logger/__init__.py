# -*- coding: utf-8 -*-
# @Time    : 2024/10/24 19:54
# @Author  : StephenLeung
# @Email   : liang.yuhao1@byd.com
# @File    : __init__.py

__all__ = ["logger"]

from src.logger.loggerController import logger
