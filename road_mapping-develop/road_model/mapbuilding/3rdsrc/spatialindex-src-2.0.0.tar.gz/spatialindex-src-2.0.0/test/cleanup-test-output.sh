#! /bin/bash

rm *.dat *.idx || true
rm data queries res mix || true
