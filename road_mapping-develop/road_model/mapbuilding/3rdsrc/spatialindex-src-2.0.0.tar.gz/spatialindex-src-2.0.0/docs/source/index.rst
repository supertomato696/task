*****************************************************************************
 libspatialindex
*****************************************************************************

.. toctree::
   :maxdepth: 1

   install
   Github <https://github.com/libspatialindex/libspatialindex>
   community
   overview


* `Class Documentation <./doxygen/index.html>`_



.. include:: introduction.rst
.. include:: ../../COPYING
.. include:: download.rst


