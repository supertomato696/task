import os
import time
import json
import csv
from datetime import datetime
import pyproj
import geopandas as gpd
import pandas as pd
from rtree import index
from typing import Dict
from pydantic import BaseModel, Field
from shapely.geometry import Point, LineString, Polygon
from pathlib import Path


class PolygonTopoResult(BaseModel):
    """
    评测结果类，包含：交叉点数量、拓扑错误线数量
    """
    intersect_lanes: int = Field(title="相互压盖车道",description="相互压盖车道数量")
    length_discrepancy: int = Field(title="左右车道线差异较大的车道",description="左右车道线差异较大的车道数量")
    lanes_lanelines_in_roads: int = Field(title="车道线与车道数量差异较大的道路面",description="车道线与车道数量差异较大的道路面数量")
    left_laneline_distance: int = Field(title="车道组内车道距离过远",description="车道组内车道距离过远的车道线数量")

class PolygonTopoCheck():
    def __init__(self,input_file_path:str,distance_threshold,output_gpkg):
        self.gpkg_name = output_gpkg
        self.lanelines_gdf = gpd.read_file(os.path.join(input_file_path,"lane_boundary.shp"))
        self.lanes_gdf = gpd.read_file(os.path.join(input_file_path,"lane.shp"))
        self.roads_gdf = gpd.read_file(os.path.join(input_file_path,"road.shp"))
        self.intersect_lanes = self.detect_intersecting_lanes()
        self.length_discrepancy = self.detect_lane_length_discrepancy()
        self.lanes_lanelines_in_roads = self.detect_lanelines_lanes_in_roads()
        self.left_laneline_distance = self.detect_lane_distance(distance_threshold)
        # poly_topo_result = PolygonTopoResult()
        # poly_topo_result.intersect_lanes = len(intersect_lanes)
        # poly_topo_result.length_discrepancy = len(length_discrepancy)
        # poly_topo_result.lanes_lanelines_in_roads = len(lanes_lanelines_in_roads)
        # poly_topo_result.left_laneline_distance = len(left_laneline_distance)
        self.save_results_to_geopackage(self.intersect_lanes,self.length_discrepancy,self.lanes_lanelines_in_roads,self.left_laneline_distance,self.gpkg_name)
        
    
    def get_dict(self) -> Dict:
        stats_dict = {
            "相互压盖车道数量": f"{len(self.intersect_lanes['lane_index']):d}",
            "左右车道线差异较大的车道数量": f"{len(self.length_discrepancy['lane_index']):d}",
            "车道线与车道数量差异较大的道路面数量": f"{len(self.lanes_lanelines_in_roads['road_index']):d}",
            "车道组内车道距离过远的车道线数量": f"{len(self.left_laneline_distance['laneline_index']):d}",
            "车道数量": f"{len(self.lanes_gdf):d}",
            "道路数量": f"{len(self.roads_gdf):d}",
            "车道线数量": f"{len(self.lanelines_gdf):2f}",
            "车道问题比例": f"{(len(self.intersect_lanes['lane_index']) + len(self.length_discrepancy['lane_index'])) / len(self.lanes_gdf)* 100:2f}%",
            "道路问题比例": f"{len(self.lanes_lanelines_in_roads['road_index']) / len(self.lanes_gdf)* 100:2f}%",
            "车道线问题比例": f"{len(self.left_laneline_distance['laneline_index']) / len(self.lanes_gdf)* 100:2f}%",
        }
        return stats_dict

    def transform_geometry(self,geometry):
        """
        转换几何对象到新的坐标系。
        
        :param geometry: 几何对象，可以是 Point, LineString 或 Polygon
        :param src_crs: 源坐标系，例如 "EPSG:4326"
        :param dst_crs: 目标坐标系，例如 "EPSG:3785"
        :return: 转换后的几何对象
        """
        src_crs = "EPSG:4326"
        dst_crs = "EPSG:3785"
        # 创建坐标转换器
        transformer = pyproj.Transformer.from_crs(src_crs, dst_crs, always_xy=True)
        
        # 转换几何对象
        if isinstance(geometry, Point):
            # 对于点，直接转换
            x, y = transformer.transform(geometry.x, geometry.y)
            return Point(x, y)
        elif isinstance(geometry, LineString):
            # 对于线，转换所有点
            new_coords = [transformer.transform(x, y) for x, y in geometry.coords]
            return LineString(new_coords)
        elif isinstance(geometry, Polygon):
            # 对于多边形，转换外部和内部环
            new_exterior = [transformer.transform(x, y) for x, y in geometry.exterior.coords]
            new_interiors = []
            for interior in geometry.interiors:
                new_interior = [transformer.transform(x, y) for x, y in interior.coords]
                new_interiors.append(LineString(new_interior))
            return Polygon(new_exterior, new_interiors)
        else:
            raise ValueError("Unsupported geometry type")
        
    # 车道互相压盖
    def detect_intersecting_lanes(self):
        """
        检测相互压盖的车道，并在原始数据中添加相交状态列
        优化：避免无效循环，使用空间索引加速
        """
        rtree_idx = index.Index()

        # 构建 R-tree 索引
        for i, geom in enumerate(self.lanes_gdf.geometry):
            if isinstance(geom, Polygon):
                rtree_idx.insert(i, geom.bounds)

        intersect_lanes = {
            'lane_index': set(),
            'lane_id': [],
            'geometry': [],
            'intersect_lane_id': [],
            'intersect_area': []
        }
        for i, geom1 in enumerate(self.lanes_gdf.geometry):
            potential_intersects = list(rtree_idx.intersection(geom1.bounds))
            candidates_intersect_lane_id = []
            candidates_intersect_area = []
            for j in potential_intersects:
                if i != j:
                    geom2 = self.lanes_gdf.geometry[j]
                    if geom1.is_valid and geom2.is_valid:
                        if isinstance(geom2, Polygon):
                            intersection = geom1.intersection(geom2)
                            if not intersection.is_empty:
                                if geom1.intersection(geom2).area > 0:
                                    intersect_lanes['lane_index'].add(i)
                                    candidates_intersect_lane_id.append(self.lanes_gdf.iloc[j]['ID'])
                                    geom1_prj = self.transform_geometry(geom1)
                                    geom2_prj = self.transform_geometry(geom2)
                                    intersect_prj = geom1_prj.intersection(geom2_prj)
                                    candidates_intersect_area.append(intersect_prj.area)
                    elif not geom1.is_valid:
                        intersect_lanes['lane_index'].add(i)
                        intersect_lanes['lane_id'].append(self.lanes_gdf.iloc[i]['ID'])
                        intersect_lanes['geometry'].append(self.lanes_gdf.iloc[i].geometry)
                        intersect_lanes['intersect_lane_id'].append('self_intersect')
                        intersect_lanes['intersect_area'].append('self_intersect')
                        break
                    else:
                        continue 
            if len(candidates_intersect_lane_id) > 0 and i not in intersect_lanes['lane_id']:
                intersect_lanes['lane_id'].append(self.lanes_gdf.iloc[i]['ID'])
                intersect_lanes['geometry'].append(self.lanes_gdf.iloc[i].geometry)
                intersect_lanes['intersect_lane_id'].append(candidates_intersect_lane_id)
                intersect_lanes['intersect_area'].append(candidates_intersect_area)
        return intersect_lanes

    # 车道左右线长度相差过大
    def detect_lane_length_discrepancy(self):
        """
        检测车道左右线长度相差是否过大。
        """

        length_discrepancy = {
            'lane_index': set(),
            'lane_id': [],
            'geometry': [],
            'left_laneline_id': [],
            'right_laneline_id': [],
            'delta_length': []
        }

        for i, lane_geom in enumerate(self.lanes_gdf.geometry):
            lane_feature = self.lanes_gdf.iloc[i]
            lane_id = lane_feature['ID']

            # 获取左边线和右边线的几何信息
            lanelines_geom = self.lanelines_gdf.geometry
            left_laneline_index = self.lanelines_gdf.loc[self.lanelines_gdf['ID'] == lane_feature['LEFT_BID']].index[0]
            right_laneline_index = self.lanelines_gdf.loc[self.lanelines_gdf['ID'] == lane_feature['RIGHT_BID']].index[0]

            #loc[self.lanelines_gdf['ID'] == lane_feature['LEFT_BID']]
            #right_laneline = self.lanelines_gdf.geometry
            #.loc[self.lanelines_gdf['ID'] == lane_feature['RIGHT_BID']]

            left_geom_prj = self.transform_geometry(lanelines_geom[left_laneline_index])
            right_geom_prj = self.transform_geometry(lanelines_geom[right_laneline_index])

            # 计算左边线和右边线的长度
            left_length = float(left_geom_prj.length)
            right_length = float(right_geom_prj.length)
            
            # 找到长边和短边
            if left_length > right_length:
                long_edge = left_length
                short_edge = right_length
            else:
                long_edge = right_length
                short_edge = left_length
            
            # 检查短边与长边的比例是否小于80%
            if short_edge / long_edge < 0.8:
                # 计算长边与短边的差
                length_diff = long_edge - short_edge
                
                # 检查长边与短边的差是否大于3米
                if length_diff > 3:
                    length_discrepancy['lane_index'].add(i)
                    length_discrepancy['lane_id'].append(lane_id)
                    length_discrepancy['geometry'].append(lane_geom)
                    length_discrepancy['left_laneline_id'].append(lane_feature['LEFT_BID'])
                    length_discrepancy['right_laneline_id'].append(lane_feature['RIGHT_BID'])
                    length_discrepancy['delta_length'].append(length_diff)

        return length_discrepancy

    # 车道组内车道数量与车道线数量相差较大
    def detect_lanelines_lanes_in_roads(self):
        """
        检测车道组内车道数量与车道线数量相差较大的情况。
        """
        lanes_lanelines_in_roads = {
            'road_index': set(),
            'road_id': [],
            'lanes_in_road': [],
            'geometry': [],
            'lanes_num': [],
            'lanelines_num': [],
            'discrepancy': []
        }

        for i, road_geom in enumerate(self.roads_gdf.geometry):
            road_feature = self.roads_gdf.iloc[i]
            road_id = road_feature['ID']
            lanes_in_road = road_feature['LANE_ID'].split(',')
            lanes_num = len(lanes_in_road)
            laneline_in_road = []
            for lane_id in lanes_in_road:
                lane_index = self.lanes_gdf.loc[self.lanes_gdf['ID'] == lane_id].index[0]
                lane_feature = self.lanes_gdf.iloc[lane_index]
                if lane_feature['LEFT_BID'] not in laneline_in_road:
                    laneline_in_road.append(lane_feature['LEFT_BID'])
                if lane_feature['RIGHT_BID'] not in laneline_in_road:
                    laneline_in_road.append(lane_feature['RIGHT_BID'])

            lanelines_num = len(laneline_in_road)
            discrepancy = abs(lanelines_num - lanes_num)
            
            # 如果差异大于3，则报错
            if discrepancy > 3:
                lanes_lanelines_in_roads['road_index'].add(i)
                lanes_lanelines_in_roads['road_id'].append(road_id)
                lanes_lanelines_in_roads['lanes_in_road'].append(lanes_in_road)
                lanes_lanelines_in_roads['geometry'].append(road_geom)
                lanes_lanelines_in_roads['lanes_num'].append(lanes_num)
                lanes_lanelines_in_roads['lanelines_num'].append(lanelines_num)
                lanes_lanelines_in_roads['discrepancy'].append(discrepancy)
        return lanes_lanelines_in_roads

    # 车道组内车道距离过远
    def detect_lane_distance(self,distance_threshold=5):
        """
        检测车道组内车道距离是否过远。
        
        参数:
            distance_threshold (float): 距离阈值，默认为5米
        """
        left_laneline_distance = {
            'laneline_index': [],
            'laneline_id': [],
            'relative_laneline_id': [],
            'geometry': [],
            'min_distance': []
        }

        lanelines_geom = self.lanelines_gdf.geometry

        for i, road_geom in enumerate(self.roads_gdf.geometry):
            road_feature = self.roads_gdf.iloc[i]
            lanes_in_road = road_feature['LANE_ID'].split(',')
            if len(lanes_in_road) > 1:
                left_laneline_in_road = []
                for lane_id in lanes_in_road:
                    lane_index = self.lanes_gdf.loc[self.lanes_gdf['ID'] == lane_id].index[0]
                    lane_feature = self.lanes_gdf.iloc[lane_index]
                    if lane_feature['LEFT_BID'] not in left_laneline_in_road:
                        left_laneline_in_road.append(lane_feature['LEFT_BID'])
                    # if lane_feature['RIGHT_BID'] not in laneline_in_road:
                    #     laneline_in_road.append(lane_feature['RIGHT_BID'])

                for i in range(len(left_laneline_in_road)-1):
                    laneline_i_id = left_laneline_in_road[i]
                    laneline_j_id = left_laneline_in_road[i+1]

                    laneline_feature_i_index = self.lanelines_gdf.loc[self.lanelines_gdf['ID'] == laneline_i_id].index[0]
                    laneline_feature_j_index = self.lanelines_gdf.loc[self.lanelines_gdf['ID'] == laneline_j_id].index[0]
                    
                    laneline_geom_i_prj = self.transform_geometry(lanelines_geom[laneline_feature_i_index])
                    laneline_geom_j_prj = self.transform_geometry(lanelines_geom[laneline_feature_j_index])
                    
                    start_point_i = Point(laneline_geom_i_prj.coords[0])
                    start_point_j = Point(laneline_geom_j_prj.coords[0])
                    end_point_i =  Point(laneline_geom_i_prj.coords[-1])
                    end_point_j =  Point(laneline_geom_j_prj.coords[-1])

                    distance = [start_point_i.distance(start_point_j),end_point_i.distance(end_point_j) > 5]
                    if distance[0] > 5 or distance[1] > 5:
                        if laneline_feature_i_index not in left_laneline_distance['laneline_index']:
                            left_laneline_distance['laneline_index'].append(laneline_feature_i_index)
                            left_laneline_distance['laneline_id'].append(laneline_i_id)
                            left_laneline_distance['relative_laneline_id'].append(laneline_j_id)
                            left_laneline_distance['geometry'].append(lanelines_geom[laneline_feature_i_index])
                            left_laneline_distance['min_distance'].append(distance)
                        if laneline_feature_j_index not in left_laneline_distance['laneline_index']:
                            left_laneline_distance['laneline_index'].append(laneline_feature_j_index)
                            left_laneline_distance['laneline_id'].append(laneline_j_id)
                            left_laneline_distance['relative_laneline_id'].append(laneline_i_id)
                            left_laneline_distance['geometry'].append(lanelines_geom[laneline_feature_j_index])
                            left_laneline_distance['min_distance'].append(distance)

        return left_laneline_distance

    # 结果打包gpkg输出
    def save_results_to_geopackage(self, intersect_lanes, length_discrepancy, lanes_lanelines_in_roads, left_laneline_distance,
                                   output_gpkg ="validation_result"):
        """
        将验证结果保存为一个 GeoPackage 文件，并将相关信息写入属性表。
        """
        output_gpkg = output_gpkg + '.gpkg'
        # 创建 GeoDataFrame 用于保存错误结果
        if len(intersect_lanes['lane_index']) != 0:
            intersect_lanes['lane_index'] = list(intersect_lanes['lane_index'])            
            intersect_lanes_gdf = gpd.GeoDataFrame(intersect_lanes, crs=self.lanes_gdf.crs)
            intersect_lanes_gdf.to_file(output_gpkg, layer="intersect_lanes", driver="GPKG")
        if len(length_discrepancy['lane_index']) != 0:
            length_discrepancy['lane_index'] = list(length_discrepancy['lane_index'])            
            length_discrepancy_gdf = gpd.GeoDataFrame(length_discrepancy, crs=self.lanes_gdf.crs)
            length_discrepancy_gdf.to_file(output_gpkg, layer="length_discrepancy", driver="GPKG")
        if len(lanes_lanelines_in_roads['road_index']) != 0:
            lanes_lanelines_in_roads['road_index'] = list(lanes_lanelines_in_roads['road_index'])            
            lanes_lanelines_in_roads_gdf = gpd.GeoDataFrame(lanes_lanelines_in_roads, crs=self.lanes_gdf.crs)
            lanes_lanelines_in_roads_gdf.to_file(output_gpkg, layer="lanes_lanelines_in_roads", driver="GPKG")
        if len(left_laneline_distance['laneline_index']) != 0:          
            left_laneline_distance_gdf = gpd.GeoDataFrame(left_laneline_distance, crs=self.lanes_gdf.crs)
            left_laneline_distance_gdf.to_file(output_gpkg, layer="lane_distance", driver="GPKG")
        self.lanelines_gdf.to_file(output_gpkg,layer='lane_boundary',driver="GPKG")
        self.lanes_gdf.to_file(output_gpkg,layer='lane',driver="GPKG")
        self.roads_gdf.to_file(output_gpkg,layer='road',driver="GPKG")

def json2csv(output_path, json_file_path):
    with open(json_file_path, 'r', encoding='utf-8') as f:
        json_data = json.load(f)

    csv_file_name = f"{json_data['version']}_{json_data['elapsed_time']}.csv"
    csv_file_path = os.path.join(output_path, csv_file_name)
    # 解析JSON数据，提取result部分
    results = json_data['result']

    # 获取所有评估类型
    first_batch = next(iter(json_data["result"].items()))[1]
    all_eval_types = first_batch.keys()

    # 准备 CSV 文件头
    csv_headers = ["算法框ID"]

    # 添加评估类型到文件头
    for eval_type in all_eval_types:
        csv_headers.append(eval_type)

    # 写入 CSV 文件
    with open(csv_file_path, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile, quoting=csv.QUOTE_NONNUMERIC)
        writer.writerow(csv_headers)

        # 遍历结果数据
        for algo_box, evaluations in results.items():
            row = [algo_box]
            for eval_type in all_eval_types:
                eval_data = evaluations.get(eval_type, {})
                row.append(eval_data)
                
            writer.writerow(row)
    
    print(f"CSV 文件 {csv_file_name} 已生成。")


if __name__ == "__main__":
    
    input_file_path = r'E:\geoeva_v2.0\data\input\v3.05.02_mmt_bev'
    output_data_path = r'E:\geoeva_v2.0\data\output0509_3'
    version = input_file_path.split('\\')[-1]
    distance_threshold = 5
    folders = os.listdir(input_file_path)
    poly_topo_result_dict = {
        "version": version,
        "elapsed_time": 0,
        "result": {}
    }
    overall_start = time.perf_counter()
    for algo_box in folders:
        if not algo_box.endswith('.zip'):
            input_data_path = os.path.join(input_file_path,algo_box)
            poly_topo_result_dict["result"][algo_box] = {}
            output_path = os.path.join(output_data_path,version)
            os.makedirs(output_path, exist_ok=True)
            output_gpkg = os.path.join(output_path,str(version) + '_' + str(algo_box) + "_polygon_topo")
            poly_topo_result = PolygonTopoCheck(input_data_path,distance_threshold,output_gpkg)
            poly_topo_result_dict['result'][algo_box].update(poly_topo_result.get_dict())
    elapsed_time = time.perf_counter() - overall_start
    poly_topo_result_dict['elapsed_time'] = f"{elapsed_time:.2f}s"
    task_json_file = os.path.join(output_data_path,
                                        poly_topo_result_dict['version'] + '_' + datetime.now().strftime("%Y-%m-%d_%H%M%S") + '.json')
    with open(task_json_file, 'w', encoding='utf-8') as f:
                json.dump(poly_topo_result_dict, f, ensure_ascii=False, indent=4)
    
    # task_json_file = r'E:\geoeva_v2.0\data\output0509_2\v3.05.01_mmt_bev_2025-05-09_174108.json'
    # output_path = r'E:\geoeva_v2.0\data\output0509_2'
    
    json2csv(output_path,task_json_file)