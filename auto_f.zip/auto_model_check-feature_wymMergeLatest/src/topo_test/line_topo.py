import os
import time
import json
import csv
from datetime import datetime
import geopandas as gpd
import matplotlib.pyplot as plt
from rtree import index
import pyproj
from typing import Dict
from pydantic import BaseModel, Field
# from src.tools.common import ensure_single_geometries
from shapely.geometry import Point, LineString, Polygon, MultiPoint, MultiPolygon, MultiLineString
# from src.logger import logger

class LineTopoResult(BaseModel):
    """
    评测结果类，包含：交叉点数量、拓扑错误线数量
    """
    num_of_intersect_lines: int = Field(title="相交线要素",description="相交线要素数量")
    num_of_intersect_points: int = Field(title="线要素相交点",description="线要素相交点数量")
    num_of_dangling_nodes: int = Field(title="悬挂点数量",description="悬挂点数量数量")
    num_of_attribute_errors: int = Field(title="前驱后继属性挂接错误车道线",description="前驱后继属性挂接错误车道线数量")
    num_of_missing_errors: int = Field(title="疑似应挂接但未挂接前驱后继车道线",description="疑似应挂接但未挂接前驱后继车道线数量")
    num_of_input_lines:  int = Field(title="输入线要素总数量",description="输入线要素总数量")

class LaneLineTopoCheck():
    def __init__(self,input_file_path:str,buffer_distance,output_gpkg):
        self.gpkg_name = output_gpkg # input_file_path.split('\\')[-2]
        self.gdf = self.ensure_single_geometries(gpd.read_file(os.path.join(input_file_path,"lane_boundary.shp")))
        self.buffer_distance = buffer_distance # 0.5
        self.intersections, self.intersection_points = self.find_intersect_features()
        self.dangling_nodes = self.find_dangling_nodes()
        self.pre_next_validate = self.validate_predecessor_successor()
        self.save_results_to_geopackage(self.intersections,self.intersection_points,self.dangling_nodes,self.pre_next_validate,self.gpkg_name)

    def get_dict(self) -> Dict:
        stats_dict = {
            "相交线要素数量": f"{len(self.intersections):d}",
            "线要素相交点数量": f"{len(self.intersection_points):d}",
            "悬挂点数量数量": f"{len(self.dangling_nodes):d}",
            "前驱后继属性挂接错误车道线数量": f"{len(self.pre_next_validate['errors']):d}",
            "疑似应挂接但未挂接前驱后继车道线数量": f"{len(self.pre_next_validate['intersecting_ids']):d}",
            "输入线要素总数量": f"{len(self.gdf):d}",
        }
        return stats_dict
       
    def check_all_instance(self, gdf: gpd.GeoDataFrame) -> bool:
        """Checks if all geometries in a GeoDataFrame are LineStrings using isinstance."""
        if gdf.empty:
            return True
        return gdf.geometry.apply(lambda geom: isinstance(geom, (LineString, Polygon,Point))).all()


    def ensure_single_geometries(self, gdf) -> gpd.GeoDataFrame:
        """
        将 GeoDataFrame 中的几何对象转换为单一的 Polygon 和 LineString。

        :param gdf: GeoDataFrame, 包含可能的 MultiPolygon 和 MultiLineString 几何对象
        :return: GeoDataFrame, 仅包含 Polygon 和 LineString，保留原始属性和CRS
        """

        # 使用 explode 方法分解复杂几何
        # 使用 explode(index_parts=False) 分解 MultiPolygon 和 MultiLineString 对象。index_parts=False 可以保持原始索引而不分解为多层索引。
        exploded_gdf = gdf.explode(index_parts=False)

        # 创建新的几何列表和属性列表
        single_geometries = []
        attributes = []

        for idx, row in exploded_gdf.iterrows():
            geom = row['geometry']
            if isinstance(geom, (MultiPolygon, MultiLineString)):
                for part in geom:
                    # 对于每个分解后的几何对象，保留原始行的属性值（去除 geometry 列），并将单一几何对象附加到 single_geometries 列表
                    single_geometries.append(part)
                    attributes.append(row.drop('geometry'))
            elif isinstance(geom, (Polygon, LineString,Point)):
                single_geometries.append(geom)
                attributes.append(row.drop('geometry'))

        # 创建新的 GeoDataFrame，一次性添加所有行.设置几何列为活动几何列.
        final_gdf = gpd.GeoDataFrame(attributes, geometry=single_geometries)
        # 重置索引
        final_gdf.reset_index(drop=True, inplace=True)

        # 赋予新的 GeoDataFrame 原始 CRS
        final_gdf.crs = gdf.crs

        if self.check_all_instance(final_gdf):
            return final_gdf
        else:
            final_gdf = self.ensure_single_geometries(final_gdf)   


    def find_intersect_features(self):
        """
        查找相交的线要素和交叉点。

        :param gdf: GeoDataFrame，包含线要素的几何信息
        :return: 两个 GeoDataFrame，分别包含相交的线要素和交叉点
        """
        rtree_idx = index.Index()

        # 构建 R-tree 索引
        for i, geom in enumerate(self.gdf.geometry):
            if isinstance(geom, LineString):
                rtree_idx.insert(i, geom.bounds)

        intersections = set()
        intersection_points = []

        # 查找相交的线要素
        for i, geom1 in enumerate(self.gdf.geometry):
            potential_intersects = list(rtree_idx.intersection(geom1.bounds))
            for j in potential_intersects:
                if i != j:
                    geom2 = self.gdf.geometry[j]
                    if isinstance(geom2, LineString):
                        intersection = geom1.intersection(geom2)
                        if not intersection.is_empty:
                            endpoints = [geom1.coords[0], geom1.coords[-1], geom2.coords[0], geom2.coords[-1]]
                            if isinstance(intersection, Point):
                                if intersection.coords[0] not in endpoints:
                                    intersections.add(i)
                                    intersection_points.append(intersection)
                            elif isinstance(intersection, MultiPoint):
                                for point in intersection.geoms:
                                    if point.coords[0] not in endpoints:
                                        intersections.add(i)
                                        intersection_points.append(point)
                                        break
        return intersections,intersection_points

    # 大地坐标转投影坐标，生成缓冲区后再转大地坐标
    def transform_polygon(self, polygon: Polygon, src_crs: str, dst_crs: str):
        """
        将 Polygon 对象从一个坐标系投影到另一个坐标系。

        :param polygon: Shapely Polygon 对象
        :param src_crs: 源坐标系（如 "EPSG:4326"）
        :param dst_crs: 目标坐标系（如 "+proj=aeqd +R=6371000 +units=m +lat_0=30 +lon_0=120"）
        :return: 投影后的 Polygon 对象
        """
        # 创建投影转换器
        transformer = pyproj.Transformer.from_crs(src_crs, dst_crs, always_xy=True)

        # 获取多边形的外环和内环坐标
        exterior_coords = polygon.exterior.coords
        interior_coords = [interior.coords for interior in polygon.interiors]

        # 转换外环坐标
        transformed_exterior = [transformer.transform(x, y) for x, y in exterior_coords]

        # 转换内环坐标
        transformed_interiors = [[transformer.transform(x, y) for x, y in interior] for interior in interior_coords]

        # 创建新的 Polygon 对象
        transformed_polygon = Polygon(transformed_exterior, transformed_interiors)

        return transformed_polygon

    def prj_transform(self,point: Point):
        """
        将点从 WGS84 坐标系投影到 Azimuthal Equidistant 投影，
        生成缓冲区，然后将缓冲区投影回 WGS84 坐标系。

        :param point: Shapely Point 对象，表示地理坐标点
        :return: 投影回 WGS84 的缓冲区
        """
        # 定义 Azimuthal Equidistant 投影
        local_azimuthal_projection = f"+proj=aeqd +R=6371000 +units=m +lat_0={point.y} +lon_0={point.x}"

        # 定义投影转换函数
        wgs84 = "EPSG:4326"
        aeqd = local_azimuthal_projection
        transformer_to_aeqd = pyproj.Transformer.from_crs(wgs84, aeqd, always_xy=True)
        transformer_to_wgs84 = pyproj.Transformer.from_crs(aeqd, wgs84, always_xy=True)

        # 将点投影到 Azimuthal Equidistant 投影
        point_transformed = Point(transformer_to_aeqd.transform(point.x, point.y))

        # 生成缓冲区
        buffer = point_transformed.buffer(self.buffer_distance)

        # 将缓冲区投影回 WGS84 坐标系
        buffer_wgs84 = self.transform_polygon(buffer,local_azimuthal_projection,wgs84)
        # buffer.transform(transformer_to_wgs84.transform))

        return buffer_wgs84

    # 车道线悬挂点检测
    def find_dangling_nodes(self):
        dangling_nodes = []
        # 创建 GeoDataFrame 的空间索引
        sindex = self.gdf.sindex

        for idx, line_a in enumerate(self.gdf.geometry):
            if isinstance(line_a, LineString):
                start_point_a = Point(line_a.coords[0])
                end_point_a = Point(line_a.coords[-1])
                
                start_point_a_buffer = self.prj_transform(start_point_a)
                end_point_a_buffer = self.prj_transform(end_point_a)

                # 查询与当前点缓冲区相交的其他线要素
                start_possible_matches_index = list(sindex.intersection(start_point_a_buffer.bounds))
                start_possible_matches = self.gdf.iloc[start_possible_matches_index]
                end_possible_matches_index = list(sindex.intersection(end_point_a_buffer.bounds))
                end_possible_matches = self.gdf.iloc[end_possible_matches_index]

                is_start_dangling = False
                is_end_dangling = False

                for _, line_b in start_possible_matches.iterrows():
                    if idx == line_b.name:  # 跳过自身
                        continue
                    elif line_b.geometry.intersects(start_point_a_buffer):
                        start_point_b = Point(line_b.geometry.coords[0])
                        end_point_b = Point(line_b.geometry.coords[-1])
                        if start_point_a != start_point_b and \
                                start_point_a != end_point_b and \
                                end_point_a != start_point_b  and \
                                end_point_a != end_point_b:
                            is_start_dangling = True
                            
                        elif end_point_b == start_point_a:
                            # logger.info(f"已找到与line_a正常挂接的line_b。start_point_a: {start_point_a.x,start_point_a.y};end_point_b: {end_point_b.x,end_point_b.y}")
                            is_start_dangling = False
                            break

                for _, line_b in end_possible_matches.iterrows():
                    if idx == line_b.name:  # 跳过自身
                        continue
                    elif line_b.geometry.intersects(end_point_a_buffer):
                        start_point_b = Point(line_b.geometry.coords[0])
                        end_point_b = Point(line_b.geometry.coords[-1])
                        if start_point_a != start_point_b and \
                                start_point_a != end_point_b and \
                                end_point_a != start_point_b  and \
                                end_point_a != end_point_b:
                            is_end_dangling = True
                            # logger.info(f"line_b: {line_b.geometry.wkt}")
                        elif start_point_b == end_point_a:
                            # logger.info(f"已找到与line_a正常挂接的line_b。end_point_a: {end_point_a.x,end_point_a.y};start_point_b: {start_point_b.x,start_point_b.y}")
                            is_end_dangling = False
                            break

                if is_start_dangling:
                    dangling_nodes.append(start_point_a)
                    # logger.info(f"line_start_dangling_point:{start_point_a.x},{start_point_a.y}")
                    # logger.info(f"line_a: {line_a.wkt}")
                if is_end_dangling:
                    dangling_nodes.append(end_point_a)
                    # logger.info(f"line_end_dangling_point: {end_point_a.x},{end_point_a.y}")
                    # logger.info(f"line_a: {line_a.wkt}")
                    
        # if len(dangling_nodes) != 0:
        #     dangling_gdf = gpd.GeoDataFrame(geometry=dangling_nodes, crs=self.gdf.crs)
        #     dangling_gdf.to_file(output_gpkg, layer="lane_boundary_dangling_nodes", driver="GPKG")
        return dangling_nodes

    # 车道线前驱后继检测
    def validate_predecessor_successor(self):
        result = {
            'successes': [],
            'errors': [],
            'intersecting_ids': []
        }

        def validate_relation(current_id, current_point, related_id_list, related_type, buffer):
            """
            验证当前要素与其前驱或后继要素之间的几何关系。

            :param current_id: 当前要素的 ID
            :param current_point: 当前要素的端点（起点或终点）
            :param related_id: 前驱或后继要素的 ID
            :param related_type: 'predecessor' 或 'successor'
            :param buffer: 当前端点的缓冲区
            """
            # 创建空间索引（如果尚未创建）
            if not hasattr(self.gdf, 'sindex'):
                self.gdf.sindex  # 创建空间索引

            if related_id_list is not None:
                # 查询相关要素
                related_ids = related_id_list.split(',')
                for related_id in related_ids:
                    related_row = self.gdf[self.gdf['ID'] == related_id]
                    if not related_row.empty:
                        related_geom = related_row.geometry.iloc[0]
                        # 根据相关类型获取相关要素的端点
                        related_point = Point(related_geom.coords[-1]) if related_type == 'predecessor' else Point(
                            related_geom.coords[0])
                        # 检查几何关系
                        if current_point == related_point:
                            result['successes'].append(
                                f"要素 {current_id} 与 {related_id} 要素属性与几何拓扑挂接无误。")
                        elif not buffer.contains(related_point):
                            result['errors'].append(
                                f"要素 {current_id} 的 {related_type} 关系错误：{related_id} 要素的端点未连接到该要素的端点。")
                    else:
                        result['errors'].append(f"要素 {current_id} 的 {related_type} 要素 {related_id} 不存在。")
            else:
                # 如果没有相关 ID，使用空间索引查询缓冲区内的相交要素
                possible_matches_index = list(self.gdf.sindex.intersection(buffer.bounds))
                possible_matches = self.gdf.iloc[possible_matches_index]

                # 进一步筛选实际相交的要素，并排除自身
                intersecting_ids = possible_matches[
                    (possible_matches.geometry.intersects(buffer)) &
                    (possible_matches['ID'] != current_id)  # 排除自身
                    ]['ID'].tolist()
                if intersecting_ids != []:
                    result['intersecting_ids'].append(dict([(current_id,intersecting_ids)]))

        for idx, row in self.gdf.iterrows():
            current_geom = row.geometry
            present_id = row['ID']
            predecessor_id = row['PRE_ID']
            successor_id = row['NEXT_ID']
            start_point = Point(current_geom.coords[0])
            end_point = Point(current_geom.coords[-1])
            start_buffer = self.prj_transform(start_point)
            end_buffer = self.prj_transform(end_point)

            # 验证前驱关系
            validate_relation(present_id, start_point, predecessor_id, 'predecessor', start_buffer)

            # 验证后继关系
            validate_relation(present_id, end_point, successor_id, 'successor', end_buffer)

        return result

    # 结果打包gpkg输出
    def save_results_to_geopackage(self, intersections, intersection_points, dangling_nodes, result,
                                   output_gpkg="validation_results.gpkg"):
        """
        将验证结果保存为一个 GeoPackage 文件，并将相关信息写入属性表。

        :param intersections: 交叉车道线要素集合
        :param intersection_points: 交叉点要素集合
        :param dangling_nodes：悬挂节点要素集合
        :param result: 包含验证结果的字典
        :param output_gpkg: 输出的 GeoPackage 文件名
        """
        # 创建 GeoDataFrame 用于保存错误结果
        if len(intersections) != 0:
            # logger.info("检测出当前车道线存在异常相交，保存异常交叉线要素至：lane_boundary_intersections")
            intersections_gdf = self.gdf.iloc[list(intersections)]
            intersections_gdf.to_file(output_gpkg, layer="lane_boundary_intersections", driver="GPKG")

        if len(intersection_points) != 0:
            # logger.info("检测出当前车道线存在异常相交，保存异常交点至：lane_boundary_intersection_points")
            intersection_points_gdf = gpd.GeoDataFrame(geometry=intersection_points, crs=self.gdf.crs)
            intersection_points_gdf.to_file(output_gpkg, layer="lane_boundary_intersection_points", driver="GPKG")
        
        if len(dangling_nodes) != 0:
            dangling_gdf = gpd.GeoDataFrame(geometry=dangling_nodes, crs=self.gdf.crs)
            dangling_gdf.to_file(output_gpkg, layer="lane_boundary_dangling_nodes", driver="GPKG")
        # 保存交叉点图层
        # logger.info("参考图层——保存被检测车道线要素至：lane_boundary_input")
        self.gdf.to_file(output_gpkg,layer="lane_boundary_input",driver="GPKG")

        if len(result['errors']) != 0:
            # logger.info("检测前驱后继属性挂接错误车道线，保存异常线要素至：lane_boundary_attributes_errors")
            errors_data = []
            for msg in result['errors']:
                id = msg.split()[1]  # 提取 ID
                message = msg
                geometry = self.gdf[self.gdf['ID'] == id].geometry.iloc[0]  # 获取对应的几何对象
                errors_data.append({'ID': id, 'Message': message, 'geometry': geometry})

            errors_gdf = gpd.GeoDataFrame(errors_data, crs=self.gdf.crs)
            errors_gdf.to_file(output_gpkg, layer="lane_boundary_attributes_errors", driver="GPKG")

        if len(result['intersecting_ids']) != 0:
            # logger.info("检测出疑似应挂接但未挂接前驱后继车道线，保存异常线要素至：lane_boundary_missing_attributes")
            # 创建 GeoDataFrame 用于保存相交 ID 结果
            intersecting_data = []
            for item in result['intersecting_ids']:
                id = list(item.keys())[0]
                intersecting_ids = item[id]
                geometry = self.gdf[self.gdf['ID'] == id].geometry.iloc[0]  # 获取对应的几何对象
                intersecting_data.append({'ID': id, 'IntersectingIDs': intersecting_ids, 'geometry': geometry})
            intersecting_gdf = gpd.GeoDataFrame(intersecting_data, crs=self.gdf.crs)
            intersecting_gdf.to_file(output_gpkg, layer="lane_boundary_missing_attributes", driver="GPKG")

def json2csv(output_path, json_file_path):
    with open(json_file_path, 'r', encoding='utf-8') as f:
        json_data = json.load(f)

    csv_file_name = f"{json_data['version']}_{json_data['elapsed_time']}.csv"
    csv_file_path = os.path.join(output_path, csv_file_name)
    # 解析JSON数据，提取result部分
    results = json_data['result']

    # 获取所有评估类型
    first_batch = next(iter(json_data["result"].items()))[1]
    all_eval_types = first_batch.keys()

    # 准备 CSV 文件头
    csv_headers = ["算法框ID"]

    # 添加评估类型到文件头
    for eval_type in all_eval_types:
        csv_headers.append(eval_type)

    # 写入 CSV 文件
    with open(csv_file_path, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile, quoting=csv.QUOTE_NONNUMERIC)
        writer.writerow(csv_headers)

        # 遍历结果数据
        for algo_box, evaluations in results.items():
            row = [algo_box]
            for eval_type in all_eval_types:
                eval_data = evaluations.get(eval_type, {})
                row.append(eval_data)
                
            writer.writerow(row)
    
    print(f"CSV 文件 {csv_file_name} 已生成。")


if __name__ == "__main__":
    input_file_path = r'E:\geoeva_v2.0\data\input\3.6.5_prod_shp_result'
    output_data_path = r'E:\geoeva_v2.0\data\topo_test_0523'
    file_path_split = input_file_path.split('\\')
    version = file_path_split[-2]+'_'+file_path_split[-1]
    distance_threshold = 1.5
    folders = os.listdir(input_file_path)
    laneline_topo_result_dict = {
        "version": version,
        "elapsed_time": 0,
        "result": {}
    }
    overall_start = time.perf_counter()
    for algo_box in folders:
        if not algo_box.endswith('.zip'):
            input_data_path = os.path.join(input_file_path,algo_box,"export_to_shp")
            laneline_topo_result_dict["result"][algo_box] = {}
            output_path = os.path.join(output_data_path,version)
            os.makedirs(output_path, exist_ok=True)
            output_gpkg = os.path.join(output_path,str(version) + '_' + str(algo_box) + "_line_topo.gpkg")
            laneline_topo_reault = LaneLineTopoCheck(input_data_path,distance_threshold,output_gpkg)
            laneline_topo_result_dict['result'][algo_box].update(laneline_topo_reault.get_dict())
    elapsed_time = time.perf_counter() - overall_start
    laneline_topo_result_dict['elapsed_time'] = f"{elapsed_time:.2f}s"
    task_json_file = os.path.join(output_data_path,
                                        laneline_topo_result_dict['version'] + '_' + datetime.now().strftime("%Y-%m-%d_%H%M%S") + '.json')
    with open(task_json_file, 'w', encoding='utf-8') as f:
                json.dump(laneline_topo_result_dict, f, ensure_ascii=False, indent=4)
    
    # task_json_file = r'E:\geoeva_v2.0\data\output0509_2\v3.05.01_mmt_bev_2025-05-09_174108.json'
    # output_path = r'E:\geoeva_v2.0\data\output0509_2'
    
    json2csv(output_path,task_json_file)