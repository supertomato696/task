from shapely.geometry import LineString
from shapely import BufferCapStyle
import matplotlib.pyplot as plt
import numpy as np

# 创建一条线
line = LineString([(0, 0), (4, 0)])

# 定义缓冲距离
buffer_distance = 1

# 使用不同的 cap_style 创建缓冲区
buffered_line_square = line.buffer(buffer_distance, cap_style=BufferCapStyle.square)
buffered_line_flat = line.buffer(buffer_distance, cap_style=BufferCapStyle.flat)

# 绘制原始线
x, y = line.xy
plt.plot(x, y, color='black', linewidth=2, label='Original Line')

# 绘制缓冲区
# 获取缓冲区的边界（Polygon 的 exterior）
x_square, y_square = buffered_line_square.exterior.xy
x_flat, y_flat = buffered_line_flat.exterior.xy

# 填充缓冲区
plt.fill(x_square, y_square, color='red', alpha=0.3, label='BufferCapStyle.square')
plt.fill(x_flat, y_flat, color='blue', alpha=0.3, label='BufferCapStyle.flat')

# 设置图例和标题
plt.legend()
plt.title('Buffer with Different Cap Styles')
plt.xlim(-1, 5)
plt.ylim(-2, 2)
plt.gca().set_aspect('equal', adjustable='box')  # 保持比例
plt.show()