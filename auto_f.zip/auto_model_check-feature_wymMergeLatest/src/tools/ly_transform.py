# -*- coding: utf-8 -*-
import os
import geopandas as gpd
from shapely.affinity import translate
import geopandas as gpd
from shapely.ops import transform
from pyproj import CRS, Transformer
from shapely import Point,  Polygon, GeometryCollection, LineString, MultiLineString, MultiPolygon
# from src.data_process.file_read import remove_z
# from src.tools.common import ensure_single_geometries

file_root = r'E:\geoeva_v2.0\data\truth\era05'
out_file_root = r'E:\geoeva_v2.0\data\truth\era21'
dx = 0.00000543
dy = -0.0000015

folder_list =  os.listdir(file_root)
for folder in folder_list:
    file_list = os.listdir(os.path.join(file_root,folder))
    for file in file_list:
        if file.endswith('.shp'):
            file_path = os.path.join(file_root,folder,file)
            out_file_path = os.path.join(out_file_root,folder)
            if not os.path.exists(out_file_path):
                os.makedirs(out_file_path)
            gdf = gpd.read_file(file_path)
            print(gdf['geometry'])
            gdf['geometry'] = gdf['geometry'].apply(lambda geom: translate(geom, xoff=dx, yoff=dy))
            print(gdf['geometry'])
            gdf.to_file(os.path.join(out_file_path,file))

# def check_all_instance(gdf: gpd.GeoDataFrame) -> bool:
#     """Checks if all geometries in a GeoDataFrame are LineStrings using isinstance."""
#     if gdf.empty:
#         return True
#     return gdf.geometry.apply(lambda geom: isinstance(geom, (LineString, Polygon,Point))).all()

# def ensure_single_geometries(gdf) -> gpd.GeoDataFrame:
#     """
#     将 GeoDataFrame 中的几何对象转换为单一的 Polygon 和 LineString。

#     :param gdf: GeoDataFrame, 包含可能的 MultiPolygon 和 MultiLineString 几何对象
#     :return: GeoDataFrame, 仅包含 Polygon 和 LineString，保留原始属性和CRS
#     """

#     # 使用 explode 方法分解复杂几何
#     # 使用 explode(index_parts=False) 分解 MultiPolygon 和 MultiLineString 对象。index_parts=False 可以保持原始索引而不分解为多层索引。
#     exploded_gdf = gdf.explode(index_parts=False)

#     # 创建新的几何列表和属性列表
#     single_geometries = []
#     attributes = []

#     for idx, row in exploded_gdf.iterrows():
#         geom = row['geometry']
#         if isinstance(geom, (MultiPolygon, MultiLineString)):
#             for part in geom:
#                 # 对于每个分解后的几何对象，保留原始行的属性值（去除 geometry 列），并将单一几何对象附加到 single_geometries 列表
#                 single_geometries.append(part)
#                 attributes.append(row.drop('geometry'))
#         elif isinstance(geom, (Polygon, LineString,Point)):
#             single_geometries.append(geom)
#             attributes.append(row.drop('geometry'))

#     # 创建新的 GeoDataFrame，一次性添加所有行.设置几何列为活动几何列.
#     final_gdf = gpd.GeoDataFrame(attributes, geometry=single_geometries)

#     # 重置索引
#     final_gdf.reset_index(drop=True, inplace=True)

#     # 赋予新的 GeoDataFrame 原始 CRS
#     final_gdf.crs = gdf.crs

#     if check_all_instance(final_gdf):
#         return final_gdf
#     else:
#         final_gdf = ensure_single_geometries(final_gdf)   


# def remove_z(geometry):
#     """
#     忽视几何对象的Z坐标，只返回XY坐标。

#     :param geometry: 输入的几何对象（LineString、Polygon、Point或GeometryCollection）。
#     :return: 忽略Z坐标后的几何对象。
#     """
#     if isinstance(geometry, LineString):
#         if geometry.has_z:
#             return LineString([(x, y) for x, y, z in geometry.coords])
#         return geometry

#     elif isinstance(geometry, MultiLineString):
#         if geometry.has_z:
#             return MultiLineString([[(x, y) for x, y, z in line.coords] for line in geometry.geoms])
#         return geometry

#     elif isinstance(geometry, Polygon):
#         if geometry.has_z:
#             exterior = [(x, y) for x, y, z in geometry.exterior.coords]
#             interiors = [[(x, y) for x, y, z in ring.coords] for ring in geometry.interiors]
#             return Polygon(exterior, interiors)
#         return geometry

#     elif isinstance(geometry, Point):
#         if geometry.has_z:
#             return Point(geometry.x, geometry.y)
#         return geometry

#     elif isinstance(geometry, GeometryCollection):
#         # 处理几何集合，递归调用
#         return GeometryCollection([remove_z(geom) for geom in geometry.geoms])

#     else:
#         raise TypeError("Unsupported geometry type: {}".format(type(geometry)))

# # 1) 定义源/目标 CRS，带 epoch 标记
# crs_src = CRS.from_proj4(
#     "+proj=longlat +datum=WGS84 +no_defs +type=crs +epoch=2005.0"
# )
# crs_dst = CRS.from_proj4(
#     "+proj=longlat +datum=WGS84 +no_defs +type=crs +epoch=2021.0"
# )

# # 2) 构造 Transformer（内部用 PROJ 速度模型）
# transformer = Transformer.from_crs(crs_src, crs_dst, always_xy=True)

# # 4) 对 geometry 做坐标转换
# def shift_geom(geom):
#     # transformer.transform(x,y) 会自动加上 Δt×V
#     return transform(lambda x, y: transformer.transform(x, y), geom)


# file_list = os.listdir(file_root)
# for file in file_list:
#     if file.endswith('.shp'):
#         file_path = os.path.join(file_root,file)
#         out_file_path = os.path.join(out_file_root,file)
#         gdf = ensure_single_geometries(gpd.read_file(file_path))
#         gdf['geometry'] = gdf['geometry'].apply(remove_z)
#         gdf['geometry'] = gdf.geometry.apply(shift_geom)
#         gdf.to_file(out_file_path)
