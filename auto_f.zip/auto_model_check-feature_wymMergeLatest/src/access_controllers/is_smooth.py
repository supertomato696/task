# -*- coding: utf-8 -*-
# @Time    : 2025/3/1 17:03
# @Author  : StephenLeung
# @Email   : liang.yuhao1@byd.com
# @File    : is_smooth.py
"""
  本工具用于车道平滑性评测。整个流程中数据流设定为GeoDataFrame，
  车道线的平滑性进行分析并生成统计结果与问题点。
  评测结果分别导出为：
    1. 统计信息result.json文件（不带几何）；
    2. 问题点flaws.geojson文件（GeoDataFrame直接转的）。
"""

import json
from src.logger import logger
import traceback
import math
from math import floor

import geopandas as gpd
from geopandas import GeoDataFrame
from shapely.geometry import Point
from pydantic import BaseModel, Field


# ------------------------------------------------------------------------------
# Pydantic 数据模型
# ------------------------------------------------------------------------------

class SmoothnessStatistics(BaseModel):
    """
    平滑度评测统计信息模型
    """
    total_lines: int = Field(..., description="总车道线数量")
    smooth_lines: int = Field(..., description="平滑车道线数量")
    smooth_line_ratio: float = Field(..., description="平滑车道线比例")
    total_length: float = Field(..., description="车道线总长度（m）")
    smooth_length: float = Field(..., description="平滑车道线总长度（m）")
    smooth_length_ratio: float = Field(..., description="平滑长度比例")


class SmoothnessEvaResult(BaseModel):
    """
    平滑度评测结果模型
      - statistics: 统计信息（数据类型为Pydantic模型）
      - flaws: 问题点（保存为 GeoDataFrame，可直接导出为 GeoJSON）
    """
    statistics: SmoothnessStatistics = Field(..., description="平滑性统计信息")
    flaws: GeoDataFrame = Field(..., description="问题点GeoDataFrame")

    class Config:
        arbitrary_types_allowed = True


# ------------------------------------------------------------------------------
# CRS 与几何处理函数
# ------------------------------------------------------------------------------

def calculate_utm_zone(gdf: gpd.GeoDataFrame) -> str:
    """
    更健壮的 UTM 带计算。使用 gdf.unary_union 计算所有几何的合并中心。
    参数:
        gdf: 输入 GeoDataFrame
    返回:
        EPSG 编号字符串，如 "EPSG:32633"
    """
    try:
        centroid = gdf.unary_union.centroid
        lon = centroid.x
        lat = centroid.y

        # UTM 带计算逻辑
        utm_zone = int(floor((lon + 180) / 6) + 1)
        northern = lat >= 0
        epsg_code = 32600 + utm_zone if northern else 32700 + utm_zone

        # 验证 EPSG 代码有效性：构造空 GeoDataFrame 并设置 CRS
        test_crs = f"EPSG:{epsg_code}"
        tmp = gpd.GeoDataFrame(geometry=[Point(0, 0)])
        tmp.set_crs(test_crs, inplace=True)
        logger.debug(f"计算得到 UTM 带 CRS：{test_crs}")
        return test_crs
    except Exception as e:
        logger.error(f"UTM 带计算失败: {e}", exc_info=True)
        return "EPSG:3857"  # 回退至 Web Mercator


def handle_crs(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """
    坐标系处理逻辑：
      1. 如果数据没有定义crs，则假设为84(实际上是02)，坐标系转换挖了好多坑；
      2. 如果crs不是投影坐标系，则尝试转成墨卡托；
         如失败则使用自定义等距圆锥投影，仍失败则使用墨卡托
    参数:
        gdf: 的输入GeoDataFrame
    返回:
        投影后的GeoDataFrame
    """
    if gdf.crs is None:
        logger.debug("数据未定义坐标系，假设为 WGS84")
        gdf = gdf.set_crs("EPSG:4326")

    if not gdf.crs.is_projected:
        logger.debug("非投影坐标系，正在尝试转换...")
        # 尝试 UTM 转换
        target_crs = calculate_utm_zone(gdf)
        try:
            gdf_proj = gdf.to_crs(target_crs)
            logger.debug(f"成功转换为 {target_crs}")
            return gdf_proj
        except Exception as e:
            logger.error(f"UTM 转换失败: {e}", exc_info=True)
            # 回退方案：使用等距圆锥投影
            try:
                centroid = gdf.unary_union.centroid
                custom_crs = f"+proj=eqc +lat_ts={centroid.y} +lon_0={centroid.x}"
                logger.debug(f"尝试使用自定义投影: {custom_crs}")
                return gdf.to_crs(custom_crs)
            except Exception as e2:
                logger.error(f"自定义投影失败，使用 Web Mercator: {e2}", exc_info=True)
                return gdf.to_crs("EPSG:3857")
    return gdf


def get_this_file_ready(file_path: str) -> gpd.GeoDataFrame:
    """
    读取并处理车道线文件：
      - 读取 shapefile 文件；
      - 数据清洗（排除空几何、非线要素）；
      - 坐标转换保证单位为米（适合距离计算）。

    参数:
        file_path: shapefile 文件路径

    返回:
        处理后的 GeoDataFrame，如读取或转换失败则返回 None
    """
    try:
        gdf = gpd.read_file(file_path)
    except Exception as e:
        logger.exception(f"读取 shapefile 失败: {e}", exc_info=True)
        raise UserWarning(f"读取 shapefile 失败: {e}")

    logger.debug("正在进行数据清洗...")
    gdf = gdf[gdf.geometry.notnull()].copy()
    valid_types = ['LineString', 'MultiLineString']
    gdf = gdf[gdf.geometry.type.isin(valid_types)].copy()

    # 坐标系处理与转换
    gdf = handle_crs(gdf)

    return gdf


# ---------------------------
# 曲率和角度计算函数
# ---------------------------
def calculate_curvature(points, idx):
    """
    计算三个相邻点间的曲率（以弧度/米为单位）。
    端点无法计算曲率，返回0.0
    """
    if idx == 0 or idx == len(points) - 1:
        return 0.0

    p1, p2, p3 = points[idx - 1], points[idx], points[idx + 1]

    # 两个向量
    v1 = [p2[0] - p1[0], p2[1] - p1[1]]
    v2 = [p3[0] - p2[0], p3[1] - p2[1]]

    len_v1 = math.hypot(*v1)
    len_v2 = math.hypot(*v2)

    if len_v1 < 1e-6 or len_v2 < 1e-6:
        return 0.0

    # 计算单位向量
    v1_unit = [v1[0] / len_v1, v1[1] / len_v1]
    v2_unit = [v2[0] / len_v2, v2[1] / len_v2]

    # 点积计算余弦值，并限制范围避免数值误差
    cos_angle = max(min(v1_unit[0] * v2_unit[0] + v1_unit[1] * v2_unit[1], 1.0), -1.0)
    angle = math.acos(cos_angle)
    curvature = angle / ((len_v1 + len_v2) / 2)

    return curvature


def calculate_angle(points, idx):
    """
    计算三点形成的折角（单位：度）。
    端点无法计算折角，返回0.0
    """
    if idx == 0 or idx == len(points) - 1:
        return 0.0

    p1, p2, p3 = points[idx - 1], points[idx], points[idx + 1]

    v1 = [p2[0] - p1[0], p2[1] - p1[1]]
    v2 = [p3[0] - p2[0], p3[1] - p2[1]]

    len_v1 = math.hypot(*v1)
    len_v2 = math.hypot(*v2)

    if len_v1 < 1e-6 or len_v2 < 1e-6:
        return 0.0

    v1_unit = [v1[0] / len_v1, v1[1] / len_v1]
    v2_unit = [v2[0] / len_v2, v2[1] / len_v2]

    cos_angle = max(min(v1_unit[0] * v2_unit[0] + v1_unit[1] * v2_unit[1], 1.0), -1.0)
    angle_deg = math.degrees(math.acos(cos_angle))
    return angle_deg


def is_small_fluctuation(points, idx, threshold_cm=2.0):
    """
    检查是否为微小波动（默认阈值：2厘米）。
    当p1与p3重合时，视为平滑。
    """
    if idx <= 0 or idx >= len(points) - 1:
        return True

    p1, p2, p3 = points[idx - 1], points[idx], points[idx + 1]

    if abs(p1[0] - p3[0]) < 1e-6 and abs(p1[1] - p3[1]) < 1e-6:
        return True

    a = p3[1] - p1[1]
    b = p1[0] - p3[0]
    c = p3[0] * p1[1] - p1[0] * p3[1]

    try:
        dist = abs(a * p2[0] + b * p2[1] + c) / math.sqrt(a ** 2 + b ** 2)
    except ZeroDivisionError:
        logger.debug("计算直线距离除以零，返回平滑")
        return True

    dist_cm = dist * 100  # 转换为厘米
    return dist_cm <= threshold_cm


# ------------------------------------------------------------------------------
# 基础评测类定义
# ------------------------------------------------------------------------------
class BaseAccessController:
    ...


# ------------------------------------------------------------------------------
# 丝滑度统计
# ------------------------------------------------------------------------------
class BaseSmoothnessEvaluator(BaseAccessController):

    @staticmethod
    def analyze_lane_smoothness(gdf: gpd.GeoDataFrame) -> SmoothnessEvaResult:
        """
        对每条线计算曲率、角度，检查是否超过阈值
        构造问题点GeoDataFrame记录（附带 is_flaw 标记和分析原因）
        同时累计统计平滑线条和长度信息。
        """

        total_lines = 0
        smooth_lines = 0
        total_length = 0.0
        smooth_length = 0.0

        # 收集每条车道线的检测结果
        lines_details = []
        # 专门用于存储所有问题点的记录
        problem_points_records = []

        for idx, row in gdf.iterrows():
            geometry = row.geometry
            line_id = row['line_id'] if 'line_id' in row else str(idx)

            # 针对 MultiLineString 分段处理
            if geometry.geom_type == 'MultiLineString':
                segments = list(geometry.geoms)
            elif geometry.geom_type == 'LineString':
                segments = [geometry]
            else:
                continue  # 非线性几何直接略过

            for seg_idx, seg in enumerate(segments):
                total_lines += 1
                line_coords = list(seg.coords)
                line_length = seg.length
                total_length += line_length
                line_is_smooth = True
                line_problem_points = []

                # 对除端点外的每个中间节点进行判断
                for i in range(1, len(line_coords) - 1):
                    # 调用实际检测函数，这里的函数需要你实现
                    curvature = calculate_curvature(line_coords, i)
                    angle = calculate_angle(line_coords, i)

                    ## 这里做了一个是否微小波动的函数。视情况打开，暂时注释掉
                    # is_small_fluc = is_small_fluctuation(line_coords, i, threshold_cm=2.0)

                    has_problem = False
                    reasons = []
                    if curvature > 0.5:  # 设定阈值
                        has_problem = True
                        reasons.append(f"曲率过大: {curvature:.4f}")
                    if angle > 30:
                        has_problem = True
                        reasons.append(f"折角过大: {angle:.2f}°")

                    if has_problem:
                        line_is_smooth = False
                        # 记录具体问题点信息（可包含更多信息）
                        problem_info = {
                            "relate_line_id": f"{line_id}_{seg_idx}",
                            "point_idx": i,
                            # "coords": line_coords[i],
                            "curvature": curvature,
                            "angle": angle,
                            "reasons": reasons,
                            "geometry": Point(line_coords[i])
                        }
                        line_problem_points.append(problem_info)
                        problem_points_records.append(problem_info)

                if line_is_smooth:
                    smooth_lines += 1
                    smooth_length += line_length

                lines_details.append({
                    "line_id": f"{line_id}_{seg_idx}",
                    "is_smooth": line_is_smooth,
                    "length": line_length,
                    "points_count": len(line_coords),
                    "problem_points": line_problem_points,
                    # "coordinates": line_coords,
                })

        # 生成统计信息数据结构
        statistics_dict = {
            "total_lines": total_lines,
            "smooth_lines": smooth_lines,
            "smooth_line_ratio": smooth_lines / total_lines if total_lines else 0,
            "total_length": total_length,
            "smooth_length": smooth_length,
            "smooth_length_ratio": smooth_length / total_length if total_length else 0,
            # "lines_details": lines_details
        }

        # 创建 Pydantic 模型对象（假设 SmoothnessStatistics 的字段和上面的字典保持一致）
        statistics_obj = SmoothnessStatistics(**statistics_dict)

        # 构造异常点 GeoDataFrame，无论是否存在问题点，我们均返回一个空的或非空的 GeoDataFrame
        if problem_points_records:
            flaws_gdf = gpd.GeoDataFrame(problem_points_records, geometry="geometry", crs=gdf.crs)
        else:
            # 返回一个空的 GeoDataFrame，字段与记录保持一致
            flaws_gdf = gpd.GeoDataFrame(
                columns=["relate_line_id", "point_idx", "curvature", "angle", "reasons", "geometry"],
                crs=gdf.crs)

        eva_result = SmoothnessEvaResult(
            statistics=statistics_obj,
            flaws=flaws_gdf
        )

        return eva_result

    # ------------------------------------------------------------------------------
    # 结果导出
    # ------------------------------------------------------------------------------
    @staticmethod
    def export_results_to_json(results: dict, stat_output_file: str, geojson_output_file: str) -> SmoothnessEvaResult:
        """
        导出分析结果：
          1. 将统计信息部分保存为不带几何的纯 JSON 文件；
          2. 将问题点保存为 GeoJSON 文件，问题点数据由 GeoDataFrame 提供；
          3. 返回 SmoothnessEvaResult 对象，包含统计信息和 GeoDataFrame 类型的 flaws。

        参数:
            results: 分析结果字典（由 analyze_lane_smoothness 返回）
            stat_output_file: 统计信息 JSON 文件路径
            geojson_output_file: 问题点 GeoJSON 文件路径

        返回:
            SmoothnessEvaResult 对象
        """
        # ---------- 导出统计信息 JSON ----------
        statistics_dict = results["statistics"]
        pure_stat_result = {"statistics": statistics_dict}

        try:
            with open(stat_output_file, "w", encoding="utf-8") as f:
                json.dump(pure_stat_result, f, ensure_ascii=False, indent=2)
            logger.info(f"统计信息已成功导出至 {stat_output_file}")
        except Exception as e:
            logger.error("导出统计信息 JSON 失败: %s\n%s", str(e), traceback.format_exc())

        # ---------- 处理问题点并构造 GeoDataFrame ----------
        flaws_records = []
        for line in results["lines_details"]:
            line_id = line.get("line_id", "")
            for point in line["problem_points"]:
                analyze_text = "\n".join(point.get("reasons", []))
                coords = point["coords"]
                record = {
                    "line_id": line_id,
                    "point_idx": point.get("point_idx"),
                    "analyze": analyze_text,
                    "coords": coords,  # 原始坐标信息
                    "geometry": Point(coords)
                }
                flaws_records.append(record)

        if flaws_records:
            flaws_gdf = gpd.GeoDataFrame(flaws_records, geometry="geometry", crs="EPSG:4326")
        else:
            flaws_gdf = gpd.GeoDataFrame(columns=["line_id", "point_idx", "analyze", "coords", "geometry"],
                                         crs="EPSG:4326")

        try:
            flaws_gdf.to_file(geojson_output_file, driver="GeoJSON")
            logger.info(f"问题点 GeoJSON 已成功导出至 {geojson_output_file}")
        except Exception as e:
            logger.error("导出问题点 GeoJSON 失败: %s\n%s", str(e), traceback.format_exc())

        eva_result = SmoothnessEvaResult(
            statistics=SmoothnessStatistics(**statistics_dict),
            flaws=flaws_gdf
        )
        return eva_result

    @staticmethod
    def save_results(eva_result: SmoothnessEvaResult, output_stats_file: str,
                     output_flaws_file: str) -> SmoothnessEvaResult:
        """
        将 SmoothnessEvaResult 保存为 json 文件：
          - 统计信息保存为 JSON 文件；
          - 问题点数据保存为 GeoJSON 文件。

        返回:
            传入的 SmoothnessEvaResult 对象
        """
        # 统计信息写入 JSON 文件
        with open(output_stats_file, 'w', encoding='utf-8') as f:
            json.dump(eva_result.statistics.dict(), f, ensure_ascii=False, indent=4)
        logger.debug(f"统计信息写入完毕:{output_stats_file}")
        # 问题点位写入 GeoJSON 文件
        eva_result.flaws.to_file(output_flaws_file, driver="GeoJSON")
        logger.debug(f"缺陷点位geojson写入完毕:{output_flaws_file}")

        return eva_result


# ------------------------------------------------------------------------------
# 主函数入口
# ------------------------------------------------------------------------------

def main():
    """
    主函数：
      - 读取或构造示例车道线 GeoDataFrame；
      - 利用 BaseSmoothnessEvaluator 进行平滑性分析；
      - 导出统计信息 JSON 与问题点 GeoJSON；
      - 输出最终评测结果（包含 Pydantic 模型及 GeoDataFrame）。
    """
    # 如果有输入文件路径则调用 get_this_file_ready，否则构造示例数据
    sample_shapefile = "./road_boundary_vectorize.shp"  # 设置你的文件路径，例如 "data/lanes.shp"
    gdf = get_this_file_ready(sample_shapefile)

    # 实例化评测器并执行评测
    results = BaseSmoothnessEvaluator().analyze_lane_smoothness(gdf)

    # 定义导出文件路径
    stats_file_path = "result.json"
    flaws_file_path = "flaws.geojson"

    BaseSmoothnessEvaluator().save_results(results, stats_file_path, flaws_file_path)

    logger.info(results.statistics)


if __name__ == "__main__":
    main()
