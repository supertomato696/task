import os
from typing import Union, List, Dict, Set, Tuple, Optional
import matplotlib.pyplot as plt
from geopandas import GeoDataFrame
from src.logger import logger
from shapely import Polygon,Point
from shapely.affinity import scale
from pydantic import BaseModel, Field
from src.geom_evaluators.evaluator_base import EvaluatorBase

class LightEvaluateResult(BaseModel):
    title: str = None
    buffer_distance: float = 0
    accuracy: float = Field(title="准确率", description="准确率Precision = TP/(TP+FP)")
    precision: float = Field(title="精准率")
    recall: float = Field(title="召回率")
    match_result: Dict[Point, List[Point]] = {}
    unmatched_input_list: List[Point] = []
    truth_matched_cnt: int = 0
    truth_unmatched_cnt: int = 0
    input_matched_cnt: int = 0
    input_unmatched_cnt: int = 0

    @property
    def f1_score(self) -> float:
        """
        计算F1分数，综合考虑精准率和召回率。

        :return: float F1分数
        """
        return 2 * (self.precision * self.recall) / (self.precision + self.recall) if (self.precision + self.recall) > 0 else 0

    @property
    def format_text(self) -> str:
        stats_text = (
            f"准确率: {self.accuracy * 100:.2f}%\n"
            f"召回率: {self.recall * 100:.2f}%\n"
            f"F1分数: {self.f1_score: .4f}\n"
            f"已匹配真值数量: {self.truth_matched_cnt}\n"
            f"未匹配真值数量: {self.truth_unmatched_cnt}\n"
            f"已匹配输入值数量: {self.input_matched_cnt}\n"
            f"未匹配输入值数量: {self.input_unmatched_cnt}\n"
        )
        return stats_text

    class Config:
        arbitrary_types_allowed = True  # 允许任意类型的字段


class TrafficlightEvaluator(EvaluatorBase):
    def __init__(self,
                 truth_light_file_path=None,
                 input_light_file_path=None,
                 truth_gdf: GeoDataFrame = None,
                 input_gdf: GeoDataFrame = None,
                 truth_data_filter_conditions: dict = None,
                 input_data_filter_conditions: dict = None,
                 global_rect: Polygon = None,
                 convex_hull: Union[Polygon, str] = None,
                 reference_material_file_path=None,
                 reference_material_gdf: GeoDataFrame = GeoDataFrame(columns=['geometry']),
                 reference_material_filter_conditions: dict = None):
        """
        信号灯评测类，用于评测输入的信号灯与真值数据之间的匹配关系。

        :param truth_light_file_path: 真值信号灯文件路径。
        :param input_light_file_path: 输入信号灯文件路径。
        :param truth_data_filter_conditions: 真值数据的过滤条件（可选）。
        :param input_data_filter_conditions: 输入数据的过滤条件（可选）。
        :param global_rect: 全局的范围框，优先级高于凸包（可选）。
        :param convex_hull: 用于计算的凸包（可选）。
        :param reference_material_file_path: 参考材料文件路径（可选）。
        :param reference_material_filter_conditions: 参考材料的过滤条件（可选）。
        """

        # 初始化父类
        super().__init__(truth_file_path=truth_light_file_path,
                         input_file_path=input_light_file_path,
                         truth_gdf=truth_gdf,
                         input_gdf=input_gdf,
                         truth_data_filter_conditions=truth_data_filter_conditions,
                         input_data_filter_conditions=input_data_filter_conditions,
                         global_rect=global_rect,
                         convex_hull=convex_hull,
                         reference_material_file_path=reference_material_file_path,
                         reference_material_gdf=reference_material_gdf,
                         reference_material_filter_conditions=reference_material_filter_conditions)

        # 获取真值信号灯和输入信号灯的GeoDataFrame
        self.truth_light_gdf = self.truth_data_gdf
        self.input_light_gdf = self.pruned_input_gdf

    def match_object(self, buffer_distance=2):
        """
        匹配输入信号灯与真值信号灯，利用缓冲区检查它们是否相交。

        :param buffer_distance: 缓冲区半径，用于扩展真值信号灯进行匹配。
        :return: 返回匹配结果和未匹配的输入信号灯。
        """
        match_result: Dict[Point] = {}
        used_input_trafficlights:Set[Point] = set()  # 存储已使用的输入信号灯以防重复匹配

        # 计算每个真值信号灯几何体的质心和缓冲区
        self.truth_light_gdf['buffer_area'] = self.truth_light_gdf.buffer(buffer_distance)

        # 对每个真值信号灯的缓冲区进行遍历
        for truth_light_buffer in self.truth_light_gdf['buffer_area']:
            match_lights = []  # 存储当前缓冲区匹配到的输入信号灯
            for input_light in self.input_light_gdf['geometry']:
                if(input_light.within(truth_light_buffer)):  # 检查是否相交
                    match_lights.append(input_light)  # 添加匹配到的输入信号灯
                    used_input_trafficlights.add(input_light)  # 标记为已使用
            match_result[truth_light_buffer] = match_lights  # 记录当前缓冲区及其匹配的输入信号灯

        # 确定未匹配的输入信号灯
        unmatch_input_list: List[Point] = [light for light in self.input_light_gdf['geometry'] if light not in used_input_trafficlights]

        return match_result, unmatch_input_list  # 返回匹配结果和未匹配的输入信号灯

    def calculate_metrics(self, matches, unmatches):
        """
        计算评测指标：准确率、精确率和召回率。

        :param matches: 匹配结果字典。
        :param unmatches: 未匹配的输入信号灯列表。
        :return: 准确率、精确率和召回率的元组。
        """
        # TP: 每个输入信号灯都有对应的真值信号灯
        true_positives = sum(1 for truthing, match_lights in matches.items() if len(match_lights) > 0)
        # FN: 每个真值信号灯没有匹配到输入信号灯
        false_negatives = sum(1 for truth_light, match_lights in matches.items() if len(match_lights) == 0)
        # FP: 每条输入信号灯应该找到至少一个真值信号灯，但实际上没有匹配
        false_positives = len(unmatches)

        # 计算精准率和召回率
        recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
        precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
        accuracy = true_positives / len(self.input_light_gdf) if len(self.input_light_gdf) > 0 else 0

        return accuracy, precision, recall  # 返回指标

    def visualize(self,
                  result: LightEvaluateResult,
                  reference_material_gdf=GeoDataFrame(columns=['geometry']),
                  is_visualize=False,
                  save_vector_file=False,
                  output_svg_path=None):
        """
        可视化匹配结果，包括未匹配的地面信号灯、真值信号灯和匹配信号灯。

        :param matches: 匹配结果字典。
        :param unmatches: 未匹配的输入信号灯列表。
        :param buffer_distance: 缓冲区半径。
        :param reference_material_gdf: 参考材料的GeoDataFrame（可选）。
        :param output_svg: 输出SVG文件的路径（可选）。
        :param is_visualize: 是否显示可视化图形。
        """
        fig, ax = plt.subplots(figsize=(12, 9))  # 创建绘图窗口

        if reference_material_gdf.empty:
            reference_material_gdf = self.reference_material_gdf

        if not reference_material_gdf.empty:
            reference_material_gdf.plot(ax=ax, edgecolor='#0f0f0f80', alpha=0.06)  # 绘制参考材料

        # 绘制未匹配的输入地面标识
        for input_light in result.unmatched_input_list:
            x, y = input_light.xy
            ax.plot(x, y,
                    color='red',
                    alpha=0.8,
                    marker='o',
                    markersize=8,
                    linestyle='',
                    label='未匹配的信号灯输入值')

        # 绘制已匹配的真值信号灯与连接线
        truth_matched_cnt = 0  # 已匹配真值计数
        truch_unmatched_cnt = 0  # 未匹配真值计数
        for truth_buffer, matched_inputs in result.match_result.items():
            t_x, t_y = truth_buffer.centroid.xy
            if len(matched_inputs):
                truth_matched_cnt += 1  # 计数已匹配的真值
                ax.plot(t_x, t_y,
                        color='orange',
                        alpha=0.3,
                        marker='o',
                        markersize=8,
                        linestyle='',
                        label='已匹配的信号灯真值')

                # 绘制已匹配的输入信号灯
                for matched in matched_inputs:
                    m_x, m_y = matched.xy
                    ax.plot(m_x, m_y,
                            color='green',
                            alpha=0.5,
                            marker='o',
                            markersize=8,
                            linestyle='',
                            label='已匹配的信号灯输入值')

                    # 绘制连接质心的虚线
                    truth_centroid = truth_buffer.centroid
                    matched_centroid = matched.centroid
                    ax.plot([truth_centroid.x, matched_centroid.x],
                            [truth_centroid.y, matched_centroid.y], 'k--', linewidth=1)  # 连接两者质心的线段
            else:
                truch_unmatched_cnt += 1  # 计数未匹配的真值
                ax.plot(t_x, t_y,
                        color='blue',
                        alpha=0.3,
                        marker='o',
                        markersize=8,
                        linestyle='',
                        label='未匹配的信号灯真值')

        # 添加图例
        handles, labels = ax.get_legend_handles_labels()
        by_label = {}
        for h, l in zip(handles, labels):
            if l not in by_label:
                by_label[l] = h
        ax.legend(by_label.values(), by_label.keys())  # 去重并绘制图例

        title_prefix = f"{os.path.splitext(os.path.basename(output_svg_path))[0]} - " if output_svg_path is not None else ""
        title = f"{result.title}"
        ax.set_title(title)  # 设置标题
        ax.set_xlabel('X')
        ax.set_ylabel('Y')

        # 构建统计信息
        stats_dict = {
            "准确率": f"{result.precision * 100:.2f}%",
            "召回率": f"{result.recall * 100:.2f}%",
            "F1分数": f"{result.f1: .4f}",
            "已匹配真值数量": f"{result.truth_matched_cnt}",
            "未匹配真值数量": f"{result.truch_unmatched_cnt}",
            "已匹配输入值数量": f"{result.input_matched_cnt}",
            "未匹配输入值数量": f"{result.input_unmatched_cnt}"
        }

        # 将统计信息格式化为文本
        stats_text = '\n'.join([f"{key}: {value}" for key, value in stats_dict.items()])
        logger.info(f"\n评测任务:{title} 结论:\n{stats_text}")  # 日志记录评测结果

        props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)  # 文本框样式
        ax.text(1.01, 0.5,
                stats_text,
                transform=ax.transAxes,
                fontsize=10,
                verticalalignment='center',
                bbox=props,
                fontfamily='Microsoft YaHei')  # 在图上添加统计信息文本

        plt.grid(True)  # 显示网格
        if output_svg_path:
            # 获取文件的目录路径
            directory = os.path.dirname(output_svg_path)

            # 检查目录是否存在，如果不存在则创建
            if directory and not os.path.exists(directory):
                os.makedirs(directory)

            # 保存图形
            plt.savefig(output_svg_path, format='svg', bbox_inches='tight')  # 保存为矢量格式

        if is_visualize:
            plt.show()  # 显示绘图


    def generate_summary(self, buffer_distance, matches, unmatch):
        """
        生成评测摘要（此处留空，待实现）。

        :param buffer_distance: 缓冲区距离。
        :param matches: 匹配结果。
        :param unmatch: 未匹配的结果。
        """
        pass  # 该方法尚未实现

    def evaluate(self, buffer_distance, task_name: Optional[str]) -> LightEvaluateResult:
        """
        执行评测流程，包括匹配过程和结果可视化。

        :param buffer_distance: 缓冲区距离。
        :param output_svg: 输出SVG文件的路径（可选）。
        :param is_visualize: 是否显示可视化结果（默认为WWTrue）。
        """
        match_result, unmatch_input_list = self.match_object(buffer_distance=buffer_distance)  # 进行对象匹配

        accuracy, precision, recall = self.calculate_metrics(match_result, unmatch_input_list)  # 计算指标

        truth_matched_cnt = 0  # 已匹配真值计数
        truth_unmatched_cnt = 0  # 未匹配真值计数
        for truth_element_buffer, matched_inputs in match_result.items():
            if len(matched_inputs):
                truth_matched_cnt += 1  # 计数已匹配的真值
            else:
                truth_unmatched_cnt += 1  # 计数未匹配的真值

        res = LightEvaluateResult(
            title=task_name,
            buffer_distance=buffer_distance,
            accuracy=accuracy,
            precision=precision,
            recall=recall,
            match_result=match_result,
            unmatched_input_list=unmatch_input_list,
            truth_matched_cnt=truth_matched_cnt,
            truth_unmatched_cnt=truth_unmatched_cnt,
            input_matched_cnt=len(self.input_light_gdf) - len(unmatch_input_list),
            input_unmatched_cnt=len(unmatch_input_list)
        )

        logger.info(f"\n评测任务:{res.title} 结论:\n{res.format_text}")  # 记录评测结论
        return res