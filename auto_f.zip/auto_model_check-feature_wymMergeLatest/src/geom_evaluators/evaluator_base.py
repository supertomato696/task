import glob
import os
from typing import Union, Optional

import geopandas as gpd
from geopandas import GeoDataFrame
from src.logger import logger
from shapely import Polygon, unary_union, LineString, Point, GeometryCollection

from src.tools.common import ensure_single_geometries, transform_to_utm
from src.tools.filter import get_filtered_geometries
from src.tools.get_evaluate_area import generate_convex_hull, prune_by_exact_area


class EvaluatorBase(object):
    """
    评测器基类，用于处理空间数据（如GeoJSON或Shapefile）并进行区域裁剪和转换操作。
    """
    __is_debug = True

    def __init__(self,
                 truth_file_path: str,
                 input_file_path: str,
                 output_file_path: str,
                 truth_gdf: gpd.GeoDataFrame = None,
                 input_gdf: gpd.GeoDataFrame = None,
                 truth_data_filter_conditions: dict = None,
                 input_data_filter_conditions: dict = None,
                 is_ignore_z: bool = True,
                 global_rect: Polygon = None,
                 convex_hull: Union[Polygon, str] = None,
                 is_save_convex_hull=True,
                 reference_material_file_path=None,
                 reference_material_gdf: gpd.GeoDataFrame = gpd.GeoDataFrame(columns=['geometry']),
                 reference_material_filter_conditions: dict = None):
        """
        初始化方法，接收真值文件路径、输入文件路径、凸包几何或文件路径以及参考材料文件路径。

        :param truth_file_path: 真值文件路径
        :param truth_data_filter_conditions: 真值要素筛选条件
        :param input_file_path: 输入文件路径，用于评测的数据
        :param input_data_filter_conditions: 输入文件要素筛选条件
        :param is_ignore_z: 是否忽略高程，默认为True
        :param global_rect: 全局的范围框，优先级高于凸包（可选）。
        :param convex_hull: 可选，提供一个凸包几何体或文件路径，若未提供，则自动查找或生成
        :param 默认保存凸包
        :param reference_material_file_path: 可选，参考材料文件路径（例如车道线）
        :param input_data_filter_conditions: 参考要素要素筛选条件

        """
        self.is_save_convex_hull = is_save_convex_hull

        # 设置路径
        self.truth_file_path = truth_file_path
        self.input_file_path = input_file_path

        # 如果是从文件中读取真值，那么
        self.truth_data_gdf = self.process_data_to_gdf_84(file_path=truth_file_path, input_gdf=truth_gdf,
                                                          data_filter_conditions=truth_data_filter_conditions)
        self.input_data_gdf = self.process_data_to_gdf_84(file_path=input_file_path, input_gdf=input_gdf,
                                                          data_filter_conditions=input_data_filter_conditions)
        # for idx, row in self.truth_data_gdf.iterrows():
        #     if row['geometry'] is None:
        #         raise

        if is_ignore_z:
            self.truth_data_gdf['geometry'] = self.truth_data_gdf['geometry'].apply(self.ignore_z)
            self.input_data_gdf['geometry'] = self.input_data_gdf['geometry'].apply(self.ignore_z)

        # for idx, row in self.truth_data_gdf.iterrows():
        #     if row['geometry'] is None:
        #         raise

        if reference_material_file_path:
            logger.debug(f"传入文件参考资料：{reference_material_file_path}")
            self.reference_material_gdf = self.process_data_to_gdf_84(file_path=reference_material_file_path,
                                                                      input_gdf=reference_material_gdf,
                                                                      data_filter_conditions=reference_material_filter_conditions)
        elif not reference_material_gdf.empty:
            self.reference_material_gdf = reference_material_gdf
        else:
            self.reference_material_gdf = gpd.GeoDataFrame(columns=['geometry'])

        # 获取或生成凸包几何
        self.convex_hull = self.ensure_convex_hull(input_gdf=self.truth_data_gdf, convex_hull=convex_hull)

        if global_rect:
            logger.debug("受到更高级的地理范围框约束，正在取交集...")
            self.convex_hull = self.convex_hull.intersection(global_rect)
            # 使用凸包对真值进行裁剪
            self.truth_data_gdf = prune_by_exact_area(self.truth_data_gdf, self.convex_hull)
            if self.truth_data_gdf.empty:
                raise ValueError("真值数据根据凸包+限定区域剪裁完什么都不剩了检查一下")
            self.pruned_input_gdf = prune_by_exact_area(self.input_data_gdf, self.convex_hull)
            if self.pruned_input_gdf.empty:
                raise ValueError("待评测数据根据凸包+限定区域剪裁完什么都不剩了检查一下")

            # # 参考资料目前不剪裁
            # if not self.reference_material_gdf.empty:
            #     self.reference_material_gdf = prune_by_exact_area(reference_material_gdf, self.convex_hull)
            #     if self.pruned_input_gdf.empty:
            #         logger.warning("参考资料根据凸包剪裁完什么都不剩了检查一下")
        else:
            self.pruned_input_gdf = prune_by_exact_area(self.input_data_gdf, self.convex_hull)
            if self.pruned_input_gdf.empty:
                import matplotlib.pyplot as plt

                fig, ax = plt.subplots(1, 1)

                # 绘制你的 GeoDataFrame
                self.input_data_gdf.plot(ax=ax, color='blue', edgecolor='black')  # 可以根据需要自定义颜色和样式

                # 绘制你的 Polygon
                polygon_gdf = gpd.GeoSeries([self.convex_hull])
                polygon_gdf.plot(ax=ax, color='red', alpha=0.5)  # 可以根据需要自定义颜色和样式

                # 可选: 设置标题、坐标轴标签、范围等
                ax.set_title("Examine Polygon and GeoDataFrame")

                plt.show()
                raise ValueError("待评测数据根据凸包剪裁完什么都不剩了检查一下")

            # # 参考资料目前不剪裁
            # if not self.reference_material_gdf.empty:
            #     self.reference_material_gdf = prune_by_exact_area(reference_material_gdf, self.convex_hull)
            #     if self.pruned_input_gdf.empty:
            #         logger.warning("参考资料根据凸包剪裁完什么都不剩了检查一下")

        self.pruned_input_gdf = transform_to_utm(self.pruned_input_gdf)
        self.truth_data_gdf = transform_to_utm(self.truth_data_gdf)
        if not self.reference_material_gdf.empty:
            self.reference_material_gdf = transform_to_utm(self.reference_material_gdf)

        if self.__is_debug:  # 检查数据处理结果
            try:
                import matplotlib.pyplot as plt

                fig, ax = plt.subplots(1, 1)

                polygon_gdf = gpd.GeoSeries([self.convex_hull]).set_crs(epsg=4326)
                # 绘制Geodataframe
                self.pruned_input_gdf.plot(ax=ax, color='blue', edgecolor='black')
                self.truth_data_gdf.plot(ax=ax, color='red', alpha=0.5)
                transform_to_utm(polygon_gdf).plot(ax=ax, color='green', alpha=0.5)
                # 设置标题
                ax.set_title("Examine Polygon and GeoDataFrame")

               # plt.show()
            except:
                raise

    @staticmethod
    def process_data_to_gdf_84(file_path: Optional[str], input_gdf: Optional[GeoDataFrame], data_filter_conditions):
        # 读取文件为GeoDataFrame
        if isinstance(input_gdf, gpd.GeoDataFrame):
            # if input_gdf.empty:
            #     input_gdf = None
            pass
        else:
            input_gdf = gpd.GeoDataFrame(columns=['geometry'])

        if file_path is None:
            logger.debug(f"处理文件{file_path}")
        if file_path and input_gdf.empty:
            gdf = gpd.read_file(file_path)
            try:
                gdf.to_crs(epsg=4326)
            except:
                # 检查 CRS 是否为 None，如果是，则设置为 EPSG:4326
                if gdf.crs is None:
                    gdf.set_crs('EPSG:4326', allow_override=True, inplace=True)
        elif not input_gdf.empty and file_path is None:
            gdf = input_gdf
        else:
            raise ValueError("请正确输入几何数据")

        # for idx, row in gdf.iterrows():
        #     if row['geometry'] is None:
        #         raise

        # 确保每个几何体只有一个（不是复合几何）
        exploded_gdf = ensure_single_geometries(gdf)
        filtered_gdf = get_filtered_geometries(gdf=exploded_gdf, filter_conditions=data_filter_conditions,
                                               convert_to_utm=False)
        return filtered_gdf

    def process_reference_material(self, reference_material_file_path, reference_material_filter_conditions):
        if reference_material_file_path:
            # 参考材料的处理，若传入了参考材料路径，则裁剪其数据
            ref_gdf = self.prune_input_with_convex_hull(reference_material_file_path, self.convex_hull)
            if reference_material_filter_conditions:
                return get_filtered_geometries(gdf=ref_gdf, filter_conditions=reference_material_filter_conditions,
                                               convert_to_utm=False)
            else:
                return ref_gdf
        else:
            return None

    @staticmethod
    def get_utm_gdf_from_file(file_path: str):
        """
        从文件中读取GeoDataFrame，并确保其几何体是单一几何，最后转换为UTM坐标系。

        :param file_path: 输入的文件路径
        :return: 转换后的GeoDataFrame，坐标系为UTM
        """
        # 读取文件为GeoDataFrame
        gdf = gpd.read_file(file_path)

        # 确保每个几何体只有一个（不是复合几何）
        exploded_gdf = ensure_single_geometries(gdf)

        # 转换到UTM坐标系
        return transform_to_utm(exploded_gdf)

    @staticmethod
    def __find_convex_hull_files(file_path):
        """
        在文件所在目录查找凸包文件，返回第一个匹配的文件路径。

        :param file_path: 输入文件的路径
        :return: 第一个找到的凸包文件路径，若没有则返回None
        """
        input_directory = os.path.dirname(file_path)

        # 使用glob搜索符合条件的文件
        convex_hull_files = glob.glob(os.path.join(input_directory, 'convex_hull.*'))
        convex_hull_files = [f for f in convex_hull_files if f.lower().endswith(('.geojson', '.shp'))]

        # 返回文件路径或None
        return convex_hull_files[0] if convex_hull_files else None

    def ensure_convex_hull(self, input_gdf: Union[str, GeoDataFrame], convex_hull: Union[Polygon, str] = None,
                           is_save_convex_hull_file=True) -> Polygon:
        """
        确保获取凸包几何，如果没有提供则根据真值文件自动查找或生成, 坐标系为4326。
        :param input_gdf 输入
        :param is_save_convex_hull_file: 是否保存凸包文件。
        :param convex_hull: 可选，凸包的几何体或文件路径
        :return: 凸包几何体（Polygon）
        """
        if convex_hull is not None:
            # 如果传入了凸包几何体或文件路径
            if isinstance(convex_hull, str):
                logger.debug(f"已指定此路口凸包文件：{convex_hull}")
                # 直接读取凸包文件
                convex_hull_gdf = gpd.read_file(convex_hull)
                convex_hull_gdf.to_crs(epsg=4326)
                convex_hull_geom = convex_hull_gdf['geometry'].tolist()[0]
            else:
                logger.debug(f"已指定此路口凸包几何")
                convex_hull_geom = convex_hull
            return convex_hull_geom
        else:
            if isinstance(input_gdf, str):
                # 尝试从真值文件所在目录查找凸包文件
                try:
                    convex_hull_file_path = self.__find_convex_hull_files(input_gdf)
                except Exception as e:
                    convex_hull_file_path = None
                if convex_hull_file_path:
                    logger.debug(f"真值路线下有凸包文件，读取此文件获取凸包几何：{convex_hull_file_path}")
                    # 读取凸包文件并返回几何
                    convex_hull_gdf = gpd.read_file(convex_hull_file_path)
                    return convex_hull_gdf['geometry'].tolist()[0]
                else:
                    logger.debug("未找到凸包，生成中...")
                    # 如果没有找到，则根据真值文件生成凸包
                    if is_save_convex_hull_file and self.is_save_convex_hull:
                        p = os.path.join(os.path.dirname(self.truth_file_path), 'batch-195.geojson')
                        return generate_convex_hull(file_paths=[self.truth_file_path],
                                                    output_file_path=glob.glob(
                                                        os.path.join(os.path.dirname(self.truth_file_path),
                                                                     'batch-195.geojson')))
                    else:
                        return generate_convex_hull(file_paths=[self.truth_file_path])
            if isinstance(input_gdf, GeoDataFrame):
                # 合并所有几何对象
                input_gdf = input_gdf.to_crs(epsg=4326)
                all_geometries = input_gdf['geometry'].tolist()
                merged_geometry = unary_union(all_geometries)
                # 计算凸包
                convex_hull: Polygon = merged_geometry.convex_hull
                return convex_hull

    @staticmethod
    def prune_input_with_convex_hull(file_path, convex_hull_geom: Polygon) -> GeoDataFrame:
        """
        根据给定的凸包几何体裁剪输入数据，并转换为UTM坐标系。

        :param file_path: 输入数据的文件路径
        :param convex_hull_geom: 凸包几何体，用于裁剪数据
        :return: 裁剪后的GeoDataFrame，坐标系为UTM
        """
        # 读取输入数据文件为GeoDataFrame
        input_file_gdf = gpd.read_file(file_path)

        # 使用凸包裁剪数据
        pruned_gdf_untransformed = prune_by_exact_area(input_file_gdf, convex_hull_geom)

        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(12, 9))  # 创建绘图窗口
        input_file_gdf.plot(ax=ax, edgecolor='blue', alpha=0.06)
        # pruned_gdf_untransformed.plot(ax=ax, edgecolor='red', alpha=0.06)

        plt.show()  # 显示绘图

        # 转换坐标系到UTM
        return transform_to_utm(pruned_gdf_untransformed)

    @staticmethod
    def get_filtered_geometries(gdf: GeoDataFrame, filter_conditions: dict) -> GeoDataFrame:
        """获取经过筛选的几何对象."""
        return get_filtered_geometries(gdf=gdf, convert_to_utm=True, filter_conditions=filter_conditions)

    def ignore_z(self, geometry):
        """
        忽视几何对象的Z坐标，只返回XY坐标。

        :param geometry: 输入的几何对象（LineString、Polygon、Point或GeometryCollection）。
        :return: 忽略Z坐标后的几何对象。
        """
        if isinstance(geometry, LineString):
            if geometry.has_z:
                return LineString([(x, y) for x, y, z in geometry.coords])
            return geometry

        elif isinstance(geometry, Polygon):
            if geometry.has_z:
                exterior = [(x, y) for x, y, z in geometry.exterior.coords]
                interiors = [[(x, y) for x, y, z in ring.coords] for ring in geometry.interiors]
                return Polygon(exterior, interiors)
            return geometry

        elif isinstance(geometry, Point):
            if geometry.has_z:
                return Point(geometry.x, geometry.y)
            return geometry

        elif isinstance(geometry, GeometryCollection):
            # 处理几何集合，递归调用
            return GeometryCollection([self.ignore_z(geom) for geom in geometry.geoms])

        else:
            raise TypeError("Unsupported geometry type: {}".format(type(geometry)))
