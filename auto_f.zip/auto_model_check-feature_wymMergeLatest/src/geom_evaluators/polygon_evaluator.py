import copy
import os
from dataclasses import dataclass
from typing import List, Tuple, Union

import geopandas as gpd
import matplotlib.pyplot as plt
from geopandas import GeoDataFrame

from src.logger import logger
from shapely.geometry import Polygon

from src.geom_evaluators.evaluator_base import EvaluatorBase


class EvaluationResult:
    """评测结果类，封装IOU、Hausdorff距离和重心距离。"""

    def __init__(self, iou: float, hausdorff_distance: float, centroid_distance: float, std_area=0, intersect_area=0):
        self.iou = iou
        self.hausdorff_distance = hausdorff_distance
        self.centroid_distance = centroid_distance

        # FIXME 这里应该搞个setter，赶时间先这么顶住先吧....
        self.std_area = std_area
        self.intersect_area = intersect_area

    def __repr__(self):
        return (f"EvaluationResult(IOU={self.iou:.4f}, "
                f"Hausdorff Distance={self.hausdorff_distance:.4f} 米, "
                f"Centroid Distance={self.centroid_distance:.4f} 米)")


@dataclass
class PolygonEvaluateSummary:
    """
    Polygon校验的结果汇总
    Pydantic用累了换个口味...
    """
    title: str
    total_true_polygon_count: int
    total_input_polygon_count: int
    recall: float  # 召回率
    matched_pairs: list[Tuple[Polygon, Polygon]]
    unmatched_polygons: list[Polygon]
    evaluation_results: list[EvaluationResult]
    total_std_area: float  # 真值总面积
    total_intersection_area: float  # 总相交面积
    total_input_area: float  # 输入总面积
    intersect_percentage: float


def create_evaluation_summary(title: str,
                              total_true_polygon_count: int,
                              total_input_polygon_count: int,
                              recall: float,
                              matched_pairs: List[Tuple[Polygon, Polygon]],
                              unmatched_polygons: List[Polygon],
                              evaluation_results: List[EvaluationResult],
                              total_std_area: float,
                              total_intersection_area: float,
                              total_input_area: float,
                              ) -> PolygonEvaluateSummary:
    """
    创建并返回一个 PolygonEvaluateSummary 实例。
    """
    summary = PolygonEvaluateSummary(
        title=title,
        total_true_polygon_count=total_true_polygon_count,
        total_input_polygon_count=total_input_polygon_count,
        recall=recall,
        matched_pairs=matched_pairs,
        unmatched_polygons=unmatched_polygons,
        evaluation_results=evaluation_results,
        total_std_area=total_std_area,
        total_intersection_area=total_intersection_area,
        total_input_area=total_input_area,
        intersect_percentage=(total_intersection_area / total_std_area * 100) if total_std_area else 0
    )
    return summary


class PolygonEvaluator(EvaluatorBase):
    def __init__(self,
                 truth_polygons_file_path,
                 input_polygons_file_path,
                 # TODO 写到注释里面
                 truth_gdf: GeoDataFrame = None,
                 input_gdf: GeoDataFrame = None,
                 truth_data_filter_conditions=None,
                 input_data_filter_conditions=None,
                 global_rect: Polygon = None,
                 convex_hull: Union[Polygon, str] = None,
                 reference_material_file_path=None,
                 # TODO 写到注释里面
                 reference_material_gdf: GeoDataFrame = GeoDataFrame(columns=['geometry']),
                 reference_material_filter_conditions: dict = None):

        """
        初始化方法，接收真值文件路径、输入文件路径、凸包几何或文件路径以及参考材料文件路径。

        :param truth_polygons_file_path: 真值文件路径
        :param truth_data_filter_conditions: 真值要素筛选条件

        :param input_polygons_file_path: 输入文件路径，用于评测的数据
        :param input_data_filter_conditions: 输入文件要素筛选条件
        :param global_rect: 全局的范围框，优先级高于凸包（可选）。
        :param convex_hull: 可选，提供一个凸包几何体或文件路径，若未提供，则自动查找或生成
        :param reference_material_file_path: 可选，参考材料文件路径（例如车道线）
        :param input_data_filter_conditions: 参考要素要素筛选条件

        """
        super().__init__(truth_file_path=truth_polygons_file_path,
                         input_file_path=input_polygons_file_path,
                         truth_gdf=truth_gdf,
                         input_gdf=input_gdf,
                         global_rect=global_rect,
                         convex_hull=convex_hull,
                         truth_data_filter_conditions=truth_data_filter_conditions,
                         input_data_filter_conditions=input_data_filter_conditions,
                         reference_material_gdf=reference_material_gdf,
                         reference_material_file_path=reference_material_file_path,
                         reference_material_filter_conditions=reference_material_filter_conditions
                         )

        self.total_input_area = self.pruned_input_gdf["geometry"].area.sum()
        self.total_intersection_area = 0
        self.total_std_area = 0

    def calculate_iou(self, std_polygon: Polygon, test_polygon: Polygon) -> float:
        """
        计算交并比（IOU）
        交并比（IoU，Intersection over Union）是目标检测和分割任务中一个重要的衡量标准。
        ‌它表示两个边界框（或分割掩模）的交集区域面积与它们的并集区域面积之比。交并比的取值范围在0到1之间，值越大表示两个边界框之间的重叠程度越高。
        当IoU为1时，表示两个边界框完全重叠；当IoU为0时，表示两个边界框没有任何重叠。‌

        IOU = 交集面积 / 并集面积

        returns:
        - IOU 值（0 到 1 之间）
        """
        intersection_area = std_polygon.intersection(test_polygon).area
        # FIXME 在里面汇总不太好，下次提到外面去，赶时间暂时先这样.
        self.total_intersection_area += intersection_area
        self.total_std_area += std_polygon.area
        union_area = std_polygon.union(test_polygon).area
        iou = intersection_area / union_area if union_area != 0 else 0
        return iou

    @staticmethod
    def calculate_hausdorff_distance(std_polygon: Polygon, test_polygon: Polygon) -> float:
        """
        用Shapely内置方法计算Hausdorff距离

        returns:
        - Hausdorff 距离值（浮点数，以米为单位）
        """
        hausdorff = std_polygon.hausdorff_distance(test_polygon)
        return hausdorff

    @staticmethod
    def calculate_centroid_distance(std_polygon: Polygon, test_polygon: Polygon) -> float:
        """
        计算两个多边形重心距离

        returns:
        - 重心距离值（浮点数，以米为单位）
        """
        centroid_std = std_polygon.centroid
        centroid_test = test_polygon.centroid
        centroid_dist = centroid_std.distance(centroid_test)
        return centroid_dist

    def evaluate_metrics(self, std_polygon: Polygon, test_polygon: Polygon) -> EvaluationResult:
        """
        评测各项指标，计算IOU、Hausdorff距离、重心距离

        returns:
        - EvaluationResult 实例
        """
        # 计算各指标
        iou = self.calculate_iou(std_polygon, test_polygon)
        hausdorff = self.calculate_hausdorff_distance(std_polygon, test_polygon)
        centroid_dist = self.calculate_centroid_distance(std_polygon, test_polygon)

        # 返回评测结果实例
        return EvaluationResult(iou=iou, hausdorff_distance=hausdorff, centroid_distance=centroid_dist,
                                std_area=std_polygon.area, intersect_area=std_polygon.intersection(test_polygon).area)

    @staticmethod
    def match_polygons(true_polygons: gpd.geoseries.GeoSeries, input_polygons: gpd.geoseries.GeoSeries,
                       max_distance: float=5) -> tuple[list[tuple[Polygon, Polygon]], list[Polygon]]:
        """
        二维数组，以真值为基础找匹配
        1. 距离真值多边形质心距离超过5米且与真值多边形没有任何交集的输入多边形视为无法匹配；
        2. 如果有多个多边形满足质心距离在5米内，那么覆盖度高的视为匹配。
        3. 如果覆盖度相同，那么质心距离最近的视为匹配。
        4. 如果覆盖度和质心距离最接近，那么任选一个视为匹配。
        5. 一个真值多边形只会被一个输入多边形匹配。也就是一个输入多边形只能被一个真值匹配成组。
        :param true_polygons: 真值多边形
        :param input_polygons:
        :param max_distance: 计算匹配的质心最大距离默认5米
        :return:
        """
        matched: dict[Polygon: Polygon] = {}

        unmatched_true_polygons = copy.deepcopy(input_polygons.tolist())

        for true_poly in true_polygons:
            # 候选列表
            candidates = []
            for input_poly in unmatched_true_polygons:
                true_centroid = true_poly.centroid
                input_centroid = input_poly.centroid
                distance = true_centroid.distance(input_centroid)
                if distance <= max_distance or true_poly.intersects(input_poly):
                    coverage = true_poly.intersection(input_poly).area / true_poly.area
                    candidates.append((input_poly, coverage, distance, input_centroid))

            if candidates:
                candidates.sort(key=lambda x: (-x[1], x[2]))
                matched_poly = candidates[0][0]
                matched[true_poly] = matched_poly
                unmatched_true_polygons.remove(matched_poly)

        # 筛选出未匹配的输入多边形
        # matched将字典中的值收集到一个集合中，用于快速查找
        dict_values_set = set(matched.values())
        # 过滤出不在字典值集合中的polygon
        unmatched_input_polygons = [value for value in input_polygons if value not in dict_values_set]

        return list(matched.items()), unmatched_input_polygons

    def evaluate(self, task_name: str, max_centroid_distance: float = 5) -> PolygonEvaluateSummary:
        """
        执行多边形匹配与评测，返回所有评测结果和平均分

        returns:
        - matched_pairs: List of tuples (真值多边形, 测试多边形)
        - evaluations: List of EvaluationResult 实例
        """
        matched_pairs, unmatched_list = self.match_polygons(true_polygons = self.truth_data_gdf["geometry"],
                                                            input_polygons= self.pruned_input_gdf["geometry"],
                                                            max_distance=max_centroid_distance)
        evaluation_results = []
        logger.debug("\n开始进行综合评测...")
        for idx, (std_poly, test_poly) in enumerate(matched_pairs, start=1):
            eval_result = self.evaluate_metrics(std_poly, test_poly)
            logger.debug(f"评测多边形对 {idx}:{eval_result}")
            evaluation_results.append(eval_result)

        return create_evaluation_summary(
            title=task_name,
            recall=len(matched_pairs) / len(self.truth_data_gdf["geometry"]),
            total_true_polygon_count=len(self.truth_data_gdf["geometry"]),
            total_input_polygon_count=len(self.pruned_input_gdf["geometry"]),
            matched_pairs=matched_pairs,
            unmatched_polygons=unmatched_list,
            evaluation_results=evaluation_results,
            total_std_area=self.total_std_area,
            total_input_area=self.total_input_area,
            total_intersection_area=self.total_intersection_area

        )

    def visualize(self, summary: PolygonEvaluateSummary, output_svg_path=None, verbose_plot=False, is_visualize=True):
        """
        可视化匹配后的多边形对，包括真值多边形、测试多边形、交集区域、重心点和基准点
        """
        # 创建绘图
        fig, ax = plt.subplots(figsize=(12, 9))

        # 绘制参考资料
        if not self.reference_material_gdf.empty:
            self.reference_material_gdf.plot(ax=ax, alpha=0.1, color="#0f0f0f80", linewidth=0.5)

        # 绘制真值多边形
        for idx, std_poly in enumerate(self.truth_data_gdf["geometry"], start=1):
            # 绘制真值多边形
            x, y = std_poly.exterior.xy
            ax.fill(x, y, alpha=0.8, color='#1b315e', label='真值多边形')

        for idx, input_poly in enumerate(self.pruned_input_gdf["geometry"], start=1):
            # 绘制待评测多边形
            x, y = input_poly.exterior.xy
            if input_poly in summary.unmatched_polygons:
                ax.fill(x, y, alpha=0.9, color='#c63c26', label='未匹配测试多边形')
            else:
                ax.fill(x, y, alpha=0.5, color='#ffc20e', label='已匹配测试多边形')

        # 绘制交集、连线和标签
        intersection_plots = []
        centroid_gt_x = []
        centroid_gt_y = []
        centroid_test_x = []
        centroid_test_y = []

        for idx, (std_poly, test_poly) in enumerate(summary.matched_pairs, start=1):
            # 绘制交集
            intersection = std_poly.intersection(test_poly)
            if not intersection.is_empty:
                if intersection.geom_type == 'Polygon':
                    intersection_plots.append(intersection)
                elif intersection.geom_type == 'MultiPolygon':
                    intersection_plots.extend(list(intersection))

            if verbose_plot:
                # 添加标签

                # 重心
                std_centroid = std_poly.centroid
                test_centroid = test_poly.centroid
                centroid_gt_x.append(std_centroid.x)
                centroid_gt_y.append(std_centroid.y)
                centroid_test_x.append(test_centroid.x)
                centroid_test_y.append(test_centroid.y)

                # 连线
                ax.plot([std_centroid.x, test_centroid.x], [std_centroid.y, test_centroid.y],
                        color='gray', linestyle='--', linewidth=1, alpha=0.7)

                midpoint_x = (std_centroid.x + test_centroid.x) / 2
                midpoint_y = (std_centroid.y + test_centroid.y) / 2
                # ax.text(midpoint_x, midpoint_y, f"匹配组{idx}", fontsize=12, ha='right', va='top', color='red')

                this_result = summary.evaluation_results[idx - 1]
                eval_text = (f"匹配组{idx}\n"
                             f"多边形IOU: {this_result.iou:.2f}(1为最优)\n"
                             f"H距离: {this_result.hausdorff_distance:.2f} 米\n"
                             f"质心偏移距离: {this_result.centroid_distance:.2f}米\n"
                             f"真值面积: {this_result.std_area:.4f}平米\n"
                             f"实际相交面积: {this_result.intersect_area:.4f}平米\n"
                             f"交集占真值面积比: {(this_result.intersect_area / this_result.std_area * 100):.4f}%\n")

                ax.text(midpoint_x + 1, midpoint_y + 1, eval_text, fontsize=8, ha='left', va='bottom',
                        bbox=dict(facecolor='white', alpha=0.2, edgecolor='none'))

        # 绘制所有交集
        for intersection in intersection_plots:
            if intersection.geom_type == 'Polygon':
                x, y = intersection.exterior.xy
                ax.fill(x, y, color='#65c294', alpha=1,
                        label='交集' if intersection_plots.index(intersection) == 0 else "")
            elif intersection.geom_type == 'MultiPolygon':
                for poly in intersection.geoms:
                    x, y = poly.exterior.xy
                    ax.fill(x, y, color='#65c294', alpha=1, label='交集' if intersection_plots.index(poly) == 0 else "")
        if verbose_plot:
            # 绘制重心点
            ax.scatter(centroid_gt_x, centroid_gt_y, marker='o', color='#f6f5ec', s=10,
                       label='真值质心')
            ax.scatter(centroid_test_x, centroid_test_y, marker='^', color='#c77eb5', s=10,
                       label='输入值质心')

        # 创建自定义图例以避免重复
        handles, labels = ax.get_legend_handles_labels()
        by_label = {}
        for handle, label in zip(handles, labels):
            if label not in by_label:
                by_label[label] = handle
        ax.legend(by_label.values(), by_label.keys(), loc='upper right')

        plt.title(summary.title)
        plt.xlabel('米')
        plt.ylabel('米')
        plt.grid(True)

        if len(summary.evaluation_results):
            avg_hausdorff = sum([e.hausdorff_distance for e in summary.evaluation_results]) / len(
                summary.evaluation_results)
            avg_centroid_offset = sum([e.centroid_distance for e in summary.evaluation_results]) / len(
                summary.evaluation_results)
        else:
            avg_hausdorff = float('inf')
            avg_centroid_offset = float('inf')

        total_union_area = summary.total_std_area + sum(polygon.area for polygon in summary.unmatched_polygons)
        IOU = summary.total_intersection_area / total_union_area if (
                    summary.total_intersection_area != 0 and total_union_area != 0) else 0

        stats_text = (
            f"总基准面积{summary.total_std_area:.2f}平米\n"
            f"相交面积{summary.total_intersection_area:.2f}平米\n"
            f"输入面积准确率={summary.total_intersection_area / summary.total_input_area * 100:.2f}%\n"
            f"输入面积召回率={summary.intersect_percentage:.2f}%\n"
            f"输入个数/真值个数：{summary.total_input_polygon_count}/{summary.total_true_polygon_count}\n"
            f"整体IOU: {IOU:.4f}\n"
            f"整体平均H距离: {avg_hausdorff:.4f}米\n"
            f"整体平均重心距离: {avg_centroid_offset:.4f}米\n"
        )
        logger.info(f"\n评测任务:{summary.title} 结论:\n{stats_text}")
        props = dict(boxstyle='round', facecolor='wheat', alpha=0.2)
        ax.text(1.01, 0.2, stats_text, transform=ax.transAxes, fontsize=9,
                verticalalignment='center', bbox=props)
        # 调整图形布局，确保文本框不会被裁剪
        plt.subplots_adjust(right=0.8)

        if output_svg_path:
            # 获取文件的目录路径
            directory = os.path.dirname(output_svg_path)

            # 检查目录是否存在，如果不存在则创建
            if directory and not os.path.exists(directory):
                os.makedirs(directory)

            # 保存图形
            plt.savefig(output_svg_path, format='svg', bbox_inches='tight')  # 矢量格式
            logger.debug(f"保存文件{output_svg_path}")
        if is_visualize:
            plt.show()
            logger.debug("可视化完成。")

    @staticmethod
    def summarize(summary: PolygonEvaluateSummary):
        """
        :return:
        """
        # TODO 这些指标也要改啦
        print(
            f"\n详细评测结果：【brief: 总基准面积{summary.total_std_area:.2f}平米，相交面积{summary.total_intersection_area:.2f}平米。相交面积占比={summary.intersect_percentage:.2f}%】")
        for idx, eval_result in enumerate(summary.evaluation_results, start=1):
            print(f"\n评测结果 - 多边形对 {idx}:")
            print(f"IOU（交并比）: {eval_result.iou:.4f}")
            print(f"Hausdorff距离: {eval_result.hausdorff_distance:.4f} 米")
            print(f"重心距离: {eval_result.centroid_distance:.4f} 米")
            print("===============================")

        # 计算各指标的平均值
        if summary.evaluation_results:
            avg_iou = sum([e.iou for e in summary.evaluation_results]) / len(summary.evaluation_results)
            avg_hausdorff = sum([e.hausdorff_distance for e in summary.evaluation_results]) / len(
                summary.evaluation_results)
            avg_centroid = sum([e.centroid_distance for e in summary.evaluation_results]) / len(
                summary.evaluation_results)
            print(f"整体召回率：{summary.recall * 100:.2f}%")
            print(f"整体评测平均IOU: {avg_iou:.4f}")
            print(f"整体评测平均Hausdorff距离: {avg_hausdorff:.4f} 米")
            print(f"整体评测平均重心距离: {avg_centroid:.4f} 米")
        else:
            print("没有评测结果。")

    def start_evaluate_task(self, task_name: str, output_svg_path=None, verbose_plot=False, is_visualize=True) -> PolygonEvaluateSummary:
        """
        进行评测任务
        :param is_visualize: 是否做可视化
        :param task_name: 任务名称
        :param output_svg_path: 输出评测结果矢量图保持位置，默认为空，即不保存
        :param verbose_plot: 详细信息开关，默认为False。verbose_plot为True是会在评测结果中添加更加详尽的信息。
        :return:
        """
        logger.info(f"开始执行评测任务：{task_name}")

        # 执行评测
        summary: PolygonEvaluateSummary = self.evaluate(task_name)
        
        # # 打印详细评测结果
        # self.summarize(Summary)

        self.visualize(summary, output_svg_path=output_svg_path, verbose_plot=verbose_plot, is_visualize=is_visualize)
