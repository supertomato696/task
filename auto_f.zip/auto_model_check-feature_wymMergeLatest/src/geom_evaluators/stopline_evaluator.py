import copy
import os
from typing import Union, Any, Optional

import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
from geopandas import GeoDataFrame
from pydantic import BaseModel, Field

from src.logger import logger
# from scipy.spatial.distance import directed_hausdorff
from shapely import Polygon
from shapely.geometry import LineString, Point
from shapely.ops import unary_union, linemerge

from src.geom_evaluators.evaluator_base import EvaluatorBase


class StopLineEvaluateResult(BaseModel):
    title: str = None

    accuracy: float = Field(title="准确率", description="准确率Precision = TP/(TP+FP)")
    precision: float = Field(title="精准率")
    recall: float = Field(title="召回率")
    matches: list[Union[tuple[Any, None], tuple[Any, Optional[Any]]]] = []
    unmatches: list
    max_hausdorff: float = Field(title="Hausdorff最大距离(米)", description="Hausdorff最大距离(米)")
    min_hausdorff: float = Field(title="Hausdorff最小距离(米)", description="Hausdorff最小距离(米)")
    max_rotate_angle: float
    min_rotate_angle: float
    max_len_diff: float = Field(title="最大长度差(米)", description="最大长度差(米)")
    min_len_diff: float = Field(title="最小长度差(米)", description="最小长度差(米)")

    @property
    def f1_score(self) -> float:
        """
        计算F1分数，综合考虑精准率和召回率。

        :return: float F1分数
        """
        return 2 * (self.precision * self.recall) / (self.precision + self.recall) if (self.precision + self.recall) > 0 else 0

    @property
    def format_text(self) -> str:
        stats_text = (
            f"准确率: {self.accuracy * 100:.2f}%\n"
            f"召回率: {self.recall * 100:.2f}%\n"
            f"F1分数: {self.f1_score: .4f}\n"
            f"Hausdorff最大距离(米): {self.max_hausdorff: .2f}\n"
            f"Hausdorff最小距离(米): {self.min_hausdorff: .2f}\n"
            f"最大偏转角: {self.max_rotate_angle: .2f}\n"
            f"最小偏转角: {self.min_rotate_angle: .2f}\n"
            f"最大长度差(米): {self.max_len_diff: .2f}\n"
            f"最小长度差(米): {self.min_len_diff: .2f}"
        )
        return stats_text

    class Config:
        arbitrary_types_allowed = True  # 允许任意类型的字段


class StopLineEvaluator(EvaluatorBase):
    def __init__(self,
                 truth_stopline_file_path=None,
                 input_stopline_file_path=None,
                 truth_gdf: GeoDataFrame = None,
                 input_gdf: GeoDataFrame = None,
                 truth_data_filter_conditions: dict = None,
                 input_data_filter_conditions: dict = None,
                 global_rect: Polygon = None,
                 convex_hull: Union[Polygon, str] = None,
                 reference_material_file_path=None,
                 reference_material_gdf: GeoDataFrame = GeoDataFrame(columns=['geometry']),
                 reference_material_filter_conditions: dict = None):
        """
        道路停止线评测类。

        :param truth_stopline_file_path: 真值停止线文件路径。
        :param input_stopline_file_path: 输入停止线文件路径。
        :param truth_data_filter_conditions: 真值数据的筛选条件（可选）。
        :param input_data_filter_conditions: 输入数据的筛选条件（可选）。
        :param global_rect: 全局的范围框，优先级高于凸包（可选）。
        :param convex_hull: 用于计算的凸包（可选）。
        :param reference_material_file_path: 参考材料文件路径（可选）。
        :param reference_material_filter_conditions: 参考材料的筛选条件（可选）。
        """
        super().__init__(truth_file_path=truth_stopline_file_path,
                         input_file_path=input_stopline_file_path,
                         truth_gdf=truth_gdf,
                         input_gdf=input_gdf,
                         truth_data_filter_conditions=truth_data_filter_conditions,
                         input_data_filter_conditions=input_data_filter_conditions,
                         global_rect=global_rect,
                         convex_hull=convex_hull,
                         reference_material_file_path=reference_material_file_path,
                         reference_material_gdf=reference_material_gdf,
                         reference_material_filter_conditions=reference_material_filter_conditions)

        # 将真值停止线数据帧赋值给实例变量
        self.truth_stopline_gdf = self.truth_data_gdf
        self.input_stopline_gdf = self.pruned_input_gdf
        # 合并真值停止线
        self.merged_truth_stopline_gdf = self.__merge_lines(self.truth_stopline_gdf)

    @staticmethod
    def __merge_lines(gdf):
        """
        合并GeoDataFrame中的线段为一个几何对象。

        :param gdf: 包含线几何的GeoDataFrame。
        :return: 合并后的GeoDataFrame，包含合并后的几何和长度信息。
        """
        merged_geometry = unary_union(gdf['geometry'])

        if merged_geometry.geom_type == 'MultiLineString':
            # 如果是MultiLineString，使用linemerge合并连续的LineString
            merged_lines = list(linemerge(merged_geometry).geoms)
        else:
            # 本身就是LineString，直接转换为列表
            merged_lines = [merged_geometry]

        # 创建一个新的GeoDataFrame来存储合并后的几何
        merged_gdf = gpd.GeoDataFrame(geometry=merged_lines, crs=gdf.crs)
        merged_gdf['length'] = merged_gdf['geometry'].length  # 计算每条线的长度
        return merged_gdf

    @staticmethod
    def __ignore_z(line: LineString):
        """
        忽视LineString的Z坐标，只返回XY坐标。

        :param line: 输入的LineString对象。
        :return: 忽略Z坐标后的LineString对象。
        """
        if line.has_z:
            return LineString([(x, y) for x, y, z in line.coords])
        return line

    @staticmethod
    def calculate_direction(line):
        """
        计算线段的方向向量。

        :param line: 输入的LineString对象。
        :return: 单位方向向量。
        """
        start_point = np.array(line.coords[0])  # 起点
        end_point = np.array(line.coords[-1])  # 终点
        direction_vector = end_point - start_point  # 方向向量
        direction_vector = direction_vector / np.linalg.norm(direction_vector)  # 单位化
        return direction_vector

    @classmethod
    def calculate_angle_between_lines(cls, line1, line2):
        """
        计算两条线段之间的夹角。

        :param line1: 第一条线段。
        :param line2: 第二条线段。
        :return: 线段之间的夹角（度）。
        """
        dir1 = cls.calculate_direction(line1)  # 计算第一条线的方向
        dir2 = cls.calculate_direction(line2)  # 计算第二条线的方向
        dot_product = np.dot(dir1, dir2)  # 点积
        angle = np.arccos(np.clip(dot_product, -1.0, 1.0))  # 计算夹角
        return np.degrees(angle)  # 返回度数

    @staticmethod
    def calculate_centroid_distance(line1, line2):
        """
        计算两条线段的质心距离。

        :param line1: 第一条线段。
        :param line2: 第二条线段。
        :return: 两条线段质心之间的距离。
        """
        centroid1 = np.array(line1.centroid.coords[0])  # 计算第一条线段的质心
        centroid2 = np.array(line2.centroid.coords[0])  # 计算第二条线段的质心
        return np.linalg.norm(centroid1 - centroid2)  # 返回质心距离

    @classmethod
    def ensure_same_direction(cls, truth_line, input_line):
        """
        确保输入线与真值线方向相同。如果不同，则反转输入线。

        :param truth_line: 真值线段。
        :param input_line: 输入线段。
        :return: 方向相同的输入线段。
        """
        truth_direction = cls.calculate_direction(truth_line)  # 真值线的方向
        input_direction = cls.calculate_direction(input_line)  # 输入线的方向

        if np.dot(truth_direction, input_direction) < 0:
            input_line = LineString(input_line.coords[::-1])  # 反转输入线
        return input_line

    @staticmethod
    def hausdorff_distance(line1, line2):
        """
        计算两条线段之间的对称Hausdorff距离。

        :param line1: 第一条线段。
        :param line2: 第二条线段。
        :return: Hausdorff距离。
        """
        return 0
        # return max(directed_hausdorff(line1.coords, line2.coords)[0],
        #            directed_hausdorff(line2.coords, line1.coords)[0])

    def match_lines(self, angle_threshold=45, distance_threshold=5):
        """
        匹配真值停止线与输入停止线，基于角度和距离阈值。

        :param angle_threshold: 匹配时允许的最大角度（度）。
        :param distance_threshold: 匹配时允许的最大质心距离（米）。
        :return: 匹配结果和未匹配的输入线。
        """
        matches = []
        used_input_lines = set()  # 用于记录已匹配的输入线

        for truth_line in self.merged_truth_stopline_gdf['geometry']:
            best_match = None
            min_combined_metric = float('inf')  # 最小组合度量初始化为无穷大

            for input_line in self.input_stopline_gdf['geometry']:
                if input_line in used_input_lines:
                    continue  # 跳过已匹配的线

                # 确保输入线与真值线方向一致
                aligned_input_line = self.ensure_same_direction(truth_line, input_line)

                # 计算角度和质心距离
                angle = self.calculate_angle_between_lines(truth_line, aligned_input_line)
                angle = min(angle, 180 - angle)  # 取最小角度
                distance = self.calculate_centroid_distance(truth_line, input_line)
                len_diff = abs(truth_line.length - aligned_input_line.length)  # 长度差
                hausdorff = self.hausdorff_distance(truth_line, aligned_input_line)  # Hausdorff距离

                # 检查条件是否满足
                if angle < angle_threshold and distance < distance_threshold:
                    combined_metric = 0.1 * angle + 0.4 * distance + 0.2 * len_diff + 0.3 * hausdorff
                    if combined_metric < min_combined_metric:  # 更新最佳匹配
                        min_combined_metric = combined_metric
                        best_match = input_line

            # 如果没有找到匹配的输入线
            if best_match is None:
                matches.append((truth_line, best_match))
            else:
                matches.append((truth_line, best_match))
                used_input_lines.add(best_match)  # 标记此线为已使用

        # 确定未匹配的输入线
        unmatches = [line for line in self.input_stopline_gdf['geometry'] if line not in used_input_lines]

        return matches, unmatches

    def match_lines_based_on_buffer(self, true_lines, input_lines):
        """
        基于缓冲区匹配真值线与输入线。

        :param true_lines: 真值线段列表。
        :param input_lines: 输入线段列表。
        :return: 匹配结果和未匹配的输入线。
        """
        matched = {}
        unmatched = copy.deepcopy(input_lines.tolist())
        candidate_pairs = []  # 存储所有候选对

        for true_line in true_lines:
            buffer = true_line.buffer(true_line.length / 2)  # 创建真值线的缓冲区

            candidates = []
            for input_line in unmatched:
                if input_line.intersects(buffer):  # 检查输入线是否与缓冲区相交
                    aligned_input_line = self.ensure_same_direction(true_line, input_line)  # 确保方向一致
                    hausdorff_dist = self.hausdorff_distance(true_line, aligned_input_line)  # 计算Hausdorff距离
                    angle = self.calculate_angle_between_lines(true_line, aligned_input_line)  # 计算角度
                    candidates.append((input_line, hausdorff_dist, angle))

            if candidates:
                candidates.sort(key=lambda x: (x[1], x[2]))  # 根据Hausdorff距离和角度排序
                best_match = candidates[0][0]  # 选择最佳匹配
                matched[true_line] = best_match
                candidate_pairs.append((true_line, best_match, candidates))

        # 检查重复匹配并解决冲突
        used_inputs = set()
        final_matches = []
        for true_line, best_match, candidates in candidate_pairs:
            if best_match not in used_inputs:
                final_matches.append((true_line, best_match))
                used_inputs.add(best_match)
            else:
                # 尝试找到下一个最佳匹配
                for candidate in candidates[1:]:
                    next_best_match = candidate[0]
                    if next_best_match not in used_inputs:
                        final_matches.append((true_line, next_best_match))
                        used_inputs.add(next_best_match)
                        break

        # 确定未匹配的输入线
        unmatched_inputs = [line for line in unmatched if line not in used_inputs]

        return final_matches, unmatched_inputs

    def calculate_metrics(self, matches, unmatches):
        """
        计算评测指标：准确率、精确率和召回率。

        :param matches: 匹配结果列表。
        :param unmatches: 未匹配的输入线列表。
        :return: 准确率、精确率和召回率。
        """
        # TP: 每个输入停止线都有对应的真值线
        true_positives = sum(1 for truth, match in matches if match is not None)
        # FN: 每个真值停止线没有匹配到输入线
        false_negatives = sum(1 for truth, match in matches if match is None)
        # FP: 每条输入线应该匹配真值线，但实际上没有匹配上
        false_positives = len(unmatches)

        recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
        precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
        accuracy = true_positives / len(self.input_stopline_gdf) if len(self.input_stopline_gdf) > 0 else 0

        return accuracy, precision, recall

    def evaluate(self, task_name: Optional[str]):
        """
        评测方法，用于执行线段匹配。
        :param task_name: 任务名称
        """
        matches, unmatches = self.match_lines()  # 执行线段匹配
        return self.generate_evaluate_result(title=task_name, matches=matches, unmatches=unmatches)

    def generate_evaluate_result(self, title, matches, unmatches):

        accuracy, precision, recall = self.calculate_metrics(matches, unmatches)  # 计算指标

        angles = []
        hausdorffs = []
        center_distances = []
        diffs = []
        for truth_line, matched_line in matches:
            if matched_line:
                # 计算各项统计信息
                h_distance = self.hausdorff_distance(truth_line, matched_line)
                angle = self.calculate_angle_between_lines(truth_line, matched_line)
                angle = min(angle, 180 - angle)  # 最小角度
                center_distance = self.calculate_centroid_distance(truth_line, matched_line)
                diff = abs(truth_line.length - matched_line.length)  # 长度差
                angles.append(angle)
                hausdorffs.append(h_distance)
                center_distances.append(center_distance)
                diffs.append(diff)

        res = StopLineEvaluateResult(
            title=title,
            accuracy=accuracy,
            precision=precision,
            recall=recall,

            matches=matches,
            unmatches=unmatches,

            max_hausdorff=np.max(hausdorffs) if hausdorffs else np.inf,
            min_hausdorff=np.min(hausdorffs) if hausdorffs else np.inf,

            max_rotate_angle=np.max(angles) if angles else np.inf,
            min_rotate_angle=np.min(angles) if angles else np.inf,

            max_len_diff=np.max(diffs) if diffs else np.inf,
            min_len_diff=np.min(diffs) if diffs else np.inf
        )

        stats_text = (
            f"准确率: {res.accuracy * 100:.2f}%\n"
            f"召回率: {res.recall * 100:.2f}%\n"
            f"F1分数: {res.f1_score: .4f}\n"
            f"Hausdorff最大距离(米): {res.max_hausdorff: .2f}\n"
            f"Hausdorff最小距离(米): {res.min_hausdorff: .2f}\n"
            f"最大偏转角: {res.max_rotate_angle: .2f}\n"
            f"最小偏转角: {res.min_rotate_angle: .2f}\n"
            f"最大长度差(米): {res.max_len_diff: .2f}\n"
            f"最小长度差(米): {res.min_len_diff: .2f}"
        )

        logger.info(f"\n评测任务:{title} 结论:\n{stats_text}")  # 记录评测结论
        return res

    def visualize(self,
                  result: StopLineEvaluateResult,
                  reference_material_gdf=GeoDataFrame(columns=['geometry']),
                  is_visualize=False,
                  save_vector_file=False,
                  output_svg_path=None):
        fig, ax = plt.subplots(figsize=(12, 9))  # 创建绘图窗口

        if reference_material_gdf.empty:
            reference_material_gdf = self.reference_material_gdf

        if not reference_material_gdf.empty:
            reference_material_gdf.plot(ax=ax, edgecolor='#0f0f0f80', alpha=0.06)  # 绘制参考材料

        # 绘制所有未匹配的输入线
        if result.unmatches:
            for line in result.unmatches:
                x, y = line.xy
                ax.plot(x, y, 'red', alpha=0.5, label='未匹配输入停止线')

        # 绘制真值线（已匹配）
        for line in self.truth_stopline_gdf['geometry']:
            x, y = line.xy
            ax.plot(x, y, 'orange', linewidth=2, label='已匹配真值停止线')

        # 绘制已匹配的输入线，并连接质心
        line_show_info = {}
        if result.matches:
            for truth_line, matched_line in result.matches:
                if matched_line:
                    x, y = np.array(matched_line.xy)
                    ax.plot(x, y, 'green', linewidth=2, label='已匹配输入停止线')

                    # 计算各项统计信息
                    h_distance = self.hausdorff_distance(truth_line, matched_line)
                    angle = self.calculate_angle_between_lines(truth_line, matched_line)
                    angle = min(angle, 180 - angle)  # 最小角度
                    center_distance = self.calculate_centroid_distance(truth_line, matched_line)
                    diff = abs(truth_line.length - matched_line.length)  # 长度差
                    line_show_info[truth_line] = {
                        "x": x.max() + 1,
                        "y": y.mean(),
                        "truth_length": truth_line.length,
                        "matched_length": matched_line.length,
                        "diff": diff,
                        "hausdorff": h_distance,
                        "angle": angle,
                        "center_distance": center_distance
                    }

                    # 绘制连接质心的线
                    truth_centroid = truth_line.centroid
                    matched_centroid = matched_line.centroid
                    ax.plot([truth_centroid.x, matched_centroid.x],
                            [truth_centroid.y, matched_centroid.y], 'k--', linewidth=1)
                else:
                    x, y = np.array(truth_line.xy)
                    ax.plot(x, y, color='purple', linewidth=2, label='未匹配真值停止线')

        # 去重处理图例
        handles, labels = ax.get_legend_handles_labels()
        by_label = {}
        for h, l in zip(handles, labels):
            if l not in by_label:
                by_label[l] = h
        ax.legend(by_label.values(), by_label.keys())  # 绘制图例

        ax.set_title(result.title)
        ax.set_xlabel('X轴')
        ax.set_ylabel('Y轴')

        stats_text = result.format_text

        props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
        ax.text(1.01, 0.5, stats_text, transform=ax.transAxes, fontsize=10,
                verticalalignment='center', bbox=props)  # 显示统计信息文本

        annot = ax.annotate(text="",
                            xy=(0, 0),
                            xytext=(20, 20),
                            textcoords="offset points",
                            bbox=dict(boxstyle="round", fc="w"),
                            arrowprops=dict(arrowstyle="->"))
        annot.set_visible(False)  # 初始状态下隐藏注释框

        def hover(event):
            """
            鼠标悬停事件处理函数，用于显示最近线段的信息。

            :param event: 事件对象。
            """
            if event.inaxes != ax:
                return

            min_distance = float('inf')
            closest_line = None
            for line in list(line_show_info.keys()):
                distance = line.distance(Point(event.xdata, event.ydata))  # 计算当前鼠标位置到线段的距离
                if distance < min_distance:
                    min_distance = distance
                    closest_line = line

            if closest_line and min_distance < 1:
                x, y = closest_line.interpolate(closest_line.project(Point(event.xdata, event.ydata))).xy
                annot.xy = (x[0], y[0])  # 设置注释框的位置

                show_info = line_show_info[closest_line]
                truth_length = show_info['truth_length']
                matched_length = show_info['matched_length']
                diff = show_info['diff']
                hausdorff = show_info['hausdorff']
                angle = show_info['angle']
                center_distance = show_info['center_distance']
                line_stat = (
                    f"真值长度: {truth_length: 2f}\n"
                    f"输入值长度: {matched_length: 2f}\n"
                    f"长度差: {diff}\n"
                    f'Hausdorff距离: {hausdorff: 2f}\n'
                    f'偏转角度: {angle: 2f}\n'
                    f'质心距离: {center_distance: 2f}'
                )
                annot.set_text(line_stat)  # 更新注释文本
                annot.set_visible(True)  # 显示注释框
                fig.canvas.draw_idle()  # 刷新画布
            else:
                if annot.get_visible():
                    annot.set_visible(False)  # 隐藏注释框
                    fig.canvas.draw_idle()

            # 连接鼠标移动事件到hover函数

        fig.canvas.mpl_connect("motion_notify_event", hover)

        plt.grid(True)  # 显示网格
        if output_svg_path and save_vector_file:
            # 获取文件的目录路径
            directory = os.path.dirname(output_svg_path)

            # 检查目录是否存在，如果不存在则创建
            if directory and not os.path.exists(directory):
                os.makedirs(directory)

            logger.debug(f"保存到{output_svg_path}")  # 记录保存路径
            # 保存图形
            plt.savefig(output_svg_path, format='svg', bbox_inches='tight')  # 矢量格式

        if is_visualize:
            plt.show()  # 显示可视化图形