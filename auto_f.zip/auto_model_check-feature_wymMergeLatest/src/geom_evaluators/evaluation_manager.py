import os
import re

from pandas import DataFrame, MultiIndex

from src.logger import logger
import pandas as pd

from src.model import Config
from src.tools.common import extract_filename
from src.tools.config_manager import ConfigManager
from src.geom_evaluators.line_evaluator import LaneLineEvaluator, RoadBoundaryEvaluator, CenterLineEvaluator
from src.geom_evaluators.polygon_evaluator import PolygonEvaluator
from src.geom_evaluators.marking_evaluator import LaneMarkingEvaluator
from src.geom_evaluators.stopline_evaluator import StopLineEvaluator
from src.geom_evaluators.trafficlight_evaluator import TrafficlightEvaluator


def get_report_df(line_buffer_distance: float = 0.5, cross_walk_search_distance: float = 5,
                  stopline_search_distance: float = 5, arrow_search_distance: float = 1,
                  trafficlight_search_distance: float = 1) -> (DataFrame, MultiIndex):
    """设置输出报告Dataframe"""
    single_level_columns = [
        '数据版本',
        '路口代号'
    ]
    multi_level_columns = [
        ('车道线', str(line_buffer_distance), '准确率'),
        ('车道线', str(line_buffer_distance), '召回率'),
        ('车道线', str(line_buffer_distance), 'F1分数'),
        ('车道线(仅矢量化)', str(line_buffer_distance), '准确率'),
        ('车道线(仅矢量化)', str(line_buffer_distance), '召回率'),
        ('车道线(仅矢量化)', str(line_buffer_distance), 'F1分数'),
        ('道路边界', str(line_buffer_distance), '准确率'),
        ('道路边界', str(line_buffer_distance), '召回率'),
        ('道路边界', str(line_buffer_distance), 'F1分数'),
        ('道路边界(仅矢量化)', str(line_buffer_distance), '准确率'),
        ('道路边界(仅矢量化)', str(line_buffer_distance), '召回率'),
        ('道路边界(仅矢量化)', str(line_buffer_distance), 'F1分数'),
        ('人行横道', str(cross_walk_search_distance), '输入面积准确率'),
        ('人行横道', str(cross_walk_search_distance), '输入面积召回率'),
        ('人行横道', str(cross_walk_search_distance), '整体平均H距离'),
        ('人行横道', str(cross_walk_search_distance), '输入数/真值数'),
        ('人行横道', str(cross_walk_search_distance), '整体IOU'),
        ('停止线', str(stopline_search_distance), '准确率'),
        ('停止线', str(stopline_search_distance), '召回率'),
        ('停止线', str(stopline_search_distance), 'F1分数'),
        ('地面箭头', str(arrow_search_distance), '准确率'),
        ('地面箭头', str(arrow_search_distance), '召回率'),
        ('地面箭头', str(arrow_search_distance), 'F1分数'),
        ('信号灯', str(trafficlight_search_distance), '准确率'),
        ('信号灯', str(trafficlight_search_distance), '召回率'),
        ('信号灯', str(trafficlight_search_distance), 'F1分数')
    ]
    single_level_columns = [(col, '', '') for col in single_level_columns]
    all_columns = single_level_columns + multi_level_columns
    columns = pd.MultiIndex.from_tuples(all_columns, names=['要素类型', '缓冲区（米）', '指标'])

    return pd.DataFrame(columns=columns), columns


def build_file_path(base_dir: str, *paths: str) -> str:
    """
    构建文件路径

    :param base_dir: 基础目录
    :param paths: 相对路径部分
    :return: 完整的文件路径
    """
    return os.path.join(base_dir, *paths)


def ensure_directory_exists(base_dir: str, *paths: str) -> str:
    """
    构建文件路径

    :param base_dir: 基础目录
    :param paths: 相对路径部分
    :return: 完整的文件路径
    """
    directory = os.path.join(base_dir, *paths)
    if not os.path.exists(directory):
        os.makedirs(directory)
    return directory


class EvaluationManager:
    def __init__(self, config_path="./config.yaml"):
        """
        初始化评测管理类，加载配置与任务设置。

        :param config_path: 配置文件路径。
        :param config_path: 任务设置文件路径。
        """

        # config_name也就是配置文件名作为任务名称
        self.config_name = extract_filename(config_path)

        self.config_manager = ConfigManager()
        self.cfg: Config = self.config_manager.load_config(config_path)

        if self.cfg.config.evaluate_rect_setting and self.cfg.config.evaluate_rect_setting.is_limit_by_rects:
            self.global_rect = self.cfg.config.evaluate_rect_setting.rects[0].geom
        else:
            self.global_rect = None

        self.tool_config = self.cfg.config
        self.tasks = self.cfg.tasks

        # 检查配置有效性
        if not self.cfg.versions:
            raise Exception("没有传入有效的版本资料")
        if not self.cfg.config.file_paths:
            raise Exception(f"请检查数据路径：{self.cfg.config.file_paths}")

        self.truth_file_dir = build_file_path(self.cfg.config.file_paths.data_path,
                                              self.cfg.config.file_paths.truth_data_path)
        self.input_data_path = build_file_path(self.cfg.config.file_paths.data_path,
                                               self.cfg.config.file_paths.input_data_path)
        self.output_data_path = build_file_path(self.cfg.config.file_paths.data_path,
                                                self.cfg.config.file_paths.output_data_path)

    def do_execute_tasks(self):
        """
        执行评测任务，遍历团队数据并调用相应的评测器执行评测。
        """
        truth_ = self.tool_config.truth_file_profile

        # FIXME
        truth_file_dir = self.truth_file_dir
        input_data_path = self.input_data_path
        output_data_path = self.output_data_path

        visualize_control = self.cfg.config.is_visualize
        team_data_info = self.cfg.versions
        line_buffer_distance = self.cfg.config.params.line_buffer_length_meter
        lane_marking_match_distance_cm = self.cfg.config.params.lane_marking_match_distance_cm

        tasks = self.cfg.tasks

        df, columns = get_report_df()

        for input_data in team_data_info:
            for task in tasks:
                tag = task.name  # 任务名称（路口代号）

                # TODO 这个是寻找真值的逻辑，后面抽出去重新写
                input_name = re.search(r'batch-\d+', tag).group(0)
                input_folder_path = build_file_path(input_data_path, input_data.version, input_data.nickname, input_name)

                if os.path.exists(input_folder_path):

                    new_row = pd.Series(index=columns)
                    new_row['路口代号'] = tag
                    new_row['数据版本'] = input_data.version + '_' + input_data.nickname
                    truth_laneline_path = build_file_path(truth_file_dir, tag,
                                                          f"{truth_.lane_line.prefix}."
                                                          f"{truth_.lane_line.suffix}")
                    truth_laneline_filter_cond = truth_.lane_line.filter_conditions.dict() if truth_.lane_line.filter_conditions else None
                    all_shp_files = os.listdir(input_folder_path)
                    task_output = os.path.join(output_data_path, input_data.version, input_data.nickname, tag)
                    task_output_path = ensure_directory_exists(task_output)
                    # 如果需要评测车道线
                    if task.evaluate_laneline:
                        pattern = re.compile(r"^lane_boundary.*\.shp$")
                        lane_boundary_files = [file for file in all_shp_files if pattern.match(file)]
                        truth_file_path = build_file_path(truth_file_dir, tag,
                                                          f"{truth_.lane_line.prefix}."
                                                          f"{truth_.lane_line.suffix}")
                        truth_data_filter_cond = truth_.lane_line.filter_conditions.dict() if truth_.lane_line.filter_conditions else None
                        for file_name in lane_boundary_files:
                            input_file_path = os.path.join(input_folder_path, file_name)
                            input_file_filter_cond = input_data.lane_line.filter_conditions.dict() if input_data.lane_line.filter_conditions else None
                            if os.path.isfile(input_file_path):
                                try:
                                    le = LaneLineEvaluator(
                                        truth_lines_file_path=truth_file_path,
                                        truth_data_filter_conditions=truth_data_filter_cond,
                                        input_lines_file_path=input_file_path,
                                        input_data_filter_conditions=input_file_filter_cond,
                                        output_file_path=task_output_path,
                                        global_rect=self.global_rect,
                                    )
                                    task_name = f"{input_data.version}-{input_data.nickname}-{tag}-{file_name}-车道线(缓冲区{line_buffer_distance}米)"
                                    result = le.evaluate(
                                        task_name=task_name,
                                        buffer_distance=line_buffer_distance)
                                    le.visualize(result=result,
                                                 is_visualize=visualize_control,
                                                 gpkg_path=build_file_path(task_output_path, f"{task_name}.gpkg"),
                                                 save_as_vector=self.cfg.config.is_save_svg,
                                                 output_svg_path=build_file_path(task_output_path, f"{task_name}.svg")
                                                 )
                                    if file_name == 'lane_boundary.shp':
                                        new_row[('车道线', str(line_buffer_distance), '准确率')] = format(
                                            result.precision * 100, ".4f") + "%"
                                        new_row[('车道线', str(line_buffer_distance), '召回率')] = format(
                                            result.recall * 100, ".4f") + "%"
                                        new_row[('车道线', str(line_buffer_distance), 'F1分数')] = format(
                                            result.f1_score, ".4f")
                                    else:
                                        new_row[('车道线(仅矢量化)', str(line_buffer_distance), '准确率')] = format(
                                            result.precision * 100, ".4f") + "%"
                                        new_row[('车道线(仅矢量化)', str(line_buffer_distance), '召回率')] = format(
                                            result.recall * 100, ".4f") + "%"
                                        new_row[('车道线(仅矢量化)', str(line_buffer_distance), 'F1分数')] = format(
                                            result.f1_score, ".4f")
                                except Exception as e:
                                    logger.exception(
                                        f"任务：{input_data.version}-{input_data.nickname}-{file_name}-{tag}--车道线 执行失败，错误详情{e}")
                            else:
                                logger.error(
                                    f"任务：{input_data.version}-{input_data.nickname}--{file_name}{tag}无有效车道线文件输入: {input_file_path}")
                    #
                    # # 如果需要评测道路边界
                    # if task.evaluate_boundary:
                    #     pattern = re.compile(r"^road_boundary.*\.shp$")
                    #     road_boundary_files = [file for file in all_shp_files if pattern.match(file)]
                    #     truth_file_path = build_file_path(truth_file_dir, tag,
                    #                                       f"{truth_.road_boundary.prefix}."
                    #                                       f"{truth_.road_boundary.suffix}")
                    #     truth_laneline_file_path = build_file_path(truth_file_dir, tag,
                    #                                                f"{truth_.lane_line.prefix}."
                    #                                                f"{truth_.lane_line.suffix}")
                    #     truth_data_filter_cond = truth_.road_boundary.filter_conditions.dict() if truth_.road_boundary.filter_conditions else None
                    #
                    #     for file_name in road_boundary_files:
                    #         input_file_path = os.path.join(input_folder_path, file_name)
                    #         input_file_filter_cond = input_data.road_boundary.filter_conditions.dict() if input_data.road_boundary.filter_conditions else None
                    #         if os.path.isfile(input_file_path):
                    #             try:
                    #                 le = RoadBoundaryEvaluator(
                    #                     truth_boundary_file_path=truth_file_path,
                    #                     truth_data_filter_conditions=truth_data_filter_cond,
                    #                     input_boundary_file_path=input_file_path,
                    #                     input_data_filter_conditions=input_file_filter_cond,
                    #                     output_file_path=task_output_path,
                    #                     reference_material_file_path=truth_laneline_file_path,
                    #                     reference_material_filter_conditions=truth_.lane_line.filter_conditions.dict() if truth_.lane_line.filter_conditions else None,
                    #                     global_rect=self.global_rect,
                    #                     truth_convex_file_path=truth_laneline_path,
                    #                     truth_convex_filter_conditions=truth_laneline_filter_cond
                    #                 )
                    #                 task_name = f"{input_data.version}-{input_data.nickname}-{tag}-{file_name}-道路边界(缓冲区{line_buffer_distance}米)"
                    #                 result = le.evaluate(
                    #                     task_name=task_name,
                    #                     buffer_distance=line_buffer_distance)
                    #                 le.visualize(result=result,
                    #                              is_visualize=visualize_control,
                    #                              gpkg_path=build_file_path(task_output_path, f"{task_name}.gpkg"),
                    #                              save_as_vector=self.cfg.config.is_save_svg,
                    #                              output_svg_path=build_file_path(task_output_path, f"{task_name}.svg")
                    #                              )
                    #                 if file_name == 'road_boundary.shp':
                    #                     new_row[('道路边界', str(line_buffer_distance), '准确率')] = format(
                    #                         result.precision * 100, ".4f") + "%"
                    #                     new_row[('道路边界', str(line_buffer_distance), '召回率')] = format(
                    #                         result.recall * 100, ".4f") + "%"
                    #                     new_row[('道路边界', str(line_buffer_distance), 'F1分数')] = format(
                    #                         result.f1_score, ".4f")
                    #                 else:
                    #                     new_row[('道路边界(仅矢量化)', str(line_buffer_distance), '准确率')] = format(
                    #                         result.precision * 100, ".4f") + "%"
                    #                     new_row[('道路边界(仅矢量化)', str(line_buffer_distance), '召回率')] = format(
                    #                         result.recall * 100, ".4f") + "%"
                    #                     new_row[('道路边界(仅矢量化)', str(line_buffer_distance), 'F1分数')] = format(
                    #                         result.f1_score, ".4f")
                    #             except Exception as e:
                    #                 logger.exception(
                    #                     f"任务：{input_data.version}-{input_data.nickname}-{file_name}-{tag}--道路边界 执行失败，错误详情{e}")
                    #         else:
                    #             logger.error(
                    #                 f"任务：{input_data.version}-{input_data.nickname}-{file_name}-{tag}无有效道路边界文件输入: {input_file_path}")
                    #
                    # if task.evaluate_centerline:
                    #     truth_file_path = build_file_path(truth_file_dir, tag,
                    #                                       f"{truth_.lane_center.prefix}."
                    #                                       f"{truth_.lane_center.suffix}")
                    #     input_file_path = build_file_path(input_data_path, input_data.nickname, input_name,
                    #                                       f"{input_data.lane_center.prefix}."
                    #                                       f"{input_data.lane_center.suffix}")
                    #     truth_laneline_file_path = build_file_path(truth_file_dir, tag,
                    #                                                f"{truth_.lane_line.prefix}."
                    #                                                f"{truth_.lane_line.suffix}")
                    #     truth_data_filter_cond = truth_.lane_center.filter_conditions.dict() if truth_.lane_center.filter_conditions else None
                    #     input_file_filter_cond = input_data.lane_center.filter_conditions.dict() if input_data.lane_center.filter_conditions else None
                    #
                    #     if os.path.isfile(input_file_path):
                    #         try:
                    #             le = CenterLineEvaluator(
                    #                 truth_centerline_file_path=truth_file_path,
                    #                 truth_data_filter_conditions=truth_data_filter_cond,
                    #                 input_centerline_file_path=input_file_path,
                    #                 input_data_filter_conditions=input_file_filter_cond,
                    #                 output_file_path=task_output_path,
                    #                 reference_material_file_path=truth_laneline_file_path,
                    #                 reference_material_filter_conditions=truth_.lane_line.filter_conditions.dict() if truth_.lane_line.filter_conditions else None,
                    #                 global_rect=self.global_rect,
                    #                 truth_convex_file_path=truth_laneline_path,
                    #                 truth_convex_filter_conditions=truth_laneline_filter_cond
                    #             )
                    #             task_name = f"{input_data.version}-{input_data.nickname}-{tag}--车道中心线(缓冲区{line_buffer_distance}米)"
                    #             result = le.evaluate(
                    #                 task_name=task_name,
                    #                 buffer_distance=line_buffer_distance)
                    #             le.visualize(result=result,
                    #                          is_visualize=visualize_control,
                    #                          save_as_vector=self.cfg.config.is_save_svg,
                    #                          gpkg_path=build_file_path(task_output_path, f"{task_name}.gpkg"),
                    #                          output_svg_path=build_file_path(task_output_path, f"{task_name}.svg")
                    #                          )
                    #         except Exception as e:
                    #             logger.exception(
                    #                 f"任务：{input_data.version}-{input_data.nickname}-{tag}--车道中心线 执行失败，错误详情{e}")
                    #     else:
                    #         logger.error(
                    #             f"任务：{input_data.version}-{input_data.nickname}-{tag}无有效车道中心线文件输入: {input_file_path}")
                    #
                    # # 如果需要评测人行横道
                    # if task.evaluate_crosswalks and truth_.crosswalk:
                    #     truth_file_path = build_file_path(truth_file_dir, tag,
                    #                                       f"{truth_.crosswalk.prefix}."
                    #                                       f"{truth_.crosswalk.suffix}")
                    #     input_file_path = build_file_path(input_data_path, input_data.version,
                    #                                       input_data.nickname, input_name,
                    #                                       f"{input_data.crosswalk.prefix}."
                    #                                       f"{input_data.crosswalk.suffix}")
                    #     truth_laneline_file_path = build_file_path(truth_file_dir, tag,
                    #                                                f"{truth_.lane_line.prefix}."
                    #                                                f"{truth_.lane_line.suffix}")
                    #     truth_data_filter_cond = truth_.crosswalk.filter_conditions.dict() if truth_.crosswalk.filter_conditions else None
                    #     input_file_filter_cond = input_data.crosswalk.filter_conditions.dict() if input_data.crosswalk.filter_conditions else None
                    #
                    #     if input_data.crosswalk.prefix and os.path.isfile(input_file_path):
                    #         try:
                    #             task_name = f"{input_data.version}-{input_data.nickname}-{tag}--人行横道(最大判定距离{5}米)"
                    #             pe = PolygonEvaluator(
                    #                 truth_polygons_file_path=truth_file_path,
                    #                 truth_data_filter_conditions=truth_data_filter_cond,
                    #                 input_polygons_file_path=input_file_path,
                    #                 input_data_filter_conditions=input_file_filter_cond,
                    #                 output_file_path=task_output_path,
                    #                 reference_material_file_path=truth_laneline_file_path,
                    #                 global_rect=self.global_rect,
                    #                 truth_convex_file_path=truth_laneline_path,
                    #                 truth_convex_filter_conditions=truth_laneline_filter_cond
                    #             )
                    #             result = pe.evaluate(task_name=task_name, max_centroid_distance=5)
                    #             summary = pe.visualize(
                    #                 summary=result,
                    #                 is_visualize=visualize_control,
                    #                 gpkg_path=build_file_path(task_output_path, f"{task_name}.gpkg"),
                    #                 output_svg_path=build_file_path(task_output_path, f"{task_name}.svg"),
                    #                 verbose_plot=False
                    #             )
                    #             new_row[('人行横道', '5', '输入面积准确率')] = format(summary['输入面积准确率'],
                    #                                                                   ".4f") + "%"
                    #             new_row[('人行横道', '5', '输入面积召回率')] = format(summary['输入面积召回率'],
                    #                                                                   ".4f") + "%"
                    #             new_row[('人行横道', '5', '整体平均H距离')] = format(summary['整体平均H距离'], ".4f")
                    #             new_row[('人行横道', '5', '输入数/真值数')] = summary['输入个数/真值个数']
                    #             new_row[('人行横道', '5', '整体IOU')] = format(summary['整体IOU'], ".4f")
                    #         except Exception as e:
                    #             logger.exception(
                    #                 f"任务：{input_data.version}-{input_data.nickname}-{tag}众源融合成果评测--人行横道 执行失败，错误详情{e}")
                    #     else:
                    #         logger.error(
                    #             f"任务：{input_data.version}-{input_data.nickname}-{tag}无有效人行横道文件输入:{input_file_path}")
                    #
                    # # 如果需要评测停止线
                    # if task.evaluate_stoplines and truth_.stop_line:
                    #     truth_file_path = build_file_path(truth_file_dir, tag,
                    #                                       f"{truth_.stop_line.prefix}."
                    #                                       f"{truth_.stop_line.suffix}")
                    #     input_file_path = build_file_path(input_data_path, input_data.version,
                    #                                       input_data.nickname, input_name,
                    #                                       f"{input_data.stop_line.prefix}."
                    #                                       f"{input_data.stop_line.suffix}")
                    #     truth_laneline_file_path = build_file_path(truth_file_dir, tag,
                    #                                                f"{truth_.lane_line.prefix}."
                    #                                                f"{truth_.lane_line.suffix}")
                    #     truth_data_filter_cond = truth_.stop_line.filter_conditions.dict() if truth_.stop_line.filter_conditions else None
                    #     input_file_filter_cond = input_data.crosswalk.filter_conditions.dict() if input_data.stop_line.filter_conditions else None
                    #
                    #     if os.path.isfile(input_file_path):
                    #         try:
                    #             task_name = f"{input_data.version}-{input_data.nickname}-{tag}--停止线(最大判定距离5米)"
                    #             evaluator = StopLineEvaluator(
                    #                 truth_stopline_file_path=truth_file_path,
                    #                 truth_data_filter_conditions=truth_data_filter_cond,
                    #                 input_stopline_file_path=input_file_path,
                    #                 input_data_filter_conditions=input_file_filter_cond,
                    #                 output_file_path=task_output_path,
                    #                 reference_material_file_path=truth_laneline_file_path,
                    #                 global_rect=self.global_rect,
                    #                 truth_convex_file_path=truth_laneline_path,
                    #                 truth_convex_filter_conditions=truth_laneline_filter_cond
                    #             )
                    #             result = evaluator.evaluate(task_name=task_name)
                    #
                    #             evaluator.visualize(result=result,
                    #                                 gpkg_path=build_file_path(task_output_path, f"{task_name}.gpkg"),
                    #                                 output_svg_path=build_file_path(task_output_path,
                    #                                                                 f"{task_name}.svg"),
                    #                                 save_vector_file=self.cfg.config.is_save_svg,
                    #                                 is_visualize=visualize_control)
                    #             new_row[('停止线', '5', '准确率')] = format(result.precision * 100, ".4f") + "%"
                    #             new_row[('停止线', '5', '召回率')] = format(result.recall * 100, ".4f") + "%"
                    #             new_row[('停止线', '5', 'F1分数')] = format(result.f1_score, ".4f")
                    #         except Exception as e:
                    #             logger.exception(
                    #                 f"任务：{input_data.version}-{input_data.nickname}-{tag}--停止线 执行失败，错误详情{e}")
                    #     else:
                    #         logger.error(
                    #             f"任务：{input_data.version}-{input_data.nickname}-{tag}无有效停止线文件输入:{input_file_path}")
                    #
                    # # 如果需要评测地面标记
                    # if task.evaluate_landmarks and truth_.lane_marking:
                    #     truth_file_path = build_file_path(truth_file_dir, tag,
                    #                                       f"{truth_.lane_marking.prefix}."
                    #                                       f"{truth_.lane_marking.suffix}")
                    #     input_file_path = build_file_path(input_data_path, input_data.version,
                    #                                       input_data.nickname, input_name,
                    #                                       f"{input_data.lane_marking.prefix}."
                    #                                       f"{input_data.lane_marking.suffix}")
                    #     truth_laneline_file_path = build_file_path(truth_file_dir, tag,
                    #                                                f"{truth_.lane_line.prefix}."
                    #                                                f"{truth_.lane_line.suffix}")
                    #     truth_data_filter_cond = truth_.lane_marking.filter_conditions.dict() if truth_.lane_marking.filter_conditions else None
                    #     input_file_filter_cond = input_data.lane_marking.filter_conditions.dict() if input_data.lane_marking.filter_conditions else None
                    #
                    #     if os.path.isfile(input_file_path):
                    #         try:
                    #             buffer_distance = 1
                    #             task_name = f"{input_data.version}-{input_data.nickname}-{tag}--地面箭头(匹配范围半径{buffer_distance}米)"
                    #             lme = LaneMarkingEvaluator(
                    #                 truth_marking_file_path=truth_file_path,
                    #                 truth_data_filter_conditions=truth_data_filter_cond,
                    #                 input_marking_file_path=input_file_path,
                    #                 input_data_filter_conditions=input_file_filter_cond,
                    #                 output_file_path=task_output_path,
                    #                 reference_material_file_path=truth_laneline_file_path,
                    #                 global_rect=self.global_rect,
                    #                 truth_convex_file_path=truth_laneline_path,
                    #                 truth_convex_filter_conditions=truth_laneline_filter_cond
                    #             )
                    #
                    #             result = lme.evaluate(buffer_distance=buffer_distance, task_name=task_name)
                    #             lme.visualize(result=result,
                    #                           gpkg_path=build_file_path(task_output_path, f"{task_name}.gpkg"),
                    #                           output_svg_path=build_file_path(task_output_path, f"{task_name}.svg"),
                    #                           save_vector_file=self.cfg.config.is_save_svg,
                    #                           is_visualize=visualize_control)
                    #             new_row[('地面箭头', '1', '准确率')] = format(result.precision * 100, ".4f") + "%"
                    #             new_row[('地面箭头', '1', '召回率')] = format(result.recall * 100, ".4f") + "%"
                    #             new_row[('地面箭头', '1', 'F1分数')] = format(result.f1_score, ".4f")
                    #         except Exception as e:
                    #             logger.exception(
                    #                 f"任务：{input_data.version}-{input_data.nickname}-{tag}--地面箭头 执行失败，错误详情{e}")
                    #     else:
                    #         logger.error(
                    #             f"任务：{input_data.version}-{input_data.nickname}-{tag}无有效地面箭头文件输入:{input_file_path}")
                    #
                    # # 如果需要评测信号灯
                    # if task.evaluate_trafficlight and truth_.trafficlight:
                    #     truth_file_path = build_file_path(truth_file_dir, tag,
                    #                                       f"{truth_.trafficlight.prefix}."
                    #                                       f"{truth_.trafficlight.suffix}")
                    #     input_file_path = build_file_path(input_data_path, input_data.version,
                    #                                       input_data.nickname, input_name,
                    #                                       f"{input_data.trafficlight.prefix}."
                    #                                       f"{input_data.trafficlight.suffix}")
                    #     truth_laneline_file_path = build_file_path(truth_file_dir, tag,
                    #                                                f"{truth_.lane_line.prefix}."
                    #                                                f"{truth_.lane_line.suffix}")
                    #     truth_data_filter_cond = truth_.trafficlight.filter_conditions.dict() if truth_.trafficlight.filter_conditions else None
                    #     input_file_filter_cond = input_data.trafficlight.filter_conditions.dict() if input_data.trafficlight.filter_conditions else None
                    #
                    #     if os.path.isfile(input_file_path):
                    #         try:
                    #             buffer_distance = 2
                    #             task_name = f"{input_data.version}-{input_data.nickname}-{tag}--信号灯(匹配范围半径{buffer_distance}米)"
                    #             lme = TrafficlightEvaluator(
                    #                 truth_light_file_path=truth_file_path,
                    #                 truth_data_filter_conditions=truth_data_filter_cond,
                    #                 input_light_file_path=input_file_path,
                    #                 input_data_filter_conditions=input_file_filter_cond,
                    #                 output_file_path=task_output_path,
                    #                 reference_material_file_path=truth_laneline_file_path,
                    #                 global_rect=self.global_rect,
                    #                 truth_convex_file_path=truth_laneline_path,
                    #                 truth_convex_filter_conditions=truth_laneline_filter_cond
                    #             )
                    #
                    #             result = lme.evaluate(buffer_distance=buffer_distance, task_name=task_name)
                    #             lme.visualize(result=result,
                    #                           gpkg_path=build_file_path(task_output_path, f"{task_name}.gpkg"),
                    #                           output_svg_path=build_file_path(task_output_path, f"{task_name}.svg"),
                    #                           save_vector_file=self.cfg.config.is_save_svg,
                    #                           is_visualize=visualize_control)
                    #
                    #             new_row[('信号灯', '2', '准确率')] = format(result.precision * 100, ".4f") + "%"
                    #             new_row[('信号灯', '2', '召回率')] = format(result.recall * 100, ".4f") + "%"
                    #             new_row[('信号灯', '2', 'F1分数')] = format(result.f1_score, ".4f")
                    #         except Exception as e:
                    #             logger.exception(
                    #                 f"任务：{input_data.version}-{input_data.nickname}-{tag}--信号灯 执行失败，错误详情{e}")
                    #     else:
                    #         logger.error(
                    #             f"任务：{input_data.version}-{input_data.nickname}-{tag}无有效信号灯文件输入:{input_file_path}")
                    # df.loc[len(df)] = new_row

                    # TODO 用一个列表收集result，如果result列表是空那么不写
                    # 找出所有数字列
                    numeric_columns = df.select_dtypes(include=[float, int]).columns
                    # 将所有数字列转换为百分比格式并保留四位小数
                    for col in numeric_columns:
                        df[col] = df[col].apply(lambda x: f"{x * 100:.4f}%")
                    out_csv_path = os.path.join(self.output_data_path, input_data.version,
                                                input_data.version + '_evaluate_result.csv')
                    df.to_csv(out_csv_path)
                    print(f"指标汇总表格已保存至:{out_csv_path}")

                else:
                    logger.warning(f"输入路径不存在：{input_folder_path}")
