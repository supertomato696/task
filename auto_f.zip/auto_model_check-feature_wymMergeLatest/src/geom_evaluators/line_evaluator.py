import os

import matplotlib.pyplot as plt
from typing import Optional, Union

from geopandas import GeoDataFrame
from matplotlib.lines import Line2D
from pydantic import BaseModel, Field
from shapely.geometry import LineString, Polygon
from shapely.strtree import STRtree
import numpy as np

from src.geom_evaluators.evaluator_base import EvaluatorBase
from src.tools.common import ensure_single_geometries

from src.logger import logger


class LineMatchResult(BaseModel):
    """
    评测结果类，包含准确率、召回率等评测指标。
    :param title: 标题，默认为空
    :param resample_segment_length: 重采样切分的线段长度。
    :param buffer_distance: 缓冲区距离。
    :param precision: 准确率，计算公式为TP/(TP+FP)。
    :param recall: 召回率。
    :param hit_length: 累计命中长度。
    :param extra_length: 累计冗余长度。
    :param mis_match_length: 累计漏识别长度。
    :param truth_segments: 真值线段列表。
    :param truth_buffers: 真值线段缓冲区列表。
    :param ground_truth_lines: 真值线段集合。
    :param input_lines: 输入线段集合。
    :param matched_truth_indices: 匹配的真值线段索引列表。
    :param total_truth_length: 真值线总长度。
    :param total_input_length: 输入线总长度。
    """
    title: str = None

    resample_segment_length: float
    buffer_distance: float

    precision: float = Field(title="准确率", description="准确率Precision = TP/(TP+FP)")
    recall: float = Field(title="召回率")
    hit_length: float = Field(title="累计命中长度", description="累计命中长度")
    extra_length: float = Field(title="累计冗余长度", description="累计冗余长度")
    mis_match_length: float = Field(title="累计漏识别长度", description="累计漏识别长度")
    truth_segments: Optional[list[LineString]] = []  # 存储真值线段
    truth_buffers: Optional[list[Polygon]] = []  # 存储真值线段的缓冲区
    ground_truth_lines: Optional[list[LineString]] = []  # 存储真值线段列表
    input_lines: Optional[list[LineString]] = []  # 存储输入线段列表
    matched_truth_indices: list = []  # 存储匹配的真值线段索引

    total_truth_length: Optional[float]  # 真值线总长度
    total_input_length: Optional[float]  # 输入线总长度

    @property
    def f1_score(self) -> float:
        """
        计算F1分数，综合考虑精准率和召回率。

        :return: float F1分数
        """
        return 2 * (self.precision * self.recall) / (self.precision + self.recall) if (
                                                                                              self.precision + self.recall) > 0 else 0

    class Config:
        arbitrary_types_allowed = True  # 允许任意类型的字段


class LaneLineEvaluator(EvaluatorBase):
    """
    道路评测类，用于评测道路线的真值数据与输入数据。

    :param truth_lines_file_path: 真值线段文件路径。
    :param input_lines_file_path: 输入线段文件路径。
    :param truth_data_filter_conditions: 真值数据的筛选条件（可选）。
    :param input_data_filter_conditions: 输入数据的筛选条件（可选）。
    :param global_rect: 全局的范围框，优先级高于凸包（可选）。
    :param convex_hull: 用于计算的凸包（可选）。
    :param reference_material_file_path: 参考材料文件路径（可选）。
    :param reference_material_filter_conditions: 参考材料的筛选条件（可选）。
    """

    def __init__(self,
                 truth_lines_file_path: str = None,
                 input_lines_file_path: str = None,
                 # TODO 写到注释里面
                 output_file_path: str = None, # TODO 需要判空
                 truth_gdf: GeoDataFrame = None,
                 input_gdf: GeoDataFrame = None,
                 truth_data_filter_conditions: dict = None,
                 input_data_filter_conditions: dict = None,
                 global_rect: Polygon = None,
                 convex_hull: Union[Polygon, str] = None,
                 reference_material_file_path=None,
                 # TODO 写到注释里面
                 reference_material_gdf: GeoDataFrame = GeoDataFrame(columns=['geometry']),
                 reference_material_filter_conditions: dict = None):

        super().__init__(truth_file_path=truth_lines_file_path,
                         input_file_path=input_lines_file_path,
                         output_file_path=output_file_path,
                         truth_gdf=truth_gdf,
                         input_gdf=input_gdf,
                         global_rect=global_rect,
                         convex_hull=convex_hull,
                         truth_data_filter_conditions=truth_data_filter_conditions,
                         input_data_filter_conditions=input_data_filter_conditions,
                         reference_material_gdf=reference_material_gdf,
                         reference_material_file_path=reference_material_file_path,
                         reference_material_filter_conditions=reference_material_filter_conditions
                         )

        # 获取经过筛选的真值线数据
        self.truth_lines_gdf = self.truth_data_gdf  # 真值线GeoDataFrame

    @staticmethod
    def split_line(line: LineString, segment_length: float) -> list[LineString]:
        """
        将LineString按指定长度切分为多段。

        :param line: 需要切分的LineString。
        :param segment_length: 切分的长度。
        :return: 切分后的LineString列表。
        """
        split_points = np.arange(0, line.length, segment_length)  # 计算切分点
        if split_points[-1] != line.length:
            split_points = np.append(split_points, line.length)  # 确保最后一个点包含在线段结束位置
        points = [line.interpolate(distance) for distance in split_points]  # 插值得到切分点
        return [LineString([points[i], points[i + 1]]) for i in range(len(points) - 1)]  # 返回切分后的LineString列表

    @staticmethod
    def create_buffers(segments: list[LineString], buffer_distance: float) -> list[Polygon]:
        """
        为每个LineString生成缓冲区。

        :param segments: 待生成缓冲区的LineString列表。
        :param buffer_distance: 缓冲区宽度。
        :return: 缓冲区Polygon列表。
        """
        return [seg.buffer(buffer_distance, cap_style=2) for seg in segments]  # cap_style=2: flat caps设置

    def compute_coverage(self, ground_truth_lines: list[LineString], input_lines: list[LineString],
                         resample_segment_length: Union[float, None], buffer_distance: float) -> LineMatchResult:
        """
        计算命中长度、误报长度和漏报长度。

        :param ground_truth_lines: 真值线段。
        :param input_lines: 输入线段。
        :param resample_segment_length: 重采样切分长度。
        :param buffer_distance: 缓冲区距离。
        :return: LineMatchResult 评测结果实例。
        """
        truth_segments = []  # 存储真值线段
        truth_buffers = []  # 存储真值线段的缓冲区
        total_truth_length = 0.0  # 真值线总长度初始化
        total_input_length = 0.0  # 输入线总长度初始化

        logger.info(f"真值={len(ground_truth_lines)}条，输入值={len(input_lines)}条")

        # 切分真值线并生成缓冲区
        for gt_line in ground_truth_lines:
            if gt_line is None:
                continue
            if gt_line.length == 0 or gt_line.length < resample_segment_length:
                continue
            # 不拆分，直接丢到truth_segments
            if resample_segment_length is None:
                truth_segments.append(gt_line)
            total_truth_length += gt_line.length  # 统计真值线总长度
            segments = self.split_line(gt_line, resample_segment_length)  # 切分真值线
            truth_segments.extend(segments)  # 添加切分后的段到列表
            truth_buffers.extend(self.create_buffers(segments, buffer_distance))  # 创建缓冲区并添加

        # 构建空间索引
        truth_tree = STRtree(truth_buffers)  # 使用空间树加速查询
        buffer_to_index = {buffer.wkt: idx for idx, buffer in enumerate(truth_buffers)}  # 缓冲区与其索引的映射

        hit_length = 0.0  # 累计命中长度初始化
        false_positive_length = 0.0  # 冗余长度初始化
        matched_truth_indices = set()  # 命中的真值线段索引

        # 遍历输入线进行匹配
        for index, input_line in enumerate(input_lines):
            # logger.info(str(index))
            # logger.info(input_line.wkt)
            this_line_length = input_line.length  # 当前输入线长度
            possible_buffers_index = truth_tree.query(input_line)  # 查询可能匹配的缓冲区索引
            possible_buffers = [truth_buffers[i] for i in possible_buffers_index]  # 获取对应的缓冲区
            hit_truth_segments = []  # 当前输入线命中的真值段

            for buffer in possible_buffers:
                intersection: LineString = input_line.intersection(buffer)  # 计算输入线与缓冲区的交集

                if not intersection.is_empty:
                    hit_truth_segments.append(intersection)  # 收集命中的真值段
                    buffer_index = buffer_to_index.get(buffer.wkt)
                    if buffer_index is not None:
                        matched_truth_indices.add(buffer_index)  # 标记已匹配的真值段

            if hit_truth_segments:
                # 合并所有命中的段
                merged_hits = hit_truth_segments[0]
                for seg in hit_truth_segments[1:]:
                    merged_hits = merged_hits.union(seg)

                covered = merged_hits.length  # 被覆盖的长度
                hit_length += covered  # 累加命中长度
                uncovered = this_line_length - covered  # 计算未被覆盖的长度
                if uncovered > 0:
                    false_positive_length += uncovered  # 累加冗余长度
            else:
                false_positive_length += this_line_length  # 如果没有匹配，则全部算作冗余

            total_input_length += this_line_length  # 累加输入线长度

        # 计算漏报长度
        covered_truth_length = sum(truth_segments[idx].length for idx in matched_truth_indices)  # 已覆盖的真值长度
        false_negative_length = max(total_truth_length - covered_truth_length, 0.0)  # 漏报长度

        # 计算评测指标
        precision = hit_length / (hit_length + false_positive_length) if (hit_length + false_positive_length) > 0 else 0
        recall = hit_length / (hit_length + false_negative_length) if (hit_length + false_negative_length) > 0 else 0

        # FIXME debug
        logger.info(os.getcwd())
        self.pruned_input_gdf.to_file("./debug_pruned_input_gdf_old.gpkg", driver="GPKG")

        return LineMatchResult(**{  # 返回评测结果实例
            "resample_segment_length": resample_segment_length,
            "buffer_distance": buffer_distance,
            "precision": precision,
            "recall": recall,
            "hit_length": hit_length,
            "extra_length": false_positive_length,
            "mis_match_length": false_negative_length,
            "truth_segments": truth_segments,
            "truth_buffers": truth_buffers,
            "ground_truth_lines": ground_truth_lines,
            "input_lines": input_lines,
            "matched_truth_indices": matched_truth_indices,
            "total_truth_length": total_truth_length,
            "total_input_length": total_input_length
        })

    def save_as_gkpg(self, results: LineMatchResult, gpkg_path):
        truth_buffers = GeoDataFrame(geometry=results.truth_buffers, crs=self.truth_lines_gdf.crs)
        matched_truth_list = [results.truth_segments[i] for i in results.matched_truth_indices]
        matched_truth_gdf = GeoDataFrame(geometry=matched_truth_list, crs=self.truth_lines_gdf.crs)
        self.truth_lines_gdf.to_file(gpkg_path, layer="truth_lines", driver='GPKG')
        truth_buffers.to_file(gpkg_path, layer="truth_buffer", driver='GPKG')
        matched_truth_gdf.to_file(gpkg_path, layer="truth_lines_matched", driver='GPKG')
        self.input_data_gdf.to_file(gpkg_path, layer="input_lines", driver='GPKG')

    @staticmethod
    def results_visualizer_hd(title: str, results: LineMatchResult, reference_material_gdf: GeoDataFrame = None,
                              is_visualize=True, save_as_vector=False,
                              output_svg_path='./result.svg'):
        fig, ax = plt.subplots(figsize=(12, 9))

        if reference_material_gdf is not None:
            if not reference_material_gdf.empty:
                reference_material_gdf.plot(ax=ax, edgecolor='#0f0f0f80', alpha=0.1)

        # 绘制真值缓冲区
        for idx, buffer in enumerate(results.truth_buffers):
            edge_color = 'green' if idx in results.matched_truth_indices else 'red'
            alpha = 0.3
            x, y = buffer.exterior.xy
            ax.plot(x, y, color=edge_color, alpha=alpha, linewidth=0.5)

        # 绘制真值线
        for idx, seg in enumerate(results.truth_segments):
            color = 'green' if idx in results.matched_truth_indices else 'red'
            linestyle = '-' if idx in results.matched_truth_indices else '--'
            linewidth = 2 if idx in results.matched_truth_indices else 1

            # 绘制真值线
            ax.add_line(Line2D(*seg.xy, color=color, linestyle=linestyle, linewidth=linewidth))

        # 绘制输入线，使用灰色线条
        for idx, input_line in enumerate(results.input_lines):
            ax.add_line(Line2D(*input_line.xy, color='gray', linestyle='-', linewidth=1))

        # 添加代表性图例
        handles = [Line2D([0], [0], color='green', lw=2, label='命中的真值线片段'),
                   Line2D([0], [0], color='red', lw=2, linestyle='--', label='未命中的真值线片段'),
                   Line2D([0], [0], color='gray', lw=1, label='输入线')]

        ax.legend(handles=handles, loc='upper right')

        ax.set_title(title)
        ax.set_aspect('equal', adjustable='box')
        plt.grid(True)

        # 统计信息文本
        stats_text = (
            f"缓冲区：真值线两侧各{results.buffer_distance}米\n"
            f"真值累计长度：{results.total_truth_length:.2f}米\n"
            f"输入累计长度：{results.total_input_length:.2f}米\n"
            f"准确率：{results.precision * 100:.2f}%\n"
            f"召回率：{results.recall * 100:.2f}%\n"
            f"F1分数：{results.f1_score:.2f}(无单位)\n"
            f"累计命中长度：{results.hit_length:.2f}米\n"
            f"累计冗余误报长度：{results.extra_length:.2f}米\n"
            f"累计漏识别长度：{results.mis_match_length:.2f}米\n"
        )
        ax.text(1.01, 0.5, stats_text, transform=ax.transAxes, fontsize=10,
                verticalalignment='center', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

        if save_as_vector:
            directory = os.path.dirname(output_svg_path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory)
            plt.savefig(output_svg_path, format='svg', bbox_inches='tight')
            logger.debug(f"保存文件{output_svg_path}")

        if is_visualize:
            plt.show()


    def evaluate(self, task_name: Optional[str], buffer_distance: float,
                 resample_segment_length: float = 1) -> LineMatchResult:
        """
        启动评测任务。

        :param task_name: 任务名称。
        :param buffer_distance: 缓冲区距离。
        :param resample_segment_length: 切分成多长的段落单位是米，默认是1。设置为None时不切分
        :param is_visualize: 是否显示可视化结果。
        :param save_as_vector: 是否保存为矢量图
        :param output_svg_path: 输出SVG文件的路径。
        """
        merged_title = f"{task_name}"
        logger.info(f"开始执行评测任务：{merged_title}")
        result = self.compute_coverage(
            ground_truth_lines=self.truth_lines_gdf.geometry,
            input_lines=ensure_single_geometries(self.pruned_input_gdf).geometry,
            resample_segment_length=resample_segment_length,
            buffer_distance=buffer_distance
        )
        result.title = merged_title
        # 统计信息文本
        stats_text = (
            f"缓冲区：真值线两侧各{result.buffer_distance}米\n"
            f"真值累计长度：{result.total_truth_length:.2f}米\n"
            f"输入累计长度：{result.total_input_length:.2f}米\n"
            f"准确率：{result.precision * 100:.2f}%\n"
            f"召回率：{result.recall * 100:.2f}%\n"
            f"F1分数：{result.f1_score:.2f}(无单位)\n"
            f"累计命中长度：{result.hit_length:.2f}米\n"
            f"累计冗余长度：{result.extra_length:.2f}米\n"
            f"累计漏识别长度：{result.mis_match_length:.2f}米\n"
        )
        # 将统计信息格式化为文本
        logger.info(f"\n评测任务:{merged_title} 结论:\n{stats_text}")  # 日志记录评测结果

        return result

    def visualize(self, result: LineMatchResult, is_visualize=True, save_as_vector=False, output_svg_path=None,
                  gpkg_path=None):
        if is_visualize or save_as_vector:
            logger.info("取得结果开始可视化")
            # 可视化评测结果
            self.results_visualizer_hd(title=result.title, results=result, is_visualize=is_visualize,
                                       output_svg_path=output_svg_path,
                                       save_as_vector=save_as_vector,
                                       reference_material_gdf=self.reference_material_gdf)
            self.save_as_gkpg(results=result, gpkg_path=gpkg_path)
            print(f"gpkg files saved: {gpkg_path}")


class RoadBoundaryEvaluator(LaneLineEvaluator):
    """
    道路边界评测类，继承自LaneLineEvaluator。
    """

    def __init__(self,
                 truth_boundary_file_path: str,
                 input_boundary_file_path: str,
                 truth_gdf: GeoDataFrame = None,
                 input_gdf: GeoDataFrame = None,
                 truth_data_filter_conditions: dict = None,
                 input_data_filter_conditions: dict = None,
                 global_rect: Polygon = None,
                 convex_hull: Union[Polygon, str] = None,
                 reference_material_file_path=None,
                 reference_material_gdf: GeoDataFrame = GeoDataFrame(columns=['geometry']),
                 reference_material_filter_conditions: dict = None):
        """
        初始化道路边界评测器。

        :param truth_boundary_file_path: 真值边界线段文件路径。
        :param input_boundary_file_path: 输入边界线段文件路径。
        :param truth_data_filter_conditions: 真值边界的筛选条件（可选）。
        :param input_data_filter_conditions: 输入边界的筛选条件（可选）。
        :param global_rect: 全局的范围框，优先级高于凸包（可选）。
        :param convex_hull: 用于计算的凸包（可选）。
        :param reference_material_file_path: 参考材料文件路径（可选）。
        :param reference_material_filter_conditions: 参考材料的筛选条件（可选）。
        """
        super().__init__(truth_lines_file_path=truth_boundary_file_path,
                         input_lines_file_path=input_boundary_file_path,
                         truth_gdf=truth_gdf,
                         input_gdf=input_gdf,
                         global_rect=global_rect,
                         convex_hull=convex_hull,
                         truth_data_filter_conditions=truth_data_filter_conditions,
                         input_data_filter_conditions=input_data_filter_conditions,
                         reference_material_file_path=reference_material_file_path,
                         reference_material_gdf=reference_material_gdf,
                         reference_material_filter_conditions=reference_material_filter_conditions
                         )
    # def evaluate(self, task_name: Optional[str], buffer_distance: float,
    #                         resample_segment_length: Union[float, None] = 1) -> LineMatchResult:
    # def start_evaluate_task(self, task_name: str, buffer_distance: float, is_visualize=True,
    #                         save_as_vector=False, output_svg_path=None):
    #     """
    #     启动边界评测任务。
    #
    #     :param task_name: 任务名称。
    #     :param buffer_distance: 缓冲区距离。
    #     :param is_visualize: 是否显示可视化结果。
    #     :param save_as_vector: 是否保存为SVG文件
    #     :param output_svg_path: 输出SVG文件的路径。
    #     """
    #     merged_title = f"{task_name}（缓冲区{buffer_distance}米）"
    #     logger.info(f"开始执行评测任务：{merged_title}")
    #
    #     results = self.compute_coverage(
    #         ground_truth_lines=self.truth_lines_gdf.geometry,
    #         input_lines=ensure_single_geometries(self.pruned_input_gdf).geometry,
    #         resample_segment_length=1,
    #         buffer_distance=buffer_distance
    #     )
    #     # 可视化评测结果
    #     self.results_visualizer_hd(title=merged_title, results=results, is_visualize=is_visualize,
    #                                save_as_vector=save_as_vector,
    #                                output_svg_path=output_svg_path,
    #                                reference_material_gdf=self.reference_material_gdf)

class CenterLineEvaluator(LaneLineEvaluator):
    """
    车道中心线评测类，继承自LaneLineEvaluator。
    """

    def  __init__(self,
                 truth_centerline_file_path: str,
                 input_centerline_file_path: str,
                 truth_gdf: GeoDataFrame = None,
                 input_gdf: GeoDataFrame = None,
                 truth_data_filter_conditions: dict = None,
                 input_data_filter_conditions: dict = None,
                 global_rect: Polygon = None,
                 convex_hull: Union[Polygon, str] = None,
                 reference_material_file_path=None,
                 reference_material_gdf: GeoDataFrame = GeoDataFrame(columns=['geometry']),
                 reference_material_filter_conditions: dict = None):
        """
        初始化车道中心线评测器。

        :param truth_centerline_file_path: 真值车道中心线段文件路径。
        :param input_centerline_file_path: 输入车道中心线段文件路径。
        :param truth_data_filter_conditions: 真值车道中心线的筛选条件（可选）。
        :param input_data_filter_conditions: 输入车道中心线的筛选条件（可选）。
        :param global_rect: 全局的范围框，优先级高于凸包（可选）。
        :param convex_hull: 用于计算的凸包（可选）。
        :param reference_material_file_path: 参考材料文件路径（可选）。
        :param reference_material_filter_conditions: 参考材料的筛选条件（可选）。
        """
        super().__init__(truth_lines_file_path=truth_centerline_file_path,
                         input_lines_file_path=input_centerline_file_path,
                         truth_gdf=truth_gdf,
                         input_gdf=input_gdf,
                         global_rect=global_rect,
                         convex_hull=convex_hull,
                         truth_data_filter_conditions=truth_data_filter_conditions,
                         input_data_filter_conditions=input_data_filter_conditions,
                         reference_material_file_path=reference_material_file_path,
                         reference_material_gdf=reference_material_gdf,
                         reference_material_filter_conditions=reference_material_filter_conditions
                         )