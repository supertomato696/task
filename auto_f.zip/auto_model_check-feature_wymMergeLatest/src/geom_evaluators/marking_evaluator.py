import os
from typing import Union, List, Dict, Set, Tuple, Optional

import matplotlib.pyplot as plt
from geopandas import GeoDataFrame
from pydantic import BaseModel, Field

from src.logger import logger
from shapely import Polygon
from shapely.affinity import scale

from src.geom_evaluators.evaluator_base import EvaluatorBase


class MarkingEvaluateResult(BaseModel):
    title: str = None
    buffer_distance: float = 0
    accuracy: float = Field(title="准确率", description="准确率Precision = TP/(TP+FP)")
    precision: float = Field(title="精准率")
    recall: float = Field(title="召回率")
    match_result: Dict[Polygon, List[Polygon]] = {}
    unmatched_input_list: List[Polygon] = []
    truth_matched_cnt: int = 0
    truth_unmatched_cnt: int = 0
    input_matched_cnt: int = 0
    input_unmatched_cnt: int = 0

    @property
    def f1_score(self) -> float:
        """
        计算F1分数，综合考虑精准率和召回率。

        :return: float F1分数
        """
        return 2 * (self.precision * self.recall) / (self.precision + self.recall) if (self.precision + self.recall) > 0 else 0

    @property
    def format_text(self) -> str:
        stats_text = (
            f"准确率: {self.accuracy * 100:.2f}%\n"
            f"召回率: {self.recall * 100:.2f}%\n"
            f"F1分数: {self.f1_score: .4f}\n"
            f"已匹配真值数量: {self.truth_matched_cnt}\n"
            f"未匹配真值数量: {self.truth_unmatched_cnt}\n"
            f"已匹配输入值数量: {self.input_matched_cnt}\n"
            f"未匹配输入值数量: {self.input_unmatched_cnt}\n"
        )
        return stats_text

    class Config:
        arbitrary_types_allowed = True  # 允许任意类型的字段


class LaneMarkingEvaluator(EvaluatorBase):
    def __init__(self,
                 truth_marking_file_path=None,
                 input_marking_file_path=None,
                 truth_gdf: GeoDataFrame = None,
                 input_gdf: GeoDataFrame = None,
                 truth_data_filter_conditions: dict = None,
                 input_data_filter_conditions: dict = None,
                 global_rect: Polygon = None,
                 convex_hull: Union[Polygon, str] = None,
                 reference_material_file_path=None,
                 reference_material_gdf: GeoDataFrame = GeoDataFrame(columns=['geometry']),
                 reference_material_filter_conditions: dict = None):
        """
        道路地面标识评测类，用于评测输入的地面箭头与真值数据之间的匹配关系。

        :param truth_marking_file_path: 真值地面标识文件路径。
        :param input_marking_file_path: 输入地面标识文件路径。
        :param truth_data_filter_conditions: 真值数据的过滤条件（可选）。
        :param input_data_filter_conditions: 输入数据的过滤条件（可选）。
        :param global_rect: 全局的范围框，优先级高于凸包（可选）。
        :param convex_hull: 用于计算的凸包（可选）。
        :param reference_material_file_path: 参考材料文件路径（可选）。
        :param reference_material_filter_conditions: 参考材料的过滤条件（可选）。
        """

        # 初始化父类
        super().__init__(truth_file_path=truth_marking_file_path,
                         input_file_path=input_marking_file_path,
                         truth_gdf=truth_gdf,
                         input_gdf=input_gdf,
                         truth_data_filter_conditions=truth_data_filter_conditions,
                         input_data_filter_conditions=input_data_filter_conditions,
                         global_rect=global_rect,
                         convex_hull=convex_hull,
                         reference_material_file_path=reference_material_file_path,
                         reference_material_gdf=reference_material_gdf,
                         reference_material_filter_conditions=reference_material_filter_conditions)

        # 获取真值地面标识和输入地面标识的GeoDataFrame
        self.truth_marking_gdf = self.truth_data_gdf
        self.input_marking_gdf = self.pruned_input_gdf

    def match_object(self, buffer_distance=1.5) -> Tuple[Dict[Polygon, List[Polygon]], List[Polygon]]:
        """
        使用缓冲区相交检查，匹配输入的地面标识与真值地面标识。

        此函数遍历每个真值地面标识，计算其质心和基于给定缓冲区距离的缓冲区区域，并检查与输入地面标识的相交情况。

        :param buffer_distance: 缓冲区半径，用于扩展真值地面标识以进行匹配。
        :return: 返回一个元组，包含匹配结果和未匹配的输入地面标识列表。
        """
        match_result: Dict[Polygon: List[Polygon]] = {}  # 存储匹配结果
        used_input_markings: Set[Polygon] = set()  # 存储已使用的输入地面标识以防重复匹配

        # 计算每个真值地面标识几何体的质心和缓冲区
        self.truth_marking_gdf['centroid'] = self.truth_marking_gdf.geometry.centroid
        self.truth_marking_gdf['buffer_area'] = self.truth_marking_gdf.centroid.buffer(buffer_distance)

        # 对每个真值地面标识的缓冲区进行遍历
        for truth_marking_buffer in self.truth_marking_gdf['buffer_area']:
            match_markings = []  # 存储当前缓冲区匹配到的输入地面标识
            for input_marking in self.input_marking_gdf['geometry']:
                if truth_marking_buffer.intersects(input_marking):  # 检查是否相交
                    match_markings.append(input_marking)  # 添加匹配到的输入地面标识
                    used_input_markings.add(input_marking)  # 标记为已使用
            match_result[truth_marking_buffer] = match_markings  # 记录当前缓冲区及其匹配的输入地面标识

        # 确定未匹配的输入地面标识
        unmatch_input_list: List[Polygon] = [marking for marking in self.input_marking_gdf['geometry'] if
                                             marking not in used_input_markings]

        return match_result, unmatch_input_list  # 返回匹配结果和未匹配的输入地面标识

    def calculate_metrics(self, matches: Dict[Polygon, List[Polygon]], unmatches: List[Polygon]) -> Tuple[
        float, float, float]:
        """
        计算评测指标：准确率、精确率和召回率。

        :param matches: 匹配结果字典。
        :param unmatches: 未匹配的输入地面标识列表。
        :return: 准确率、精确率和召回率的元组。
        """
        # TP: 每个输入地面标识都有对应的真值地面标识
        true_positives = sum(1 for truthing, match_markings in matches.items() if len(match_markings) > 0)
        # FN: 每个真值地面标识没有匹配到输入地面标识
        false_negatives = sum(1 for truth_marking, match_markings in matches.items() if len(match_markings) == 0)
        # FP: 每条输入地面标识应该找到至少一个真值地面标识，但实际上没有匹配
        false_positives = len(unmatches)

        # 计算精准率和召回率
        recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
        precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
        accuracy = true_positives / len(self.input_marking_gdf) if len(self.input_marking_gdf) > 0 else 0

        return accuracy, precision, recall  # 返回指标

    def generate_summary(self, buffer_distance, matches, unmatch):
        """
        生成评测摘要（此处留空，待实现）。

        :param buffer_distance: 缓冲区距离。
        :param matches: 匹配结果。
        :param unmatch: 未匹配的结果。
        """
        pass  # 该方法尚未实现

    def evaluate(self, buffer_distance, task_name: Optional[str]) -> MarkingEvaluateResult:
        match_result, unmatch_input_list = self.match_object(buffer_distance=buffer_distance)  # 进行对象匹配

        accuracy, precision, recall = self.calculate_metrics(match_result, unmatch_input_list)  # 计算指标

        truth_matched_cnt = 0  # 已匹配真值计数
        truth_unmatched_cnt = 0  # 未匹配真值计数
        for truth_element_buffer, matched_inputs in match_result.items():
            if len(matched_inputs):
                truth_matched_cnt += 1  # 计数已匹配的真值
            else:
                truth_unmatched_cnt += 1  # 计数未匹配的真值

        res = MarkingEvaluateResult(
            title=task_name,
            buffer_distance=buffer_distance,
            accuracy=accuracy,
            precision=precision,
            recall=recall,
            match_result=match_result,
            unmatched_input_list=unmatch_input_list,
            truth_matched_cnt=truth_matched_cnt,
            truth_unmatched_cnt=truth_unmatched_cnt,
            input_matched_cnt=len(self.input_marking_gdf) - len(unmatch_input_list),
            input_unmatched_cnt=len(unmatch_input_list)
        )

        logger.info(f"\n评测任务:{res.title} 结论:\n{res.format_text}")  # 记录评测结论
        return res

    def visualize(self,
                  result: MarkingEvaluateResult,
                  reference_material_gdf=GeoDataFrame(columns=['geometry']),
                  is_visualize=False,
                  save_vector_file=False,
                  output_svg_path=None):
        fig, ax = plt.subplots(figsize=(12, 9))  # 创建绘图窗口

        if reference_material_gdf.empty:
            reference_material_gdf = self.reference_material_gdf

        if not reference_material_gdf.empty:
            reference_material_gdf.plot(ax=ax, edgecolor='#0f0f0f80', alpha=0.06)  # 绘制参考材料

        # 绘制未匹配的输入地面标识
        for input_marking in result.unmatched_input_list:
            x, y = input_marking.exterior.xy
            ax.fill(x, y,
                    color='red',
                    alpha=0.8,
                    label='未匹配的地面箭头输入值')

        # 绘制真值地面标识, 就是输入真值buffer几何的质心
        for truth_marking in self.truth_marking_gdf['geometry']:
            scaled_marking = scale(truth_marking, xfact=20, yfact=20, origin='centroid')  # 放大绘制地面标识
            x, y = scaled_marking.exterior.xy
            ax.fill(x, y,
                    color='orange',
                    alpha=0.5,
                    label='地面箭头真值')

        # 绘制已匹配的真值地面地面标识与连接线
        for truth_buffer, matched_inputs in result.match_result.items():
            t_x, t_y = truth_buffer.exterior.xy
            if len(matched_inputs):
                ax.fill(t_x, t_y,
                        color='orange',
                        edgecolor='orange',
                        alpha=0.3,
                        linestyle='--',
                        label='已匹配的地面箭头真值')
                # 绘制已匹配的输入地面标识
                for matched in matched_inputs:
                    m_x, m_y = matched.exterior.xy
                    ax.fill(m_x, m_y,
                            color='green',
                            alpha=0.5,
                            label='已匹配的地面箭头输入值')
                    # 绘制连接质心的虚线
                    truth_centroid = truth_buffer.centroid
                    matched_centroid = matched.centroid
                    ax.plot([truth_centroid.x, matched_centroid.x],
                            [truth_centroid.y, matched_centroid.y], 'k--', linewidth=1)  # 连接两者质心的线段
            else:
                ax.fill(t_x, t_y,
                        color='red',
                        edgecolor='red',
                        alpha=0.3,
                        linestyle='--',
                        label='未匹配的地面箭头真值')

        # 添加图例
        handles, labels = ax.get_legend_handles_labels()
        by_label = {}
        for h, l in zip(handles, labels):
            if l not in by_label:
                by_label[l] = h
        ax.legend(by_label.values(), by_label.keys())  # 去重并绘制图例

        title = f"{result.title}"
        ax.set_title(title)  # 设置标题
        ax.set_xlabel('X')
        ax.set_ylabel('Y')

        # 将统计信息格式化为文本
        stats_text = result.format_text
        # logger.info(f"\n评测任务:{title} 结论:\n{stats_text}")  # 日志记录评测结果

        props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)  # 文本框样式
        ax.text(1.01, 0.5,
                stats_text,
                transform=ax.transAxes,
                fontsize=10,
                verticalalignment='center',
                bbox=props,
                fontfamily='Microsoft YaHei')  # 在图上添加统计信息文本

        plt.grid(True)  # 显示网格
        if output_svg_path and save_vector_file:
            # 获取文件的目录路径
            directory = os.path.dirname(output_svg_path)

            # 检查目录是否存在，如果不存在则创建
            if directory and not os.path.exists(directory):
                os.makedirs(directory)

            logger.debug(f"保存到{output_svg_path}")  # 记录保存路径
            # 保存图形
            plt.savefig(output_svg_path, format='svg', bbox_inches='tight')  # 矢量格式

        if is_visualize:
            plt.show()  # 显示可视化图形
