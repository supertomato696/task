from matplotlib import rcParams

# 设置中文字体显示
rcParams['font.family'] = 'SimHei'  # 使用黑体
rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
