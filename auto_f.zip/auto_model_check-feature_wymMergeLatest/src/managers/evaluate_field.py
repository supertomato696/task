# -*- coding: utf-8 -*-
# @Time    : 2025/2/28 22:11
# @Author  : StephenLeung
# @Email   : liang.yuhao1@byd.com
# @File    : evaluate_field.py


class EvaluateFieldManager:
    def __init__(self):
        pass


    def get_evaluate_field_from_db(self):
        ...

    def load_local_evaluate_field(self):
        ...
