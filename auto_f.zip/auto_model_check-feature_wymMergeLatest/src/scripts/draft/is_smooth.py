# -*- coding: utf-8 -*-
# @Time    : 2025/2/28 22:23
# @Author  : StephenLeung
# @Email   : liang.yuhao1@byd.com
# @File    : is_smooth_draft.py
from math import floor

import matplotlib.pyplot as plt
import geopandas as gpd
import numpy as np
from shapely.geometry import Point, LineString, MultiLineString
from tqdm import tqdm
import warnings
import sys

from src.logger import logger


# 高速公路：angle_threshold=15, curvature_threshold=0.05
# 城市道路：angle_threshold=30, curvature_threshold=0.1
# 停车场：angle_threshold=45, curvature_threshold=0.2


def calculate_utm_zone(gdf):
    """更健壮的UTM带计算"""
    try:
        centroid = gdf.geometry.unary_union.centroid
        lon = centroid.x
        lat = centroid.y

        # UTM带计算逻辑
        utm_zone = int(floor((lon + 180) / 6) + 1)
        northern = 'N' if lat >= 0 else 'S'
        epsg_code = 32600 + utm_zone if northern == 'N' else 32700 + utm_zone

        # 验证EPSG代码有效性
        test_crs = f"EPSG:{epsg_code}"
        gpd.GeoDataFrame(geometry=[Point(0, 0)]).set_crs(test_crs, inplace=True)
        return test_crs
    except Exception as e:
        print(f"UTM带计算失败: {str(e)}")
        return "EPSG:3857"  # 退回Web Mercator


def handle_crs(gdf):
    """坐标系处理核心逻辑"""
    if gdf.crs is None:
        print("警告：数据未定义坐标系，假设为WGS84")
        gdf = gdf.set_crs("EPSG:4326")

    if not gdf.crs.is_projected:
        print("正在执行坐标系转换...")
        original_crs = gdf.crs

        # 第一次尝试UTM转换
        target_crs = calculate_utm_zone(gdf)
        try:
            gdf_proj = gdf.to_crs(target_crs)
            print(f"成功转换为 {target_crs}")
            return gdf_proj
        except Exception as e:
            print(f"UTM转换失败: {str(e)}")

            # 退回方案：使用等距圆锥投影
            print("尝试使用自定义投影...")
            centroid = gdf.geometry.unary_union.centroid
            custom_crs = f"+proj=eqc +lat_ts={centroid.y} +lon_0={centroid.x}"
            try:
                return gdf.to_crs(custom_crs)
            except:
                print("自定义投影失败，使用Web Mercator")
                return gdf.to_crs("EPSG:3857")

    return gdf


def visualize_results(gdf, output_image="smoothness_check.png"):
    """可视化平滑检测结果"""
    plt.figure(figsize=(12, 8))
    ax = plt.subplot(111)

    try:
        # 绘制底图
        # world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
        minx, miny, maxx, maxy = gdf.total_bounds
        buffer = 0.1 * (maxx - minx)
        # world.plot(ax=ax, color='lightgrey', edgecolor='white')

        # 绘制检测结果
        smooth_lines = gdf[gdf['is_smooth']]
        unsmooth_lines = gdf[~gdf['is_smooth']]

        smooth_lines.plot(ax=ax, color='limegreen', linewidth=2, label='Smooth', zorder=2)
        unsmooth_lines.plot(ax=ax, color='crimson', linewidth=2, label='Unsmooth', zorder=3)

        # 标注问题点
        problem_points = []
        for geom in unsmooth_lines.geometry:
            problem_points.extend(find_problem_points(geom))

        if problem_points:
            points_gdf = gpd.GeoDataFrame(geometry=problem_points, crs=gdf.crs)
            points_gdf.plot(ax=ax, color='gold', markersize=50, marker='*',
                            edgecolor='k', label='Problem Points', zorder=4, alpha=0.3)

        ax.set_xlim(minx - buffer, maxx + buffer)
        ax.set_ylim(miny - buffer, maxy + buffer)
        ax.legend(loc='upper right')
        plt.title(f"Lane Smoothness Check\nTotal: {len(gdf)} lines | Unsmooth: {len(unsmooth_lines)} lines")
        plt.savefig(output_image, dpi=300, bbox_inches='tight')
        print(f"可视化结果已保存至: {output_image}")
    except Exception as e:
        logger.exception(f"可视化失败: {str(e)}")
    finally:
        plt.show()
        plt.close()


def find_problem_points(geom, angle_threshold=30, curvature_threshold=0.1):
    """递归定位问题点，支持MultiLineString"""
    points = []

    if geom.is_empty:
        return points

    if geom.geom_type == 'LineString':
        coords = list(geom.coords)
        for i in range(1, len(coords) - 1):
            prev = np.array(coords[i - 1])
            curr = np.array(coords[i])
            next_p = np.array(coords[i + 1])

            # 向量计算
            vec_prev = curr - prev
            vec_next = next_p - curr

            # 跳过零向量
            if np.linalg.norm(vec_prev) == 0 or np.linalg.norm(vec_next) == 0:
                continue

            # 角度计算
            cos_theta = np.dot(vec_prev, vec_next) / (np.linalg.norm(vec_prev) * np.linalg.norm(vec_next))
            cos_theta = np.clip(cos_theta, -1.0, 1.0)
            angle = np.degrees(np.arccos(cos_theta))

            # 曲率计算
            a, b, c = np.linalg.norm(prev - curr), np.linalg.norm(curr - next_p), np.linalg.norm(next_p - prev)
            if a * b * c == 0:
                continue
            s = (a + b + c) / 2
            area = np.sqrt(max(0, s * (s - a) * (s - b) * (s - c)))
            curvature = (4 * area) / (a * b * c)

            if angle > angle_threshold or curvature > curvature_threshold:
                points.append(Point(coords[i]))

    elif geom.geom_type == 'MultiLineString':
        for line in geom.geoms:
            points.extend(find_problem_points(line))

    return points


def is_smooth_geom(geom, angle_threshold=30, curvature_threshold=0.1):
    """支持MultiLineString的平滑检测"""
    try:
        if geom.is_empty:
            return False

        if geom.geom_type == 'LineString':
            return _check_single_line(geom, angle_threshold, curvature_threshold)
        elif geom.geom_type == 'MultiLineString':
            return all(_check_single_line(line, angle_threshold, curvature_threshold) for line in geom.geoms)
        else:
            warnings.warn(f"不支持的几何类型: {geom.geom_type}")
            return False
    except Exception as e:
        print(f"几何体处理错误: {str(e)}")
        return False


def _check_single_line(line, angle_threshold, curvature_threshold):
    """单个LineString的检测逻辑"""
    coords = list(line.coords)
    if len(coords) < 3:
        return True

    for i in range(1, len(coords) - 1):
        prev = np.array(coords[i - 1])
        curr = np.array(coords[i])
        next_p = np.array(coords[i + 1])

        vec_prev = curr - prev
        vec_next = next_p - curr

        if np.linalg.norm(vec_prev) == 0 or np.linalg.norm(vec_next) == 0:
            continue

        # 角度检测
        cos_theta = np.dot(vec_prev, vec_next) / (np.linalg.norm(vec_prev) * np.linalg.norm(vec_next))
        cos_theta = np.clip(cos_theta, -1.0, 1.0)
        angle = np.degrees(np.arccos(cos_theta))
        if angle > angle_threshold:
            return False

        # 曲率检测
        a, b, c = np.linalg.norm(prev - curr), np.linalg.norm(curr - next_p), np.linalg.norm(next_p - prev)
        if a * b * c == 0:
            continue
        s = (a + b + c) / 2
        area = np.sqrt(max(0, s * (s - a) * (s - b) * (s - c)))
        curvature = (4 * area) / (a * b * c)
        if curvature > curvature_threshold:
            return False

    return True


def main(input_shp, angle_threshold=30, curvature_threshold=0.1):
    try:
        # 读取数据
        print(f"正在读取文件: {input_shp}")
        gdf = gpd.read_file(input_shp)
        gdf = handle_crs(gdf)
        original_count = len(gdf)

        # 数据清洗
        print("正在进行数据清洗...")
        gdf = gdf[gdf.geometry.notnull()].copy()
        valid_types = ['LineString', 'MultiLineString']
        gdf = gdf[gdf.geometry.type.isin(valid_types)].copy()

        # 打印清洗报告
        filtered_count = original_count - len(gdf)
        if filtered_count > 0:
            print(f"已过滤 {filtered_count} 条无效记录 (空几何或非法类型)")

        if len(gdf) == 0:
            raise ValueError("没有有效数据可供处理")

        # 进度条处理
        tqdm.pandas(desc="检测线段平滑性")
        gdf['is_smooth'] = gdf.geometry.progress_apply(
            lambda x: is_smooth_geom(x, angle_threshold, curvature_threshold)
        )

        # 统计计算
        smooth_mask = gdf['is_smooth']
        total_length = gdf.geometry.length.sum()
        smooth_length = gdf[smooth_mask].geometry.length.sum()
        unsmooth_length = total_length - smooth_length

        print("\n" + "=" * 40)
        print(f"{'检测结果统计':^40}")
        print("=" * 40)
        print(f"总线段数: {len(gdf)}")
        print(f"总长度: {total_length:.2f} 米")
        print(f"平滑线段长度: {smooth_length:.2f} ({smooth_length / total_length:.1%})")
        print(f"非平滑线段长度: {unsmooth_length:.2f} ({unsmooth_length / total_length:.1%})")

        # 可视化
        visualize_results(gdf)

        return True
    except Exception as e:
        print(f"\n错误: {str(e)}")
        return False


if __name__ == "__main__":
    # 参数配置
    input_path = "../road_boundary_vectorize.shp"  # 输入文件路径

    # 参数检查
    if not input_path.endswith('.shp'):
        print("错误: 仅支持Shapefile格式输入")
        sys.exit(1)

    # 执行检测
    success = main(input_path,
                   angle_threshold=30,
                   curvature_threshold=0.1)

    # 退出码处理
    sys.exit(0 if success else 1)
