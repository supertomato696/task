import os
import pickle

import geopandas
import numpy as np
import pandas as pd
from geopandas import GeoDataFrame
from shapely import LineString
import matplotlib.pyplot as plt
from src.geom_evaluators.lane_width_check import LaneWidthEvaluator, visualize_lane_width_relative_error_results
from src.geom_evaluators.line_evaluator import LaneLineEvaluator
from src.geom_evaluators.marking_evaluator import LaneMarkingEvaluator
from src.geom_evaluators.stopline_evaluator import StopLineEvaluator


def width_test():
    lwe = LaneWidthEvaluator(truth_lines_file_path="./data_for_test/job/truth/【氦】/laneline.shp",
                             truth_data_filter_conditions={"line_type": {
                                 "value": 1,
                                 "operator": "neq"}},
                             input_lines_file_path="./data_for_test/job/input/IRD-0124/【氦】/lane_boundary.shp",
                             truth_intersection_file_path="./data_for_test/job/truth/【氦】/intersection.shp",
                             truth_centerline_file_path="./data_for_test/job/truth/【氦】/lane.shp")

    return lwe


def save_gdf_to_pickle(gdf, filename):
    """
    将 GeoDataFrame 保存为 pickle 文件。
    """
    with open(filename, 'wb') as f:
        pickle.dump(gdf, f)
    print(f"GeoDataFrame has been saved to {filename}")


def load_gdf_from_pickle(filename):
    """
    从 pickle 文件加载 GeoDataFrame。
    """
    with open(filename, 'rb') as f:
        gdf = pickle.load(f)
    print(f"GeoDataFrame has been loaded from {filename}")
    return gdf


def convert_gdf_coordinates(gdf: GeoDataFrame):
    """
    将 GeoDataFrame 中的几何体转换为 EPSG:4326。
    会将 point, left_perp_geom, right_perp_geom 进行转换。
    """
    # 确保 gdf 具有 CRS
    if gdf.crs is None or gdf.crs.to_string() != "EPSG:32650":  # 假设原始 CRS 是 EPSG:32650 (UTM)
        raise ValueError("Input GeoDataFrame must be in EPSG:32650")
    gdf = gdf.to_crs(epsg=4326)

    # 轮流将几何列设置为 geometry，先处理 left_perp_geom
    if 'left_perp_geom' in gdf.columns:
        gdf = gdf.set_geometry('left_perp_geom', crs='EPSG:32650')
        gdf = gdf.to_crs(epsg=4326)  # 转换坐标系
        # 恢复主几何列为 point，保存 left_perp_geom 的结果
        gdf['left_perp_geom'] = gdf.geometry
        gdf = gdf.reset_index(drop=True)

    # 处理 right_perp_geom
    if 'right_perp_geom' in gdf.columns:
        gdf = gdf.set_geometry('right_perp_geom', crs='EPSG:32650')
        gdf = gdf.to_crs(epsg=4326)  # 转换坐标系
        # 恢复主几何列为 point，保存 right_perp_geom 的结果
        gdf['right_perp_geom'] = gdf.geometry
        gdf = gdf.reset_index(drop=True)

    # 最后处理 point 列，设置为主几何列
    if 'point' in gdf.columns:
        gdf = gdf.set_geometry('point', crs='EPSG:32650')  # 设置 point 为主几何列

    return gdf


def plot_distribution(gdf, column_name, bins=400):
    """
    绘制 GeoDataFrame 中指定数字列的分布图。

    Args:
        gdf: GeoDataFrame。
        column_name: 要绘制的数值列的名称。
        bins: 直方图的柱数。
    """
    if column_name not in gdf.columns:
        print(f"Error: Column '{column_name}' not found in GeoDataFrame.")
        return

    try:
        # 尝试将列转换为数值类型，忽略无法转换的值
        values = pd.to_numeric(gdf[column_name], errors='coerce')
        values = values.dropna()  # 删除缺失值

        if values.empty:
            print(f"Error: Column '{column_name}' contains no numeric values after converting.")
            return

        # 使用 Matplotlib 绘制直方图
        plt.figure(figsize=(10, 6))  # 设置图像大小
        plt.hist(values, bins=bins, edgecolor='black')  # 绘制直方图

        plt.title(f"Distribution of {column_name}")  # 设置标题
        plt.xlabel(column_name)  # 设置 x 轴标签
        plt.ylabel("Frequency")  # 设置 y 轴标签
        plt.grid(True)  # 显示网格

        # 添加95%分位数线
        percentile_95 = values.quantile(0.95)
        plt.axvline(percentile_95, color='red', linestyle='dashed', linewidth=2,
                    label=f'95th Percentile: {percentile_95:.2f}')

        plt.legend()  # 显示图例
        plt.show()

    except TypeError:
        non_numeric_values = gdf[~pd.to_numeric(gdf[column_name], errors='coerce').notnull()][column_name].unique()
        print(f"Error: Column '{column_name}' contains non-numeric values: {non_numeric_values}")


# 清理数据并计算区间分布
def calculate_width_diff_distribution(gdf: GeoDataFrame, bins=None):
    # 过滤掉NaN值
    gdf_cleaned = gdf.dropna(subset=["width_diff"])

    # 如果没有给定区间，默认为根据最小值和最大值来划分
    if bins is None:
        min_val = gdf_cleaned["width_diff"].min()  # 获取最小值
        max_val = gdf_cleaned["width_diff"].max()  # 获取最大值
        bins = np.linspace(min_val, max_val, num=6)  # 将数据均匀分成5个区间

    # 使用pd.cut将数据分配到不同的区间
    gdf_cleaned['width_diff_binned'] = pd.cut(gdf_cleaned['width_diff'], bins)

    # 计算每个区间的分布百分比
    distribution = gdf_cleaned['width_diff_binned'].value_counts(normalize=True) * 100

    # 返回区间分布百分比
    return distribution


if __name__ == '__main__':
    import geopandas as gpd

    # import matplotlib.pyplot as plt
    #
    # fig, ax = plt.subplots(figsize=(12, 9))

    lwe = width_test()


    """
    根据人工作业的真值地图，其中包括车道线、车道中心线。对输入的BEV识别结果车道线进行相对精度评估。
    也就是模拟一辆车沿着车道前进，在同一个地方，BEV车道宽度和真值的车道宽度的差值是多少，也就是相对宽度。
    
    现在我已经将真值车道线、车道中心线、输入的Input结果读取为Geodataframe
    
    策略：
    车道沿着每一条车道中心线前进，步长为1米，想想有多个检查点，中心线的开始是一个检查点，结束是一个检查点，中间每隔一米一个检查点。
    从这条车道中心线中的点（以起点为例），以中心线向量方向的为前方，往左右两侧各自做垂线，垂线长度为3米。
    现在会出现这么几种情况：
    1. 如果左侧或者右侧没有匹配到真值车道线，那么跳过，continue。但是要记录这个点，以及它的垂线（后面做可视化检查用）
    2. 如果只有一侧匹配到真值车道线，那么也跳过，continue。但是要记录这个点，以及它的垂线（后面做可视化检查用）
    3. 如果垂线与多条真值车道线相交，那么说明这个地方是有完整车道的。这个点我们称之为P，左侧的垂线是L，右侧的垂线是R。 这个时候尝试寻找输入的BEV识别结果车道线，在真值中心相同位置，左右两侧的垂线是否也有交点。
        a. 如果没有，那么跳过，continue。但是要记录这个点，以及它的垂线（后面做可视化检查用）
        b. 如果有，那么检查这L和R与真值线的所有交点，取左右两侧的交点离P最近的两个，并计算其差值（作为这个点的真值车道宽度）。同时也检查L和R与BEV识别结果，取左右两侧的交点离P最近的两个，并计算其差值（作为这个点的输入值车道宽度）。
            计算两个宽度的差值作为相对精度误差。
    """
    # print(os.getcwd())
    # res = relative_width_statistics(lwe.truth_lines_gdf, lwe.usable_centerline, lwe.pruned_input_gdf)
    # # res = res.to_crs("EPSG:4326")
    # # # 将其他几何列也转换为 GeoSeries 并设置CRS
    # # for col in ["left_perp_geom", "right_perp_geom"]:
    # #     res[col] = gpd.GeoSeries(res[col], crs="EPSG:4326")
    #
    # save_gdf_to_pickle(res,"./test.pickles")
    #
    # visualize_results(lwe.truth_lines_gdf, lwe.usable_centerline, lwe.pruned_input_gdf, res)
    #
    # # analyze_results(res)

    gdf = load_gdf_from_pickle("./test.pickles")

    gdf_ = convert_gdf_coordinates(gdf)
    percentile_95 = gdf_["width_diff"].quantile(0.95)
    print(percentile_95)
    #
    # plot_distribution(gdf_, "width_diff")

    visualize_lane_width_relative_error_results(lwe.truth_lines_gdf.to_crs("EPSG:4326"), lwe.usable_centerline.to_crs("EPSG:4326"), lwe.pruned_input_gdf.to_crs("EPSG:4326"), gdf_)
    print("done")
