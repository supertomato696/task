import os
import geopandas as gpd
import pyproj
from geopandas import GeoDataFrame
from shapely.ops import unary_union
from shapely.geometry import Point, Polygon,LineString, MultiLineString

def convex_hull(lane_lines,road_boundaries,stop_lines,crosswalks,convex_hull_path):
    
    hull_list = []

    if not lane_lines.empty:
        hull_list.append(lane_lines.union_all().convex_hull)

    # if not road_boundaries.empty:
    #     hull_list.append(road_boundaries.union_all().convex_hull)

    # if not stop_lines.empty:
    #     hull_list.append(stop_lines.union_all().convex_hull.buffer(1))  # 多往外找一米

    # if not crosswalks.empty:
    #     hull_list.append(crosswalks.union_all().convex_hull.buffer(1))  # 多往外找一米


    merged_hulls = unary_union(hull_list)

    # gdf = transform_geometry(merged_hulls)
    # 创建 GeoDataFrame
    gdf = GeoDataFrame({'geometry': [merged_hulls]}, crs='EPSG:4326')
    
    # 保存为 GeoJSON 文件
    gdf_transformed = gdf.to_file(convex_hull_path, 'ESRI Shapefile')
    
    gdf = transform_geometry(merged_hulls)
    return gdf

def transform_geometry(geometry):
    """
    转换几何对象到新的坐标系。
    
    :param geometry: 几何对象，可以是 Point, LineString 或 Polygon
    :param src_crs: 源坐标系，例如 "EPSG:4326"
    :param dst_crs: 目标坐标系，例如 "EPSG:3785"
    :return: 转换后的几何对象
    """
    src_crs = "EPSG:4326"
    dst_crs = "EPSG:3785"
    # 创建坐标转换器
    transformer = pyproj.Transformer.from_crs(src_crs, dst_crs, always_xy=True)
    
    # 转换几何对象
    if isinstance(geometry, Point):
        # 对于点，直接转换
        x, y = transformer.transform(geometry.x, geometry.y)
        return Point(x, y)
    elif isinstance(geometry, LineString):
        # 对于线，转换所有点
        new_coords = [transformer.transform(x, y) for x, y in geometry.coords]
        return LineString(new_coords)
    elif isinstance(geometry, MultiLineString):
        new_multilines = []
        for line in geometry.geoms:
            new_coords = [transformer.transform(x, y) for x, y in line.coords]
            new_multilines.append(LineString(new_coords))
        return MultiLineString(new_multilines)
    elif isinstance(geometry, Polygon):
        # 对于多边形，转换外部和内部环
        new_exterior = [transformer.transform(x, y) for x, y in geometry.exterior.coords]
        new_interiors = []
        for interior in geometry.interiors:
            new_interior = [transformer.transform(x, y) for x, y in interior.coords]
            new_interiors.append(LineString(new_interior))
        return Polygon(new_exterior, new_interiors)
    else:
        raise ValueError("Unsupported geometry type")
    
def intersect_length(polygon,line):
    intersection = polygon.intersection(line)
    total_length = 0
    # 如果相交部分是LineString或MultiLineString，计算长度
    if isinstance(intersection, LineString):
        total_length += intersection.length
    elif isinstance(intersection, MultiLineString):
        for line_part in intersection.geoms:
            total_length += line_part.length
    return total_length / 1000

if __name__ == "__main__":
    input_file_path = r'E:\geoeva_v2.0\data\input\v3.05.02_mmt_bev'
    sd_link_path = r'E:\geoeva_v2.0\data\output0509_3\深圳市算法框_0425_4\LinkShp_all.shp'
    output_data_path = r'E:\geoeva_v2.0\data\input\convex_hull'
    version = input_file_path.split('\\')[-1]
    distance_threshold = 5
    folders = os.listdir(input_file_path)

    sd_link_gdf = gpd.read_file(sd_link_path)

    for algo_box in folders:
        if not algo_box.endswith('.zip'):
            sum_length = 0
            input_data_path = os.path.join(input_file_path,algo_box)

            lane_lines = gpd.read_file(os.path.join(input_file_path,algo_box,"lane_boundary.shp"))
            road_boundaries = gpd.read_file(os.path.join(input_file_path,algo_box,"road_boundary.shp"))
            stop_lines = gpd.read_file(os.path.join(input_file_path,algo_box,"stop_line.shp"))
            crosswalks = gpd.read_file(os.path.join(input_file_path,algo_box,"cross_walk.shp"))
            convex_hull_path = os.path.join(output_data_path,algo_box + '_convex_hull_union.shp')
            convex_hull_polygon = convex_hull(lane_lines,road_boundaries,stop_lines,crosswalks,convex_hull_path)
            for i, geom in enumerate(sd_link_gdf.geometry):
                geom_prj = transform_geometry(geom)
                sum_length += intersect_length(convex_hull_polygon,geom_prj)
            print(algo_box,sum_length)



