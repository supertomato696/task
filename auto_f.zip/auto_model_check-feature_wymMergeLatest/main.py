# -*- coding: utf-8 -*-
# @Time    : 2025/3/3 14:20
# @Author  : StephenLeung
# @Email   : liang.yuhao1@byd.com
# @File    : main.py
import argparse

from src.algorithm_range.manager import AlgorithmBoxManager
from src.intersection_evaluator.manager import EvaluationManager

VERSION = "v2.0.2"

"""
71951   氦
71952   锂
72377   铍
72001   硼
71699   氖
"""


def main():
    em = EvaluationManager("./data/input/config.yaml")
    em.start_evaluation()


def start_cli():
    parser = argparse.ArgumentParser(
        description="Process a YAML file for evaluation with algorithm box ID and version.")

    # 添加命令行选项
    parser.add_argument("-f", "--file", required=True, help="Path to the YAML configuration file.")
    # parser.add_argument("-b", "--box_id", required=True, help="Algorithm box ID.")
    # parser.add_argument("-v", "--version", required=True, help="Algorithm version.")

    # 解析参数
    args = parser.parse_args()

    em = EvaluationManager(args.file)  # 修改这里
    em.start_evaluation()


if __name__ == '__main__':
    main()
