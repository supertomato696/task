#include "ConfigLoader.h"
#include <fstream>
#include <iostream>

// 如果使用 nlohmann/json，需要在 CMakeLists.txt 中引入该库，并在此包含头文件
#include "nlohmann/json.hpp"

using json = nlohmann::json;

ConfigLoader& ConfigLoader::getInstance()
{
    static ConfigLoader instance;
    return instance;
}

bool ConfigLoader::loadConfig(const std::string& filePath)
{
    // 1. 打开文件
    std::ifstream ifs(filePath);
    if (!ifs.is_open()) {
        std::cerr << "[ConfigLoader] Cannot open config file: " << filePath << std::endl;
        return false;
    }

    // 2. 解析 JSON
    json j;
    try {
        ifs >> j;
    } catch (const std::exception& e) {
        std::cerr << "[ConfigLoader] JSON parse error: " << e.what() << std::endl;
        return false;
    }

    // 3. 检查字段 "models" 是否存在
    if (!j.contains("models") || !j["models"].is_array()) {
        std::cerr << "[ConfigLoader] Invalid config: 'models' array not found." << std::endl;
        return false;
    }

    // 4. 清空之前的配置（若重复调用）
    modelConfigs_.clear();

    // 5. 遍历 models 数组
    auto modelArray = j["models"];
    for (auto& item : modelArray) {
        ModelConfig cfg;
        try {
            // 基本字段
            cfg.modelId  = item.at("modelId").get<uint32_t>();
            cfg.name     = item.value("name", "");
            cfg.version  = item.value("version", "");
            cfg.soPath   = item.value("soPath", "");
            cfg.soType   = item.at("soType").get<uint32_t >();

        } catch (const std::exception& e) {
            std::cerr << "[ConfigLoader] parse model item error: " << e.what() << std::endl;
            continue;
        }

        modelConfigs_.push_back(std::move(cfg));
    }

    std::cout << "[ConfigLoader] Successfully loaded "
              << modelConfigs_.size() << " model configs from "
              << filePath << std::endl;
    return true;
}