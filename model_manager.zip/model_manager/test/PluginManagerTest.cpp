
// #include "plugin/PluginManager.h"
#include <iostream>
#include <thread>
#include <chrono>
#include "PluginManager.hpp"
#include  "ipconfig.h"
using namespace bos::aios;
int main()
{
    // 1) 加载配置文件，批量加载插件
    std::string configPath = ModelConfigPath;
    PluginManager::getInstance().loadPlugins(configPath);

    // 2) 为了演示，对 4 种 plugin 分别初始化(也可以先判断是否加载成功)
    //    这里的 modelId 跟 plugin_config.json 中保持一致

    // ================== 大模型 (modelId=1001) ==================
    {
        UINT32 modelId = 1001;
        auto st = PluginManager::getInstance().initPlugin(modelId);
        if (st != Status::SUCCESS) {
            std::cerr << "[Test] initPlugin(MLLM, 1001) failed!\n";
        } else {
            std::cout << "[Test] initPlugin(MLLM, 1001) success.\n";
        }

        // 同步生成
        GenerateOutput genOut = PluginManager::getInstance().mllmGenerate(
                modelId,
                R"({"prompt":"Hello, how are you?"})"
        );
        if (genOut.status == Status::SUCCESS) {
            std::cout << "[Test] MLLM generate output: " << genOut.output << std::endl;

        } else {
            std::cerr << "[Test] MLLM generate failed.\n";
        }

        // 异步生成
        Status plugin_out;
        auto asyncSt = PluginManager::getInstance().mllmGenerateAsync(
                modelId,
                R"({"prompt":"Tell me a story in async mode"})",
                [](GenerationStatus gs, const std::string& token){
                    // 这里在回调中打印信息
                    std::cout << "[AsyncCallback] status=" << static_cast<int>(gs)
                              << ", token=" << token
                              << std::endl;
                },
                plugin_out
        );
        if (asyncSt == AimhStatus::SUCCESS && plugin_out == Status::SUCCESS) {
            std::cout << "[Test] MLLM generateAsync invoked.\n";
        }

        // 等异步回调完成 (本示例中，同步回调了几次)
        std::this_thread::sleep_for(std::chrono::milliseconds(500));

        // (如果要测试多次异步调用，也可以再来一次 generateAsync)
    }

    // ================== FaceId (modelId=2001) ==================
    {
        UINT32 modelId = 2001;
        auto st = PluginManager::getInstance().initPlugin(modelId);
        if (st != Status::SUCCESS) {
            std::cerr << "[Test] initPlugin(FaceId, 2001) failed!\n";
        } else {
            std::cout << "[Test] initPlugin(FaceId, 2001) success.\n";
        }

        // 调用 faceIdOn
        st = PluginManager::getInstance().modelOn(
                modelId,
                1234,
                [](const std::string &jsonRes){
                    std::cout << "[Test-FaceIdCallback] " << jsonRes << std::endl;
                }
        );
        if (st == Status::SUCCESS) {
            std::cout << "[Test] faceIdOn success.\n";
        } else {
            std::cerr << "[Test] faceIdOn failed.\n";
        }

        // 模拟等待
        std::this_thread::sleep_for(std::chrono::milliseconds(200));

        // faceIdOff
        st = PluginManager::getInstance().modelOff(modelId, 1234);
        if (st == Status::SUCCESS) {
            std::cout << "[Test] faceIdOff success.\n";
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(200));

        //faceIdManagerAsync
        Status plugin_out;
        auto asyncSt = PluginManager::getInstance().faceIdManageAsync(modelId, R"({"image": "base64_image_data"})", [] (Status status, const std::string& result) {
            std::cout << "[Test-FaceIdCallback] " << result << std::endl;
            if (status == Status::SUCCESS) {
                std::cout << "[Test] faceIdManagerAsync success.\n";
            } else {
                std::cerr << "[Test] faceIdManagerAsync failed.\n";
            }

        },
        plugin_out);

        if (asyncSt == AimhStatus::SUCCESS && plugin_out == Status::SUCCESS) {
            std::cout << "[Test] faceIdManagerAsync invoked.\n";
        }
    }

    // ================== OMS (modelId=2002) ==================
    {
        UINT32 modelId = 2002;
        auto st = PluginManager::getInstance().initPlugin(modelId);
        if (st != Status::SUCCESS) {
            std::cerr << "[Test] initPlugin(OMS, 2002) failed!\n";
        } else {
            std::cout << "[Test] initPlugin(OMS, 2002) success.\n";
        }

        // omsOn
        st = PluginManager::getInstance().modelOn(
                modelId,
                5678,
                [](const std::string &jsonMsg){
                    std::cout << "[Test-OMSCallback] " << jsonMsg << std::endl;
                }
        );
        if (st == Status::SUCCESS) {
            std::cout << "[Test] omsOn success.\n";
        } else {
            std::cerr << "[Test] omsOn failed.\n";
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(200));

        // omsOff
        st = PluginManager::getInstance().modelOff(modelId, 5678);
        if (st == Status::SUCCESS) {
            std::cout << "[Test] omsOff success.\n";
        }
    }

    // ================== QrHelper (modelId=2003) ==================
    // {
    //     UINT32 modelId = 2003;
    //     auto st = PluginManager::getInstance().initPlugin(modelId);
    //     if (st != Status::SUCCESS) {
    //         std::cerr << "[Test] initPlugin(QrHelper, 2003) failed!\n";
    //     } else {
    //         std::cout << "[Test] initPlugin(QrHelper, 2003) success.\n";
    //     }

    //     // qrHelperOn
    //     st = PluginManager::getInstance().qrHelperOn(
    //             modelId,
    //             9999,
    //             [](QrHelperOutput out){
    //                 std::cout << "[Test-QrHelperCallback] got qrContent=" << out.qrContent << std::endl;
    //             }
    //     );
    //     if (st == Status::SUCCESS) {
    //         std::cout << "[Test] qrHelperOn success.\n";
    //     } else {
    //         std::cerr << "[Test] qrHelperOn failed.\n";
    //     }

    //     std::this_thread::sleep_for(std::chrono::milliseconds(200));

    //     // qrHelperOff
    //     st = PluginManager::getInstance().qrHelperOff(modelId, 9999);
    //     if (st == Status::SUCCESS) {
    //         std::cout << "[Test] qrHelperOff success.\n";
    //     }
    // }

    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        std::cout << "[Test] Sleeping...\n";
    }
    // 3) 反初始化 & 卸载
    //    如果你想保留插件继续使用，也可以不卸载
    std::this_thread::sleep_for(std::chrono::seconds(10));
    // 大模型
    PluginManager::getInstance().deinitPlugin(1001);
    PluginManager::getInstance().unloadPlugin(1001);

    // FaceId
    PluginManager::getInstance().deinitPlugin(2001);
    PluginManager::getInstance().unloadPlugin(2001);

    // OMS
    PluginManager::getInstance().deinitPlugin(2002);
    PluginManager::getInstance().unloadPlugin(2002);

    // QrHelper
    // PluginManager::getInstance().deinitPlugin(2003);
    // PluginManager::getInstance().unloadPlugin(2003);

    // std::this_thread::sleep_for(std::chrono::seconds(10));
    std::cout << "[Test] All plugins unloaded. Exiting...\n";
    return 0;
}

