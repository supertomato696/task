#include <iostream>
#include <atomic>
#include <string>
#include <vector>
#include <functional>
#include "aimh_types.h"
#include <thread>



// -----------------------------------------------
// 全局静态，用于模拟插件的状态 & modelId
static std::atomic<bool> g_inited(false);
static uint32_t g_modelId = 1001;  // 可以不在此处存 modelId，只有在界面显示
// -----------------------------------------------


// 导出符号: initModel
extern "C" Status initModel()
{
    if (g_inited.load()) {
        std::cout << "[libMllmSo] initModel: already inited.\n";
        return Status::SUCCESS;
    }
    // 模拟一些初始化操作
    std::cout << "[libMllmSo] initModel done. (modelId=" << g_modelId << ")\n";
    g_inited.store(true);
    return Status::SUCCESS;
}

// 导出符号: deinitModel
extern "C" Status deinitModel()
{
    if (!g_inited.load()) {
        std::cout << "[libMllmSo] deinitModel: not inited.\n";
        return Status::SUCCESS;
    }
    // 模拟一些释放操作
    std::cout << "[libMllmSo] deinitModel done.\n";
    g_inited.store(false);
    return Status::SUCCESS;
}

// 导出符号: isInitialized
extern "C" bool isInitialized()
{
    return g_inited.load();
}

// 导出符号: generateAsync
extern "C" Status generateAsync(const std::string &input, const MllmAsyncCallback &callback)
{
    if (!g_inited.load()) {
        std::cerr << "[libMllmSo] generateAsync: plugin not inited.\n";
        return Status::FAIL;
    }

    if (callback == nullptr) {
        std::cerr << "[libMllmSo] generateAsync: callback is nullptr.\n";
        return Status::FAIL;
    }
    std::cout << "[libMllmSo] generateAsync called, input=" << input << std::endl;


        std::cout << "Generating async for input: " << input << std::endl;

    // 模拟异步操作
    std::thread([input, callback]() {
        while (true) {
            std::cout << "[libMllmSo] generateAsync called, input=" << input << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(2));  // 模拟延迟
            callback(GenerationStatus::GENERATING, "Hello(1)");
                // 回调2 (GENERATING)
                callback(GenerationStatus::GENERATING, "Hello(2)");
            // 生成的结果
            GenerationStatus status = GenerationStatus::FINISH;  // 假设异步生成成功
            std::string output = "Generated output for: " + input;

            // 回调结果
            callback(status, output);
        }
    }).detach();


    return Status::SUCCESS;
}

// 导出符号: generate
extern "C" GenerateOutput generate(const std::string &input)
{
    GenerateOutput out;
    out.status = Status::FAIL;
    if (!g_inited.load()) {
        std::cerr << "[libMllmSo] generate: not inited.\n";
        return out;
    }
    std::cout << "[libMllmSo] generate called, input=" << input << std::endl;
    // // 模拟生成结果
    // out.status = Status::SUCCESS;
    // out.output = "Generate result from MLLM with prompt: " + input;

    // // 模拟返回一张图片
    // stBufferDataList dummyBuf;
    // {
    //     stBufferData buf;
    //     buf.format = stFormat::Image_PNG;
    //     buf.buffer.assign({0x89, 0x50, 0x4E, 0x47});
    //     dummyBuf.data.push_back(buf);
    // }
    // out.buffer_data_out = dummyBuf;
    // return out;

    // 模拟同步操作
    GenerateOutput result;
    result.status = Status::SUCCESS;
    result.output = "Generated output for: " + input;

    return result;
}
