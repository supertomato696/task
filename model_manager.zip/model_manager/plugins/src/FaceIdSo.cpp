#include <iostream>
#include <atomic>
#include <string>
#include <functional>
#include <thread>

#include "aimh_types.h"

// FaceId 回调
using FaceIdCallback = std::function<void(const std::string&)>;

// 全局静态
static std::atomic<bool> g_inited(false);

// initModel
extern "C" Status initModel()
{
    if (g_inited.load()) {
        std::cout << "[libFaceIdSo] initModel: already inited.\n";
        return Status::SUCCESS;
    }
    std::cout << "[libFaceIdSo] initModel done.\n";
    g_inited.store(true);
    return Status::SUCCESS;
}

// deinitModel
extern "C" Status deinitModel()
{
    if (!g_inited.load()) {
        std::cout << "[libFaceIdSo] deinitModel: not inited.\n";
        return Status::SUCCESS;
    }
    std::cout << "[libFaceIdSo] deinitModel done.\n";
    g_inited.store(false);
    return Status::SUCCESS;
}

// isInitialized
extern "C" bool isInitialized()
{
    return g_inited.load();
}

// faceIdOn
extern "C" Status modelOn(uint32_t streaming_channel,  FaceIdCallback face_id_handler)
{
    if (!g_inited.load()) {
        std::cerr << "[libFaceIdSo] faceIdOn: plugin not init.\n";
        return Status::FAIL;
    }
    std::cout << "[libFaceIdSo] faceIdOn called, channel=" << streaming_channel << std::endl;

    std::thread([streaming_channel, face_id_handler] () {
        while (true) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            if (face_id_handler) {
                // std::cout << "[libFaceIdSo] faceIdOn called, channel=" << streaming_channel << std::endl;
                face_id_handler(R"({"faceCount": 2, "message": "faces detected!"})");
            } else {
                std::cerr << "[libFaceIdSo] faceIdOn: no callback handler.\n";
                break;
            }
        }
    }).detach();

    // // 模拟回调一次检测结果
    // if (face_id_handler) {
    //     face_id_handler(R"({"faceCount": 2, "message": "faces detected!"})");
    // }

    return Status::SUCCESS;
}

// faceIdOff
extern "C" Status modelOff(uint32_t streaming_channel)
{
    if (!g_inited.load()) {
        std::cerr << "[libFaceIdSo] faceIdOff: plugin not init.\n";
        return Status::FAIL;
    }
    std::cout << "[libFaceIdSo] faceIdOff called, channel=" << streaming_channel << std::endl;

    return Status::SUCCESS;
}


    // 新增的异步接口
extern "C"   Status faceIdManageAsync(const std::string &input, AsyncCallback async_handler) {
        if (!g_inited.load()) {
            std::cerr << "[libFaceIdSo] faceIdManageAsync: plugin not init.\n";
            return Status::FAIL;
        }

        // std::cout << "[libFaceIdSo] faceIdManageAsync called, input=" << input << std::endl;

        // 模拟一个异步操作
        std::thread([input, async_handler]() {
            while (true) {
                // 模拟处理过程 (例如: 假设处理需要 2 秒)
                std::this_thread::sleep_for(std::chrono::seconds(2));

                // 假设处理完后返回 SUCCESS 和处理的结果
                Status result = Status::SUCCESS;
                std::string result_message = "FaceId processed successfully for input: " + input;
                std::cout << "[libFaceIdSo] faceIdManageAsync called, input=" << input << std::endl;

                // 调用回调，传递结果
                async_handler(result, result_message);
            }
        }).detach();

        return Status::SUCCESS; // 返回成功启动异步操作
    }