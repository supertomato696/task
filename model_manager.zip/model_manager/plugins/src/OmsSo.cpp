#include <iostream>
#include <atomic>
#include <string>
#include <functional>
#include "aimh_types.h"
#include <thread>

// OMS回调
using OmsCallback = std::function<void(const std::string&)>;

// 全局静态
static std::atomic<bool> g_inited(false);

// initModel
extern "C" Status initModel()
{
    if (g_inited.load()) {
        std::cout << "[libOmsSo] initModel: already inited.\n";
        return Status::SUCCESS;
    }
    std::cout << "[libOmsSo] initModel done.\n";
    g_inited.store(true);
    return Status::SUCCESS;
}

// deinitModel
extern "C" Status deinitModel()
{
    if (!g_inited.load()) {
        std::cout << "[libOmsSo] deinitModel: not inited.\n";
        return Status::SUCCESS;
    }
    std::cout << "[libOmsSo] deinitModel done.\n";
    g_inited.store(false);
    return Status::SUCCESS;
}

// isInitialized
extern "C" bool isInitialized()
{
    return g_inited.load();
}

// omsOn
extern "C" Status modelOn(uint32_t streaming_channel, OmsCallback oms_handler)
{
    if (!g_inited.load()) {
        std::cerr << "[libOmsSo] omsOn: plugin not init.\n";
        return Status::FAIL;
    }
    std::cout << "[libOmsSo] omsOn called, channel=" << streaming_channel << std::endl;

    // std::thread

    // 模拟一次回调
    if (oms_handler) {
        oms_handler(R"({"omsEvent": "OMS object detected", "channel": 2002})");
    }
    std::this_thread::sleep_for(std::chrono::seconds(2));

    // 模拟多次回调
    std::thread([streaming_channel, oms_handler] () {
        while (true) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            if (oms_handler) {
                oms_handler(R"({"omsEvent": "OMS object detected"})");
            } else {
                std::cerr << "[libOmsSo] modelOn: no callback handler.\n";
                break;
            }
        }
    }).detach();


    
    return Status::SUCCESS;
}

// omsOff
extern "C" Status modelOff(uint32_t streaming_channel)
{
    if (!g_inited.load()) {
        std::cerr << "[libOmsSo] omsOff: plugin not init.\n";
        return Status::FAIL;
    }
    std::cout << "[libOmsSo] omsOff called, channel=" << streaming_channel << std::endl;
    return Status::SUCCESS;
}
