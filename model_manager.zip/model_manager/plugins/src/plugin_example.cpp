#include "qr_helper.h"
#include <iostream>

extern "C" {
    void processQR(QrHelperOutput* out) {
        out->qrContent = "Plugin Processed: ABC-123";
        out->confidence = 99;
    }
}
