#include "qr_helper.h"
#include <iostream>
#include <dlfcn.h>
#include <thread>

using namespace std;

int main() {
    // 初始化
    if(initModel("config.json") != Status::SUCCESS) {
        cerr << "Init failed: " << getLastError() << endl;
        return 1;
    }

    // 注册回调
    auto callback = [](const QrHelperOutput& out) {
        cout << "Received QR: " << out.qrContent 
             << " (Confidence: " << out.confidence << "%)\n";
    };
    
    if(qrHelperOn(0, callback) != Status::SUCCESS) {
        cerr << "Enable failed: " << getLastError() << endl;
    }

    // 加载插件
    void* plugin = dlopen("./libqrplugin.so", RTLD_LAZY);
    if(plugin) {
        auto process = (void(*)(QrHelperOutput*))dlsym(plugin, "processQR");
        if(process) {
            QrHelperOutput out;
            process(&out);
            cout << "Plugin processed: " << out.qrContent << endl;
        }
        dlclose(plugin);
    }

    // 保持运行
    this_thread::sleep_for(3s);
    
    // 清理
    deinitModel();
    return 0;
}
