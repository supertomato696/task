#ifndef QR_HELPER_H
#define QR_HELPER_H

#include <functional>
#include <string>
#include <cstdint>

// 错误码枚举
enum class Status {
    SUCCESS,
    FAIL,
    NOT_INITIALIZED,
    CONFIG_ERROR,
    PLUGIN_ERROR,
    THREAD_TIMEOUT
};

// 输出数据结构体
struct QrHelperOutput {
    std::string qrContent;
    int confidence = 0;
};

// 回调函数类型
using QrHelperCallback = std::function<void(const QrHelperOutput&)>;

// 导出符号宏
#ifdef _WIN32
    #define EXPORT_API __declspec(dllexport)
#else
    #define EXPORT_API __attribute__((visibility("default")))
#endif

// 核心接口函数
extern "C" {
    EXPORT_API Status initModel(const char* config_path = nullptr);
    EXPORT_API Status deinitModel();
    EXPORT_API bool isInitialized();
    EXPORT_API Status qrHelperOn(uint32_t channel, QrHelperCallback cb);
    EXPORT_API Status qrHelperOff(uint32_t channel);
    EXPORT_API const char* getLastError();
}

#endif // QR_HELPER_H
