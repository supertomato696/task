#include <iostream>
#include <atomic>
#include <string>
#include <functional>

#include "aimh_types.h"



// 回调
using QrHelperCallback = std::function<void(QrHelperOutput)>;


// 全局静态
static std::atomic<bool> g_inited(false);

// initModel
extern "C" Status initModel()
{
    if (g_inited.load()) {
        std::cout << "[libQrHelperSo] initModel: already inited.\n";
        return Status::SUCCESS;
    }
    std::cout << "[libQrHelperSo] initModel done.\n";
    g_inited.store(true);
    return Status::SUCCESS;
}

// deinitModel
extern "C" Status deinitModel()
{
    if (!g_inited.load()) {
        std::cout << "[libQrHelperSo] deinitModel: not inited.\n";
        return Status::SUCCESS;
    }
    std::cout << "[libQrHelperSo] deinitModel done.\n";
    g_inited.store(false);
    return Status::SUCCESS;
}

// isInitialized
extern "C" bool isInitialized()
{
    return g_inited.load();
}

// qrHelperOn
extern "C" Status qrHelperOn(uint32_t streaming_channel, QrHelperCallback cb)
{
    if (!g_inited.load()) {
        std::cerr << "[libQrHelperSo] qrHelperOn: plugin not init.\n";
        return Status::FAIL;
    }
    std::cout << "[libQrHelperSo] qrHelperOn called, channel=" << streaming_channel << std::endl;

    // 模拟一次扫描结果
    if (cb) {
        QrHelperOutput out;
        out.qrContent = "Fake QR Content: https://example.com";
        cb(out);
    }
    return Status::SUCCESS;
}

// qrHelperOff
extern "C" Status qrHelperOff(uint32_t streaming_channel)
{
    if (!g_inited.load()) {
        std::cerr << "[libQrHelperSo] qrHelperOff: plugin not init.\n";
        return Status::FAIL;
    }
    std::cout << "[libQrHelperSo] qrHelperOff called, channel=" << streaming_channel << std::endl;
    return Status::SUCCESS;
}
