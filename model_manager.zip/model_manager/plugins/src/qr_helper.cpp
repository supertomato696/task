#include "qr_helper.h"
#include <atomic>
#include <mutex>
#include <queue>
#include <thread>
#include <condition_variable>
#include <fstream>
#include "nlohmann/json.hpp"
#include <dlfcn.h>
#include <csignal>

using namespace std;
using json = nlohmann::json;

// 全局状态管理
namespace {
    // 初始化状态
    atomic<bool> g_initialized{false};

    // 线程安全资源管理
    struct ThreadSafeResources {
        mutex mtx;
        unordered_map<uint32_t, QrHelperCallback> callbacks;
        json config;
        string last_error;
    };
    ThreadSafeResources g_res;

    // 异步任务队列
    class AsyncTaskQueue {
        queue<function<void()>> tasks;
        vector<thread> workers;
        mutex mtx;
        condition_variable cv;
        atomic<bool> stop{false};

    public:
        AsyncTaskQueue(size_t threads = 4) {
            for(size_t i = 0; i < threads; ++i) {
                workers.emplace_back([this] {
                    while(true) {
                        function<void()> task;
                        {
                            unique_lock<mutex> lock(mtx);
                            cv.wait(lock, [this]{ return stop || !tasks.empty(); });
                            if(stop && tasks.empty()) return;
                            task = move(tasks.front());
                            tasks.pop();
                        }
                        task();
                    }
                });
            }
        }

        template<typename F>
        void enqueue(F&& f) {
            {
                lock_guard<mutex> lock(mtx);
                tasks.emplace(forward<F>(f));
            }
            cv.notify_one();
        }

        ~AsyncTaskQueue() {
            stop = true;
            cv.notify_all();
            for(auto& t : workers) if(t.joinable()) t.join();
        }
    };
    unique_ptr<AsyncTaskQueue> g_taskQueue;

    // 信号处理
    volatile sig_atomic_t g_signalStatus = 0;
    void signalHandler(int signum) {
        g_signalStatus = signum;
        deinitModel();
    }
}

// 实现函数
extern "C" {
    EXPORT_API Status initModel(const char* config_path) {
        if(g_initialized) return Status::SUCCESS;

        // 加载配置文件
        try {
            if(config_path) {
                ifstream f(config_path);
                g_res.config = json::parse(f);
            }
        } catch(const exception& e) {
            g_res.last_error = "Config error: " + string(e.what());
            return Status::CONFIG_ERROR;
        }

        // 初始化任务队列
        size_t threads = g_res.config.value("worker_threads", 4);
        g_taskQueue = make_unique<AsyncTaskQueue>(threads);

        // 注册信号处理
        signal(SIGINT, signalHandler);
        signal(SIGTERM, signalHandler);

        g_initialized = true;
        return Status::SUCCESS;
    }

    EXPORT_API Status deinitModel() {
        if(!g_initialized) return Status::SUCCESS;

        // 清理任务队列
        g_taskQueue.reset();

        {
            lock_guard<mutex> lock(g_res.mtx);
            g_res.callbacks.clear();
        }

        g_initialized = false;
        return Status::SUCCESS;
    }

    EXPORT_API bool isInitialized() {
        return g_initialized.load();
    }

    EXPORT_API Status qrHelperOn(uint32_t channel, QrHelperCallback cb) {
        if(!g_initialized) {
            g_res.last_error = "Not initialized";
            return Status::NOT_INITIALIZED;
        }

        {
            lock_guard<mutex> lock(g_res.mtx);
            g_res.callbacks[channel] = cb;
        }

        // 模拟异步处理
        g_taskQueue->enqueue([channel] {
            this_thread::sleep_for(1s); // 模拟处理耗时

            QrHelperOutput out;
            out.qrContent = "QR Result: 2023";
            out.confidence = 95;

            lock_guard<mutex> lock(g_res.mtx);
            if(auto it = g_res.callbacks.find(channel); it != end(g_res.callbacks)) {
                it->second(out);
            }
        });

        return Status::SUCCESS;
    }

    EXPORT_API Status qrHelperOff(uint32_t channel) {
        lock_guard<mutex> lock(g_res.mtx);
        if(g_res.callbacks.erase(channel) == 0) {
            g_res.last_error = "Channel " + to_string(channel) + " not found";
            return Status::FAIL;
        }
        return Status::SUCCESS;
    }

    EXPORT_API const char* getLastError() {
        return g_res.last_error.c_str();
    }
}
