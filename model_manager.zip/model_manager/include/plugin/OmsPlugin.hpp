#include "IPlugin.h"
#include <dlfcn.h>   // dlopen, dlsym, dlclose
#include <iostream>

/**
 * @brief OmsPlugin
 *
 * - 实现公共接口：initModel / deinitModel / isInitialized
 * - 提供专有接口：omsOn / omsOff
 */
class OmsPlugin : public IPlugin
{
public:
    // 定义 OMS 插件需要的函数指针类型
    using FnInitModel   = Status (*)();
    using FnDeinitModel = Status (*)();
    using FnIsInit      = bool   (*)();

    using FnModelOn  = Status (*)(UINT32 streaming_channel, OmsCallback oms_handler);
    using FnModelOff = Status (*)(UINT32 streaming_channel);

public:
    explicit OmsPlugin(const ModelConfig &config)
            : IPlugin(config)

    {}

    ~OmsPlugin() override {

    }

    /**
     * @brief 实现基类的 initModel()
     */
    Status initModel() override
    {

        // 加载 .so
        if (loadSo() != 0) {
            std::cerr << "[OmsPlugin] initModel failed, because loadSo failed: " << config_.soPath << std::endl;
            return Status::FAIL;
        }
        // 调用 .so 内的 initModel
        if (!fnInitModel_) {
            std::cerr << "[OmsPlugin] initModel symbol not found.\n";
            return Status::NULLPTR;
        }

        Status st = fnInitModel_();
        if (st != Status::SUCCESS) {
            std::cerr << "[OmsPlugin] initModel() returned fail.\n";
            return st;
        }

        std::cout << "[OmsPlugin] initModel success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief 实现基类的 deinitModel()
     */
    Status deinitModel() override
    {

        if (fnDeinitModel_ == nullptr) {
            std::cerr << "[OmsPlugin] deinitModel: fnDeinitModel is null.\n";
            return Status::NULLPTR;
        }


        Status st = fnDeinitModel_();
        if (st != Status::SUCCESS) {
            std::cerr << "[OmsPlugin] deinitModel returned fail.\n";
            return st;
        }

        std::cout << "[OmsPlugin] deinitModel success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief 实现基类的 isInitialized()
     */
    bool isInitialized() const override
    {
        if (fnIsInitialized_) {
            return fnIsInitialized_();
        }
        std::cerr << "[OmsPlugin] isInitialized is null.\n";
        return false;
    }

    // ================== OMS 插件特有接口 ================== //

    /**
     * @brief OMS功能对指定影像流运行启动
     * @param streaming_channel 影像流ID
     * @param oms_handler 回调函数
     * @return 启动执行状态
     */
    Status modelOn(UINT32 streaming_channel, OmsCallback oms_handler) override
    {

        if (!fnModelOn_) {
            std::cerr << "[OmsPlugin] omsOn symbol not found.\n";
            return Status::NULLPTR;
        }

        Status st = fnModelOn_(streaming_channel, oms_handler);
        if (st != Status::SUCCESS) {
            std::cerr << "[OmsPlugin] omsOn returned fail.\n";
            return st;
        }
        std::cout << "[OmsPlugin] omsOn success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief OMS功能对指定影像流运行停止
     * @param streaming_channel 影像流ID
     * @return 停止执行状态
     */
    Status modelOff(UINT32 streaming_channel) override
    {

        if (!fnModelOff_) {
            std::cerr << "[OmsPlugin] omsOff symbol not found.\n";
            return Status::NULLPTR;
        }

        Status st = fnModelOff_(streaming_channel);
        if (st != Status::SUCCESS) {
            std::cerr << "[OmsPlugin] omsOff returned fail.\n";
            return st;
        }

        std::cout  << "[OmsPlugin] omsOff success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

private:
    /**
     * @brief 加载 .so 并解析符号
     */
    int loadSo()
    {
        if (soHandle_) {
            return 0; // 已加载
        }
        soHandle_ = dlopen(config_.soPath.c_str(), RTLD_LAZY);
        if (!soHandle_) {
            std::cerr << "[OmsPlugin] dlopen failed: " << dlerror() << std::endl;
            return -1;
        }
        // 解析函数指针
        if (parseSymbols() != 0) {
            dlclose(soHandle_);
            soHandle_ = nullptr;
            return -2;
        }
        std::cout << "[OmsPlugin] loadSo success. soPath=" << config_.soPath << std::endl;
        return 0;
    }

/**
 * @brief dlsym 解析
 * @return 0 成功，非0 失败
 */
int parseSymbols()
{
    dlerror();

    bool hasError = false;

    fnInitModel_ = reinterpret_cast<FnInitModel>(dlsym(soHandle_, "initModel"));
    const char* errInitModel = dlerror();
    if (errInitModel) {
        std::cerr << "[OmsPlugin] dlsym error for initModel: " << errInitModel << std::endl;
        hasError = true;
    }

    fnDeinitModel_ = reinterpret_cast<FnDeinitModel>(dlsym(soHandle_, "deinitModel"));
    const char* errDeinitModel = dlerror();
    if (errDeinitModel) {
        std::cerr << "[OmsPlugin] dlsym error for deinitModel: " << errDeinitModel << std::endl;
        hasError = true;
    }

    fnIsInitialized_ = reinterpret_cast<FnIsInit>(dlsym(soHandle_, "isInitialized"));
    const char* errIsInitialized = dlerror();
    if (errIsInitialized) {
        std::cerr << "[OmsPlugin] dlsym error for isInitialized: " << errIsInitialized << std::endl;
        hasError = true;
    }

    fnModelOn_ = reinterpret_cast<FnModelOn>(dlsym(soHandle_, "modelOn"));
    const char* errModelOn = dlerror();
    if (errModelOn) {
        std::cerr << "[OmsPlugin] dlsym error for modelOn: " << errModelOn << std::endl;
        hasError = true;
    }

    fnModelOff_ = reinterpret_cast<FnModelOff>(dlsym(soHandle_, "modelOff"));
    const char* errModelOff = dlerror();
    if (errModelOff) {
        std::cerr << "[OmsPlugin] dlsym error for modelOff: " << errModelOff << std::endl;
        hasError = true;
    }

    if (hasError) {
        return -1;
    }

    std::cout << "[OmsPlugin] parseSymbols success. soPath=" << config_.soPath << std::endl;
    return 0;
}


};
