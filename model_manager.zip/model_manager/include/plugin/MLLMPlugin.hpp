
#include "IPlugin.h"
#include <dlfcn.h>

/**
 * @brief 大模型插件 (MLLMPlugin)
 *        - 实现 initModel, deinitModel, isInitialized
 *        - 提供专有的 generate(), generateAsync() 接口
 *        - 内部通过 dlopen / dlsym 解析 .so
 */
class MLLMPlugin : public IPlugin
{
public:

    using FnGenerateAsync   = Status (*)(const std::string&, const MllmAsyncCallback &);
    using FnGenerate        = GenerateOutput (*)(const std::string&);

public:
    /**
     * @brief 构造：传入已加载的 ModelConfig
     */
    explicit MLLMPlugin(const ModelConfig &config)
            : IPlugin(config)
            , fnGenerateAsync_(nullptr)
            , fnGenerate_(nullptr)
    {
    }

    /**
     * @brief 析构时，如尚未 deinit，可自动处理
     */
    ~MLLMPlugin() override {
        if (fnGenerate_) {
            fnGenerate_ = nullptr;
        }

        if (fnGenerateAsync_) {
            fnGenerateAsync_ = nullptr;
        }
    }

    /**
     * @brief 实现 IPlugin 的 initModel()
     * @return 初始化执行状态
     */
    Status initModel() override
    {

        // 1) 加载 .so
        int ret = loadSo();
        if (ret != 0) {
            return Status::FAIL;
        }

        // 2) 调用 so 内部的 initModel
        if (!fnInitModel_) {
            std::cerr << "[MLLMPlugin] initModel is null.\n";
            return Status::NULLPTR;
        }

        Status st = fnInitModel_();
        if (st != Status::SUCCESS) {
            std::cerr << "[MLLMPlugin] initModel() returned fail.\n";
            return st;
        }


        std::cout << "[MLLMPlugin] initModel success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief 实现 IPlugin 的 deinitModel()
     * @return 反初始化执行状态
     */
    Status deinitModel() override
    {

        if (fnDeinitModel_ == nullptr) {
            std::cerr << "[MLLMPlugin] deinitModel: fnDeinitModel is null.\n";
            return Status::NULLPTR;
        }


        Status st = fnDeinitModel_();
        if (st != Status::SUCCESS) {
            std::cerr << "[MLLMPlugin] deinitModel returned fail.\n";
            return st;
        }



        std::cout << "[MLLMPlugin] deinitModel success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief 实现 IPlugin 的 isInitialized()
     * @return 是否已初始化
     */
    bool isInitialized() const override
    {
        // 调用 .so 里的 isInitialized 函数：
        if (fnIsInitialized_) { return fnIsInitialized_(); }
        std::cout << "[MLLMPlugin] isInitialized() is null.\n";

        return false;
    }

    // =========== 大模型插件专有接口 =========== //

    /**
     * @brief 多模态大模型推理异步执行
     * @param input 输入json
     * @param asyncHandler 异步回调函数
     * @param plugin_out 输出，插件执行状态
     * @return 接口调用执行状态
     */
    AimhStatus generateAsync(const std::string &input, const  MllmAsyncCallback &asyncHandler, Status &plugin_out)
    {
        plugin_out = Status::FAIL;

        if (!fnGenerateAsync_) {
            std::cerr << "[MLLMPlugin] generateAsync is null.\n";
            return AimhStatus::ERROR_ACTION_NOT_EXIST;
        }

        Status st =  fnGenerateAsync_(input, asyncHandler);
        if (st != Status::SUCCESS) {
            std::cerr << "[MLLMPlugin] generateAsync returned fail.\n";

        }
        plugin_out = st;
        
        return AimhStatus::SUCCESS;
    }

    /**
     * @brief 多模态大模型推理同步执行
     * @param input 输入json
     * @return 同步接口输出(含执行状态, 推理结果, 图像数据等)
     */
    GenerateOutput generate(const std::string &input)
    {
        GenerateOutput output;
        output.status = Status::NULLPTR;


        if (!fnGenerate_) {
            std::cerr << "[MLLMPlugin] generate symbol not found.\n";
            return output;
        }

        output = fnGenerate_(input);
        return output;
    }

private:
    /**
     * @brief 加载 .so 并解析符号
     * @return 0 成功，非0 失败
     */
    int loadSo()
    {
        if (soHandle_) {
            // 已加载过
            return 0;
        }
        // dlopen
        soHandle_ = dlopen(config_.soPath.c_str(), RTLD_LAZY);
        if (!soHandle_) {
            std::cerr << "[MLLMPlugin] dlopen failed: " << dlerror() << std::endl;
            return -1;
        }

        // parse symbols
        if (parseSymbols() != 0) {
            std::cerr << "[MLLMPlugin] loadSo failed.\n";
            dlclose(soHandle_);
            soHandle_ = nullptr;
            return -2;
        }
        std::cout << "[MLLMPlugin] loadSo success. soPath=" << config_.soPath << std::endl;
        return 0;
    }


    /**
 * @brief dlsym 解析函数指针
 * @return 0 成功，非0 失败
 */
int parseSymbols()
{
    dlerror();

    bool hasError = false;

    fnInitModel_ = reinterpret_cast<FnInitModel>(dlsym(soHandle_, "initModel"));
    const char* errInitModel = dlerror();
    if (errInitModel) {
        std::cerr << "[MLLMPlugin] dlsym error for initModel: " << errInitModel << std::endl;
        hasError = true;
    }

    fnDeinitModel_ = reinterpret_cast<FnDeinitModel>(dlsym(soHandle_, "deinitModel"));
    const char* errDeinitModel = dlerror();
    if (errDeinitModel) {
        std::cerr << "[MLLMPlugin] dlsym error for deinitModel: " << errDeinitModel << std::endl;
        hasError = true;
    }

    fnIsInitialized_ = reinterpret_cast<FnIsInitialized>(dlsym(soHandle_, "isInitialized"));
    const char* errIsInitialized = dlerror();
    if (errIsInitialized) {
        std::cerr << "[MLLMPlugin] dlsym error for isInitialized: " << errIsInitialized << std::endl;
        hasError = true;
    }

    fnGenerateAsync_ = reinterpret_cast<FnGenerateAsync>(dlsym(soHandle_, "generateAsync"));
    const char* errGenerateAsync = dlerror();
    if (errGenerateAsync) {
        std::cerr << "[MLLMPlugin] dlsym error for generateAsync: " << errGenerateAsync << std::endl;
        hasError = true;
    }

    fnGenerate_ = reinterpret_cast<FnGenerate>(dlsym(soHandle_, "generate"));
    const char* errGenerate = dlerror();
    if (errGenerate) {
        std::cerr << "[MLLMPlugin] dlsym error for generate: " << errGenerate << std::endl;
        hasError = true;
    }

    if (hasError) {
        return -1; // 如果有任何错误，返回失败
    }

    std::cout << "[MLLMPlugin] parseSymbols success. soPath=" << config_.soPath << std::endl;
    return 0;
}

private:
    FnGenerateAsync   fnGenerateAsync_;
    FnGenerate        fnGenerate_;
};