#pragma once

#include "IPlugin.h"  // 上述基类头文件
#include <dlfcn.h>    // dlopen, dlsym, dlclose
#include <iostream>

/**
 * @brief QrHelperPlugin
 *
 * 继承 IPlugin，主要实现：
 * - initModel / deinitModel / isInitialized
 * - qrHelperOn / qrHelperOff
 */
class QrHelperPlugin : public IPlugin
{
public:
    // 定义二维码插件需要解析的函数指针
    using FnInitModel   = Status (*)();
    using FnDeinitModel = Status (*)();
    using FnIsInit      = bool   (*)();

    using FnQrHelperOn  = Status (*)(UINT32 streaming_channel, QrHelperCallback callback);
    using FnQrHelperOff = Status (*)(UINT32 streaming_channel);

public:
    explicit QrHelperPlugin(const ModelConfig &config)
            : IPlugin(config)

            , fnQrHelperOn_(nullptr)
            , fnQrHelperOff_(nullptr)
    {}

    ~QrHelperPlugin() override
    {

    }

    /**
     * @brief 实现公共接口：initModel
     */
    Status initModel() override
    {

        // 1) dlopen + dlsym
        int ret = loadSo();
        if (ret != 0) {
            std::cout << "[QrHelperPlugin] initModel  failed because loadSo failed.\n";
            return Status::FAIL;
        }
        // 2) 调用 .so 内部的 initModel
        if (!fnInitModel_) {
            std::cerr << "[QrHelperPlugin] initModel symbol not found.\n";
            return Status::NULLPTR;
        }

        Status st = fnInitModel_();
        if (st != Status::SUCCESS) {
            std::cerr << "[QrHelperPlugin] initModel() returned fail. modelId=" << getModelId() << std::endl;
            return st;
        }
        // 标记初始化完成

        std::cout << "[QrHelperPlugin] initModel success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief 实现公共接口：deinitModel
     */
    Status deinitModel() override
    {
        if (fnDeinitModel_ == nullptr) {
            std::cerr << "[QrHelperPlugin] deinitModel: fnDeinitModel is null.\n";
            return Status::NULLPTR;
        }


        Status st = fnDeinitModel_();
        if (st != Status::SUCCESS) {
            std::cerr << "[QrHelperPlugin] deinitModel returned fail.\n";
            return st;
        }

        std::cout << "[QrHelperPlugin] deinitModel success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief 实现公共接口：isInitialized
     */
    bool isInitialized() const override
    {
        if (fnIsInitialized_) {
            return fnIsInitialized_();
        }

        std::cout << "[QrHelperPlugin] isInitialized is null\n";
        return false;
    }

    // =========== QrHelper 插件特有接口 =========== //

    /**
     * @brief 二维码识别功能对指定影像流运行启动
     *
     * @param streaming_channel 指定影像输入流（本期只需支持DVR输入）
     * @param qr_helper_handler 二维码识别回调函数
     *
     * @return 启动执行状态
     */
    Status qrHelperOn(UINT32 streaming_channel, QrHelperCallback qr_helper_handler)
    {

        if (!fnQrHelperOn_) {
            std::cerr << "[QrHelperPlugin] qrHelperOn symbol not found.\n";
            return Status::NULLPTR;
        }

        Status st = fnQrHelperOn_(streaming_channel, qr_helper_handler);
        if (st != Status::SUCCESS) {
            std::cerr << "[QrHelperPlugin] qrHelperOn returned fail. modelId=" << getModelId() << std::endl;
            return st;
        }

        std::cout << "[QrHelperPlugin] qrHelperOn success. modelId=" << getModelId() << std::endl;

        return Status::SUCCESS;
    }

    /**
     * @brief 二维码识别功能对指定影像流运行停止
     *
     * @param streaming_channel 指定影像输入流（本期只需支持DVR输入）
     * @return 停止执行状态
     */
    Status qrHelperOff(UINT32 streaming_channel)
    {

        if (!fnQrHelperOff_) {
            std::cerr << "[QrHelperPlugin] qrHelperOff symbol not found.\n";
            return Status::NULLPTR;
        }

        Status st = fnQrHelperOff_(streaming_channel);
        if (st != Status::SUCCESS) {
            std::cerr << "[QrHelperPlugin] qrHelperOff returned fail. modelId=" << getModelId() << std::endl;
            return st;
        }
        std::cout << "[QrHelperPlugin] qrHelperOff success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

private:
    /**
     * @brief 加载 .so 并解析符号
     * @return 0 成功，非 0 失败
     */
    int loadSo()
    {
        if (soHandle_) {
            return 0; // 已加载过
        }
        soHandle_ = dlopen(config_.soPath.c_str(), RTLD_LAZY);
        if (!soHandle_) {
            std::cerr << "[QrHelperPlugin] dlopen failed: " << dlerror() << std::endl;
            return -1;
        }
        // 解析符号
        if (parseSymbols() != 0) {
            dlclose(soHandle_);
            soHandle_ = nullptr;
            return -2;
        }

        std::cout << "[QrHelperPlugin] loadSo success. soPath=" << config_.soPath << std::endl;
        return 0;
    }

    /**
 * @brief dlsym 解析
 * @return 0 成功，非0 失败
 */
int parseSymbols()
{
    dlerror(); // 清除上一条错误

    bool hasError = false;

    // 逐个解析并检查每个函数指针
    fnInitModel_ = reinterpret_cast<FnInitModel>(dlsym(soHandle_, "initModel"));
    const char* errInitModel = dlerror();
    if (errInitModel) {
        std::cerr << "[QrHelperPlugin] dlsym error for initModel: " << errInitModel << std::endl;
        hasError = true;
    }

    fnDeinitModel_ = reinterpret_cast<FnDeinitModel>(dlsym(soHandle_, "deinitModel"));
    const char* errDeinitModel = dlerror();
    if (errDeinitModel) {
        std::cerr << "[QrHelperPlugin] dlsym error for deinitModel: " << errDeinitModel << std::endl;
        hasError = true;
    }

    fnIsInitialized_ = reinterpret_cast<FnIsInit>(dlsym(soHandle_, "isInitialized"));
    const char* errIsInitialized = dlerror();
    if (errIsInitialized) {
        std::cerr << "[QrHelperPlugin] dlsym error for isInitialized: " << errIsInitialized << std::endl;
        hasError = true;
    }

    fnQrHelperOn_ = reinterpret_cast<FnQrHelperOn>(dlsym(soHandle_, "qrHelperOn"));
    const char* errQrHelperOn = dlerror();
    if (errQrHelperOn) {
        std::cerr << "[QrHelperPlugin] dlsym error for qrHelperOn: " << errQrHelperOn << std::endl;
        hasError = true;
    }

    fnQrHelperOff_ = reinterpret_cast<FnQrHelperOff>(dlsym(soHandle_, "qrHelperOff"));
    const char* errQrHelperOff = dlerror();
    if (errQrHelperOff) {
        std::cerr << "[QrHelperPlugin] dlsym error for qrHelperOff: " << errQrHelperOff << std::endl;
        hasError = true;
    }

    if (hasError) {
        return -1; // 如果有任何错误，返回失败
    }

    std::cout << "[QrHelperPlugin] parseSymbols success. soPath=" << config_.soPath << std::endl;
    return 0;
}



private:
    FnQrHelperOn    fnQrHelperOn_;
    FnQrHelperOff   fnQrHelperOff_;
};
