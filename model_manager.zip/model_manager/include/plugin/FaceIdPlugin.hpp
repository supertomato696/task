#pragma once

#include "IPlugin.h"   // 或者你自己路径，比如 "plugin/IPlugin.hpp"
#include <dlfcn.h>     // dlopen, dlsym, dlclose
#include <iostream>

#include "../../../../third_party/fmt/include/fmt/format.h"

/**
 * @brief FaceId 插件
 *
 * 实现 initModel / deinitModel / isInitialized
 * 并提供 faceIdOn / faceIdOff 等函数
 */
class FaceIdPlugin : public IPlugin
{
public:

    using FnFaceIdManageAsync =  Status (*) (const std::string &input, AsyncCallback async_handler);

public:
    explicit FaceIdPlugin(const ModelConfig &config)
            : IPlugin(config)
            , fnFaceIdManageAsync_(nullptr)
    {}

    ~FaceIdPlugin() override {
        if (fnModelOn_) {
            fnModelOn_ = nullptr;
        }

        if (fnModelOff_) {
            fnModelOff_ = nullptr;
        }

        if (fnFaceIdManageAsync_) {
            fnFaceIdManageAsync_ = nullptr;
        }
    }

    /**
     * @brief 实现公共接口：initModel
     */
    Status initModel() override
    {

        // 加载 so & 解析符号
        int ret = loadSo();
        if (ret != 0) {
            std::cerr << "[FaceIdPlugin] initModel failed because so load failed.\n";

            return Status::FAIL;
        }

        // 调用 so 内部 initModel
        if (!fnInitModel_) {
            std::cerr << "[FaceIdPlugin] initModel symbol not found\n";
            return Status::NULLPTR;
        }

        Status st = fnInitModel_();
        if (st != Status::SUCCESS) {
            std::cerr << "[FaceIdPlugin] initModel() returned fail.\n";
            return st;
        }

        std::cout << "[FaceIdPlugin] initModel success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief 实现公共接口：deinitModel
     */
    Status deinitModel() override
    {

        if (fnDeinitModel_ == nullptr) {
            std::cerr << "[FaceIdPlugin] deinitModel symbol not found.\n";
            return Status::NULLPTR;
        }


        Status st = fnDeinitModel_();
        if (st != Status::SUCCESS) {
            std::cerr << "[FaceIdPlugin] deinitModel returned fail.\n";
            return st;
        }


        std::cout << "[FaceIdPlugin] deinitModel success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief 实现公共接口：isInitialized
     */
    bool isInitialized() const override
    {
        if (fnIsInitialized_) {
            return fnIsInitialized_();
        }
        std::cerr << "[FaceIdPlugin] isInitialized symbol not found.\n";
        return false;
    }


    // =========== FaceId 插件特有接口 =========== //

    /**
     * @brief FaceId 功能对指定影像流运行启动
     * @param streamingChannel 指定影像输入流
     * @param faceIdHandler 回调函数
     * @return 启动执行状态
     */
    Status modelOn(UINT32 streamingChannel, FaceIdCallback faceIdHandler) override
    {

        if (!fnModelOn_) {
            std::cerr << "[FaceIdPlugin] faceIdOn symbol not found.\n";
            return Status::NULLPTR;
        }

        Status st = fnModelOn_(streamingChannel, faceIdHandler);
        if (st != Status::SUCCESS) {
            std::cerr << "[FaceIdPlugin] faceIdOn returned fail.\n";
            return st;
        }
        std::cout << "[FaceIdPlugin] call faceIdOn success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }

    /**
     * @brief FaceId 功能对指定影像流运行停止
     * @param streamingChannel
     * @return 停止执行状态
     */
    Status modelOff(UINT32 streamingChannel) override
    {

        if (!fnModelOff_) {
            std::cerr << "[FaceIdPlugin] faceIdOff symbol not found.\n";
            return Status::NULLPTR;
        }

        Status st = fnModelOff_(streamingChannel);
        if (st != Status::SUCCESS) {
            std::cerr << "[FaceIdPlugin] faceIdOff returned fail.\n";
            return st;
        }

        std::cout << "[FaceIdPlugin] call faceIdOff success. modelId=" << getModelId() << std::endl;
        return Status::SUCCESS;
    }


    /**
     * @brief FaceIdManagerAsync 插件特有接口
     * @param input
     * @param async_handler
     * @param plugin_out 输出，插件执行状态
     * @return 接口调用执行状态
     */

    AimhStatus faceIdManageAsync(const std::string &input, AsyncCallback async_handler, Status &plugin_out)
    {
        plugin_out = Status::FAIL;

        if (!fnFaceIdManageAsync_) {
            std::cerr << "[FaceIdPlugin] faceIdManagerAsync symbol not found.\n";
            return AimhStatus::ERROR_ACTION_NOT_EXIST;
        }

        Status st = fnFaceIdManageAsync_(input, async_handler);
        if (st != Status::SUCCESS) {
            std::cerr << "[FaceIdPlugin] faceIdManagerAsync returned fail.\n";
       }
        plugin_out = st;

        std::cout << "[FaceIdPlugin] call faceIdManagerAsync success. modelId=" << getModelId() << std::endl;
        return AimhStatus::SUCCESS;
    }

private:
    /**
     * @brief 加载 .so 并解析函数符号
     */
    int loadSo()
    {
        if (soHandle_) {
            std::cout << "[FaceIdPlugin] loadSo already loaded. soPath=" << config_.soPath << std::endl;
            return 0; // 已经加载过
        }
        soHandle_ = dlopen(config_.soPath.c_str(), RTLD_LAZY);
        if (!soHandle_) {
            std::cerr << "[FaceIdPlugin] dlopen failed: " << dlerror() << std::endl;
            return -1;
        }
        // 解析函数指针
        if (parseSymbols() != 0) {
            std::cout << "loadSo failed, because parseSymbols failed.\n";
            dlclose(soHandle_);
            soHandle_ = nullptr;
            return -2;
        }
        std::cout << "[FaceIdPlugin] loadSo success. soPath=" << config_.soPath << std::endl;
        return 0;
    }


/**
 * @brief dlsym 解析
 * @return 0 成功，非0 失败
 */
int parseSymbols()
{
    dlerror(); // 清理旧的 error

    bool hasError = false;

    fnInitModel_ = reinterpret_cast<FnInitModel>(dlsym(soHandle_, "initModel"));
    if (const char* errInitModel = dlerror()) {
        std::cerr << "[FaceIdPlugin] dlsym error for initModel: " << errInitModel << std::endl;
        hasError = true;
    }

    fnDeinitModel_ = reinterpret_cast<FnDeinitModel>(dlsym(soHandle_, "deinitModel"));
    const char* errDeinitModel = dlerror();
    if (errDeinitModel) {
        std::cerr << "[FaceIdPlugin] dlsym error for deinitModel: " << errDeinitModel << std::endl;
        hasError = true;
    }

    fnIsInitialized_ = reinterpret_cast<FnIsInitialized>(dlsym(soHandle_, "isInitialized"));
    const char* errIsInitialized = dlerror();
    if (errIsInitialized) {
        std::cerr << "[FaceIdPlugin] dlsym error for isInitialized: " << errIsInitialized << std::endl;
        hasError = true;
    }

    fnModelOn_ = reinterpret_cast<FnModelOn>(dlsym(soHandle_, "modelOn"));
    const char* errModelOn = dlerror();
    if (errModelOn) {
        std::cerr << "[FaceIdPlugin] dlsym error for modelOn: " << errModelOn << std::endl;
        hasError = true;
    }

    fnModelOff_ = reinterpret_cast<FnModelOff>(dlsym(soHandle_, "modelOff"));
    const char* errModelOff = dlerror();
    if (errModelOff) {
        std::cerr << "[FaceIdPlugin] dlsym error for modelOff: " << errModelOff << std::endl;
        hasError = true;
    }

    fnFaceIdManageAsync_ = reinterpret_cast<FnFaceIdManageAsync>(dlsym(soHandle_, "faceIdManageAsync"));
        const char* errFaceIdManagerAsync = dlerror();
        if (errFaceIdManagerAsync) {
            std::cerr << "[FaceIdPlugin] dlsym error for faceIdManagerAsync: " << errFaceIdManagerAsync << std::endl;
            hasError = true;
        }

    if (hasError) {
        return -1;
    }

    std::cout << "[FaceIdPlugin] parseSymbols success. soPath=" << config_.soPath << std::endl;
    return 0;
}

private:
    FnFaceIdManageAsync fnFaceIdManageAsync_;
};
