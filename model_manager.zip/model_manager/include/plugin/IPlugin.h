
#pragma once

#include <string>
#include <atomic>
#include "aimh_types.h"
#include "ConfigLoader.h"

#include <dlfcn.h>


/**
 * @brief 抽象基类 IPlugin
 *        - 定义所有插件都要实现的公共接口：
 *          initModel(), deinitModel(), isInitialized()
 *        - 存放公共成员：ModelConfig, soHandle, isInitialized_
 */
class IPlugin
{
public:
    using FnInitModel       = Status (*)();
    using FnDeinitModel     = Status (*)();
    using FnIsInitialized   = bool   (*)();

    using FnModelOn  = Status (*)(UINT32 streamingChannel, StreamingCallback callbackHandler);

    using FnModelOff = Status (*)(UINT32 streamingChannel);
    /**
     * @brief 构造函数，传入 ModelConfig
     */
    explicit IPlugin(const ModelConfig& config)
            : config_(config)
            , soHandle_(nullptr)
            , isInitialized_(false)
            , fnInitModel_(nullptr)
            , fnDeinitModel_(nullptr)
            , fnIsInitialized_(nullptr)
            , fnModelOn_(nullptr)
            , fnModelOff_(nullptr)

    {
    }

    /**
     * @brief 虚析构，保证派生类可正确释放资源
     */
    virtual ~IPlugin() {
        if (fnIsInitialized_) {
            if (fnIsInitialized_()) {
                if (fnDeinitModel_) {
                    fnDeinitModel_();
                } else {
                    std::cout << "IPlugin fnDeinitModel_ is null" << std::endl;
                }
            } else {
                std::cout << "IPlugin fnIsInitialized_()=false, no need fnDeinitModel_" << std::endl;
            }

            fnIsInitialized_ = nullptr;
        } else {
            std::cout << "IPlugin fnIsInitialized_ is null" << std::endl;
        }

        if (fnInitModel_) {
            fnInitModel_ = nullptr;
        }

        if (fnDeinitModel_) {
            fnDeinitModel_ = nullptr;
        }

        if (fnModelOn_) {
            fnModelOn_ = nullptr;
        }

        if (fnModelOff_) {
            fnModelOff_ = nullptr;
        }

        if (soHandle_) {
            dlclose(soHandle_);
        }


    }

    /**
     * @brief 模型初始化（纯虚函数，派生类实现）
     * @return 初始化执行状态
     */
    virtual Status initModel() = 0;

    /**
     * @brief 模型反初始化（纯虚函数，派生类实现）
     * @return 反初始化执行状态
     */
    virtual Status deinitModel() = 0;

    /**
     * @brief 检查模型是否已初始化（纯虚函数，派生类实现）
     * @return 模型初始化状态
     */
    virtual bool isInitialized() const = 0;

    virtual Status modelOn(UINT32 streamingChannel, StreamingCallback callbackHandler) {
        std::cout << "IPlugin::modelOn" << " Plugin has not such interface" << std::endl;

        return Status::FAIL;
    }

    virtual Status modelOff(UINT32 streamingChannel) {
        std::cout << "IPlugin::modelOff" << " Plugin has not such interface" << std::endl;

        return Status::FAIL;
    }

    /**
     * @brief 获取该插件的 modelId
     */
    UINT32 getModelId() const {
        return config_.modelId;
    }

    /**
     * @brief 获取该插件的 soType
     */
    UINT32 getSoType() const {
        return config_.soType;
    }



protected:
    // 供派生类访问的成员
    ModelConfig config_;            // 插件配置信息（包括 soPath, modelId 等）
    void*       soHandle_;          // dlopen 返回的句柄
    std::atomic<bool> isInitialized_; // 是否已初始化
    std::atomic<uint32_t> referenceCount{0};

protected:
    // ========== 函数指针 ========== //
    FnInitModel       fnInitModel_;
    FnDeinitModel     fnDeinitModel_;
    FnIsInitialized   fnIsInitialized_;
    FnModelOn         fnModelOn_;
    FnModelOff        fnModelOff_;
};