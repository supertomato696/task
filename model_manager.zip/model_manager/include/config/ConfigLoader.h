#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <cstdint>

/**
 * @brief 存放单个模型的配置信息
 */
struct ModelConfig {
    uint32_t modelId;
    std::string name;
    std::string version;
    std::string soPath;
    uint32_t soType;



    std::unordered_map<std::string, std::string> initParams;
};

/**
 * @brief ConfigLoader 负责从 JSON/YAML 等配置文件中加载模型信息
 */
class ConfigLoader {

public:
    static ConfigLoader& getInstance();



    /**
     * @brief 从给定路径加载配置文件
     * @param filePath 配置文件路径 (JSON/YAML)
     * @return true: 加载成功, false: 加载失败
     */
    bool loadConfig(const std::string& filePath);

    /**
     * @brief 获取所有模型配置信息
     */
    const std::vector<ModelConfig>& getModelConfigs() const {
        return modelConfigs_;
    }


public:
    ~ConfigLoader() = default;
private:
    ConfigLoader() = default;

private:
    // 存放从配置文件中读取的模型配置列表
    std::vector<ModelConfig> modelConfigs_;
};