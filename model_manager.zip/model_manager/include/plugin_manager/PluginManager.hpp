#pragma once

#include <unordered_map>
#include <shared_mutex>
#include <mutex>
#include <memory>
#include <iostream>

#include "../config/ConfigLoader.h"
#include "../plugin/IPlugin.h"
#include "../plugin/MLLMPlugin.hpp"
#include "../plugin/FaceIdPlugin.hpp"
#include "../plugin/OmsPlugin.hpp"
#include "../plugin/QrHelperPlugin.hpp"

namespace  bos::aios {
    /**
     * @brief 插件管理器：统一管理多种插件的加载、卸载、初始化、调用等
     */

    class PluginManager
    {
    public:
        /**
         * @brief 单例访问接口
         */
        static PluginManager& getInstance()
        {
            static PluginManager instance;
            return instance;
        }

    public:
        ~PluginManager() = default;

        /**
         * @brief 从配置文件中批量加载插件
         *        - 调用 ConfigLoader 解析
         *        - 对每个 ModelConfig 调用 loadPlugin
         */
        void loadPlugins(const std::string &configPath)
        {
            // 1. 解析配置文件
            ConfigLoader &loader = ConfigLoader::getInstance();
            if (!loader.loadConfig(configPath)) {
                std::cerr << "[PluginManager] loadConfig failed, path=" << configPath << std::endl;
                return;
            }

            // 2. 逐个加载
            for (const auto &cfg : loader.getModelConfigs()) {
                int ret = loadPlugin(cfg);
                if (ret != 0) {
                    std::cerr << "[PluginManager] loadPlugin failed, modelId="
                              << cfg.modelId << ", soPath=" << cfg.soPath << std::endl;
                }
            }
        }

        /**
         * @brief 根据 ModelConfig 加载单个插件
         *        - 根据 cfg.soType 创建不同插件对象
         *        - 插入到 pluginMap_
         */
        int loadPlugin(const ModelConfig &cfg)
        {
            std::unique_lock<std::shared_mutex> lock(mutex_);

            // 检查是否已加载
            if (pluginMap_.find(cfg.modelId) != pluginMap_.end()) {
                std::cerr << "[PluginManager] modelId=" << cfg.modelId << " already loaded.\n";
                return -1;
            }

            // 创建对应插件对象
            std::shared_ptr<IPlugin> plugin = createPluginInstance(cfg);
            if (!plugin) {
                std::cerr << "[PluginManager] createPluginInstance failed. soType=" << cfg.soType << std::endl;
                return -2;
            }

            // 先不调用 initModel，留给上层决定何时初始化
            // 也可以在这里直接调用 plugin->initModel() 根据需求

            // 插入 map
            pluginMap_[cfg.modelId] = plugin;
            std::cout << "[PluginManager] loadPlugin success, modelId=" << cfg.modelId << std::endl;
            return 0;
        }

        /**
         * @brief 卸载某个插件
         *        - 调用 deinitModel
         *        - dlclose (派生类在 deinitModel() 内完成)
         *        - 从 map 中移除
         */
        int unloadPlugin(UINT32 modelId)
        {
            std::unique_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                std::cerr << "[PluginManager] unloadPlugin: modelId=" << modelId << " not found.\n";
                return -1;
            }
            std::shared_ptr<IPlugin> plugin = it->second;
            if(plugin->isInitialized()) { plugin->deinitModel(); }
            // 由插件内部执行 dlclose
            pluginMap_.erase(it);

            std::cout << "[PluginManager] unloadPlugin success, modelId=" << modelId << std::endl;
            return 0;
        }

        void unloadPlugins(const std::string& configPath = "")
        {

            ConfigLoader &loader = ConfigLoader::getInstance();
            // if (!loader.loadConfig(configPath)) {
            //     std::cerr << "[PluginManager] unloadPlugins loadConfig failed, path=" << configPath << std::endl;
            //     return;
            // }


            for (const auto &cfg : loader.getModelConfigs()) {
                int ret = unloadPlugin(cfg.modelId);
                if (ret != 0) {
                    std::cerr << "[PluginManager] unloadPlugins unloadPlugin failed, modelId="
                              << cfg.modelId << ", soPath=" << cfg.soPath << std::endl;
                }

                std::cout << "[PluginManager] unloadPlugins unloadPlugin successful, modelId="
                              << cfg.modelId << ", soPath=" << cfg.soPath << std::endl;
            }
        }

        /**
         * @brief 初始化某个插件
         */
        Status initPlugin(UINT32 modelId)
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                std::cerr << "[PluginManager] initPlugin: modelId=" << modelId << " not found.\n";
                return Status::FAIL;
            }
            return it->second->initModel();
        }

        /**
         * @brief 反初始化某个插件
         */
        Status deinitPlugin(UINT32 modelId)
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                std::cerr << "[PluginManager] deinitPlugin: modelId=" << modelId << " not found.\n";
                return Status::FAIL;
            }
            return it->second->deinitModel();
        }

        /**
         * @brief 是否已加载
         */
        bool isPluginLoaded(UINT32 modelId)
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            return (pluginMap_.find(modelId) != pluginMap_.end());
        }

        /**
         * @brief 是否已初始化
         */
        bool isPluginInitialized(UINT32 modelId)
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                return false;
            }
            return it->second->isInitialized();
        }

        // ================= 大模型 (MLLM) 专用接口示例 =================== //

        /**
         * @brief 大模型-同步生成
         */
        GenerateOutput mllmGenerate(UINT32 modelId, const std::string &inputJson)
        {
            GenerateOutput out;
            out.status = Status::FAIL;

            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                std::cerr << "[PluginManager] mllmGenerate: modelId=" << modelId << " not found.\n";
                return out;
            }
            // 动态转换到 MLLMPlugin
            auto mllmPtr = std::dynamic_pointer_cast<MLLMPlugin>(it->second);
            if (!mllmPtr) {
                std::cerr << "[PluginManager] mllmGenerate: modelId=" << modelId << " not MLLM type.\n";
                return out;
            }
            out = mllmPtr->generate(inputJson);
            return out;
        }

        /**
         * @brief 大模型-异步生成
         */
        AimhStatus mllmGenerateAsync(UINT32 modelId, const std::string &inputJson,  MllmAsyncCallback cb, Status &plugin_out)
        {
            plugin_out = Status::FAIL;
            
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                std::cerr << "[PluginManager] mllmGenerateAsync: modelId=" << modelId << " not found.\n";
                return AimhStatus::ERROR_MODEL_NOT_EXIST;
            }
            auto mllmPtr = std::dynamic_pointer_cast<MLLMPlugin>(it->second);
            if (!mllmPtr) {
                std::cerr << "[PluginManager] mllmGenerateAsync: modelId=" << modelId << " not MLLM type.\n";
                return AimhStatus::ERROR_ACTION_NOT_EXIST;
            }
            return mllmPtr->generateAsync(inputJson, cb, plugin_out);
        }

                // ================= FaceId 专用接口示例 =================== //

        AimhStatus faceIdManageAsync (UINT32 modelId, const std::string &inputJson, AsyncCallback cb, Status &plugin_out)
        {
            plugin_out = Status::FAIL;

            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                std::cerr << "[PluginManager] faceIdManagerAsync: modelId=" << modelId << " not found.\n";
                return AimhStatus::ERROR_MODEL_NOT_EXIST;
            }
            auto faceIdPtr = std::dynamic_pointer_cast<FaceIdPlugin>(it->second);
            if (!faceIdPtr) {
                std::cerr << "[PluginManager] faceIdManagerAsync: modelId=" << modelId << " not FaceId type.\n";
                return AimhStatus::ERROR_ACTION_NOT_EXIST;
            }

            return faceIdPtr->faceIdManageAsync(inputJson, cb, plugin_out);
        }

        Status modelOn(UINT32 modelId, UINT32 streamingChannel, FaceIdCallback handler)
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                std::cerr << "[PluginManager] modelOn: modelId=" << modelId << " not found.\n";
                return Status::FAIL;
            }

            return it->second->modelOn(streamingChannel, handler);

        }

        Status modelOff(UINT32 modelId, UINT32 streamingChannel)
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                std::cout << "[PluginManager] modelOff: modelId=" << modelId << " not found.\n";
                return Status::FAIL;
            }

            return it->second->modelOff(streamingChannel);
        }



        // // ================= FaceId 专用接口示例 =================== //
        //
        // Status faceIdOn(UINT32 modelId, UINT32 streamingChannel, FaceIdCallback handler)
        // {
        //     std::shared_lock<std::shared_mutex> lock(mutex_);
        //     auto it = pluginMap_.find(modelId);
        //     if (it == pluginMap_.end()) {
        //         std::cerr << "[PluginManager] faceIdOn: modelId=" << modelId << " not found.\n";
        //         return Status::FAIL;
        //     }
        //     auto faceIdPtr = std::dynamic_pointer_cast<FaceIdPlugin>(it->second);
        //     if (!faceIdPtr) {
        //         std::cerr << "[PluginManager] faceIdOn: modelId=" << modelId << " not FaceId type.\n";
        //         return Status::FAIL;
        //     }
        //     return faceIdPtr->faceIdOn(streamingChannel, handler);
        // }
        //
        // Status faceIdOff(UINT32 modelId, UINT32 streamingChannel)
        // {
        //     std::shared_lock<std::shared_mutex> lock(mutex_);
        //     auto it = pluginMap_.find(modelId);
        //     if (it == pluginMap_.end()) {
        //         return Status::FAIL;
        //     }
        //     auto faceIdPtr = std::dynamic_pointer_cast<FaceIdPlugin>(it->second);
        //     if (!faceIdPtr) {
        //         std::cerr << "[PluginManager] faceIdOff: modelId=" << modelId << " not found.\n";
        //         return Status::FAIL;
        //     }
        //     return faceIdPtr->faceIdOff(streamingChannel);
        // }
        //
        // // ================= OMS 专用接口示例 =================== //
        //
        // Status omsOn(UINT32 modelId, UINT32 streamingChannel, OmsCallback handler)
        // {
        //     std::shared_lock<std::shared_mutex> lock(mutex_);
        //     auto it = pluginMap_.find(modelId);
        //     if (it == pluginMap_.end()) {
        //         std::cerr << "[PluginManager] omsOn: modelId=" << modelId << " not found.\n";
        //         return Status::FAIL;
        //     }
        //     auto omsPtr = std::dynamic_pointer_cast<OmsPlugin>(it->second);
        //     if (!omsPtr) {
        //         std::cerr << "[PluginManager] omsOn: modelId=" << modelId << " not OMS type.\n";
        //         return Status::FAIL;
        //     }
        //     return omsPtr->omsOn(streamingChannel, handler);
        // }
        //
        // Status omsOff(UINT32 modelId, UINT32 streamingChannel)
        // {
        //     std::shared_lock<std::shared_mutex> lock(mutex_);
        //     auto it = pluginMap_.find(modelId);
        //     if (it == pluginMap_.end()) {
        //         return Status::FAIL;
        //     }
        //     auto omsPtr = std::dynamic_pointer_cast<OmsPlugin>(it->second);
        //     if (!omsPtr) {
        //         std::cerr << "[PluginManager] omsOff: modelId=" << modelId << " not found.\n";
        //         return Status::FAIL;
        //     }
        //     return omsPtr->omsOff(streamingChannel);
        // }

        // ================= QrHelper 专用接口示例 =================== //

        Status qrHelperOn(UINT32 modelId, UINT32 streamingChannel, QrHelperCallback handler)
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                return Status::FAIL;
            }
            auto qrPtr = std::dynamic_pointer_cast<QrHelperPlugin>(it->second);
            if (!qrPtr) {
                return Status::FAIL;
            }
            return qrPtr->qrHelperOn(streamingChannel, handler);
        }

        Status qrHelperOff(UINT32 modelId, UINT32 streamingChannel)
        {
            std::shared_lock<std::shared_mutex> lock(mutex_);
            auto it = pluginMap_.find(modelId);
            if (it == pluginMap_.end()) {
                return Status::FAIL;
            }
            auto qrPtr = std::dynamic_pointer_cast<QrHelperPlugin>(it->second);
            if (!qrPtr) {
                return Status::FAIL;
            }
            return qrPtr->qrHelperOff(streamingChannel);
        }

    public:
        // ========== 设置发布 (给总线) 的相关参数 ==========
        //    /**
        //     * @brief 设置一个全局 pubMgr, PluginManager 就能在回调中 publish
        //     */
        //    void setPubMgr(std::shared_ptr<AIOSPubClientMgrImpl> pubMgr) {
        //        pubMgr_ = pubMgr;
        //    }

        /**
         * @brief 设置大模型异步事件使用的topic
         */
        void setMllmEventTopic(const std::string &topic) {
            mllmEventTopic_ = topic;
        }

        /**
         * @brief 设置faceId事件使用的topic
         */
        void setFaceIdEventTopic(const std::string &topic) {
            faceIdEventTopic_ = topic;
        }


    private:
        PluginManager() = default;

        PluginManager(const PluginManager&)            = delete;
        PluginManager& operator=(const PluginManager&) = delete;

        /**
         * @brief 根据 soType 创建对应插件对象
         */
        std::shared_ptr<IPlugin> createPluginInstance(const ModelConfig &cfg)
        {
            switch (cfg.soType) {
                case 1:
                    // 大模型
                        return std::make_shared<MLLMPlugin>(cfg);
                case 2:
                    // FaceId
                        return std::make_shared<FaceIdPlugin>(cfg);
                case 3:
                    // OMS
                        return std::make_shared<OmsPlugin>(cfg);
                case 4:
                    // QrHelper
                        return std::make_shared<QrHelperPlugin>(cfg);
                default:
                    std::cerr << "[PluginManager] unknown soType=" << cfg.soType << std::endl;
                return nullptr;
            }
        }

    private:
        /**
         * @brief 存放已加载插件对象的 map
         *        key = modelId, value = IPlugin派生类实例
         */
        std::unordered_map<UINT32, std::shared_ptr<IPlugin>> pluginMap_;
        mutable std::shared_mutex mutex_;

    private:
        // 系统总线的发布客户端
        //    std::shared_ptr<AIOSPubClientMgrImpl> pubMgr_;

        // 要发布的大模型、FaceId 事件topic
        std::string mllmEventTopic_;
        std::string faceIdEventTopic_;

    };
}