#!/bin/bash

# 定义一些变量
BUILD_DIR="build"
# TOOLCHAIN_FILE="$HOME/toolchain/global-toolchain.cmake"
TOOLCHAIN_FILE="$HOME/toolchain/toolchain.cmake"

# 如果 build 目录已经存在，删除它
if [ -d "$BUILD_DIR" ]; then
    echo "Removing existing build directory..."
    rm -rf "$BUILD_DIR"
fi

# 创建新的 build 目录并进入
echo "Creating build directory..."
mkdir -p "$BUILD_DIR"  # 创建新的 build 目录
cd "$BUILD_DIR" || exit 1  # 如果进入失败，则退出脚本

# 判断是否提供了工具链文件，若是，则使用工具链进行交叉编译
if [ -f "$TOOLCHAIN_FILE" ]; then
    echo "Using toolchain file: $TOOLCHAIN_FILE"
    cmake .. -DCMAKE_TOOLCHAIN_FILE="$TOOLCHAIN_FILE" \
    # -DCMAKE_INSTALL_PREFIX=/opt/mtk8678_toolchains/sysroots/aarch64-poky-linux/usr/local
else
    echo "No toolchain file found, proceeding with default cmake configuration."
    cmake ..
fi

# 编译项目
echo "Building project..."
make

# 检查构建是否成功
if [ $? -eq 0 ]; then
    echo "Build completed successfully."
else
    echo "Build failed."
    exit 1
fi
